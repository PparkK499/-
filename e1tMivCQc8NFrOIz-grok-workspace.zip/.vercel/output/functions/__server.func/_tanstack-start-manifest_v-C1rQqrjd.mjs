//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C1rQqrjd.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BFfAUzRC.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BFfAUzRC.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-KIFU_a-4.js"]
	}
} });
//#endregion
export { tsrStartManifest };
