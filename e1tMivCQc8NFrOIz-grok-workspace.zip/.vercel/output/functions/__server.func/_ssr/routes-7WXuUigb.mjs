import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Line, c as ResponsiveContainer, i as XAxis, l as Tooltip, n as LineChart, o as CartesianGrid, r as YAxis, s as Bar, t as BarChart } from "../_libs/recharts+[...].mjs";
import { t as katex } from "../_libs/katex.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-7WXuUigb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STROKE = {
	primary: "var(--color-primary)",
	accent: "var(--color-accent)",
	muted: "var(--color-muted)"
};
function fmtTick(v) {
	if (!Number.isFinite(v)) return "";
	const a = Math.abs(v);
	if (a !== 0 && (a >= 1e3 || a < .01)) return v.toExponential(0);
	if (a >= 10) return v.toFixed(0);
	if (a >= 1) return String(Math.round(v * 10) / 10);
	return String(Math.round(v * 100) / 100);
}
function Tip({ active, payload, label }) {
	if (!active || !payload?.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border bg-surface px-3 py-2 text-xs text-fg shadow-none",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-1 tabular-nums text-muted",
			children: fmtTick(Number(label))
		}), payload.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "tabular-nums",
			style: { color: p.color },
			children: [
				p.name,
				" ",
				fmtTick(Number(p.value))
			]
		}, p.name))]
	});
}
function Legend({ lines }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mb-2 flex flex-wrap gap-x-4 gap-y-1",
		children: lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-center gap-2 text-xs text-muted",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "inline-block h-0.5 w-4",
				style: {
					background: STROKE[line.tone],
					outline: line.dash ? "1px dashed var(--color-border)" : void 0
				}
			}), line.name]
		}, line.key))
	});
}
function LinePlot({ title, subtitle, xLabel, data, lines, yDomain }) {
	const [on, setOn] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setOn(true), []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "rounded-xl border border-border bg-surface p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
				className: "mb-1 flex flex-wrap items-baseline justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-medium",
					children: title
				}), subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted",
					children: subtitle
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, { lines }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-56",
				children: on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
						data,
						margin: {
							top: 8,
							right: 8,
							left: 0,
							bottom: 0
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
								stroke: "var(--color-border)",
								strokeDasharray: "3 6",
								vertical: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "x",
								tickFormatter: fmtTick,
								stroke: "var(--color-muted)",
								tick: {
									fill: "var(--color-muted)",
									fontSize: 11
								},
								minTickGap: 32,
								axisLine: false,
								tickLine: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								domain: yDomain ?? ["auto", "auto"],
								tickFormatter: fmtTick,
								stroke: "var(--color-muted)",
								tick: {
									fill: "var(--color-muted)",
									fontSize: 11
								},
								width: 44,
								axisLine: false,
								tickLine: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tip, {}) }),
							lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								type: "monotone",
								dataKey: line.key,
								name: line.name,
								stroke: STROKE[line.tone],
								strokeWidth: line.tone === "muted" ? 1.25 : 1.75,
								strokeDasharray: line.dash ? "5 4" : void 0,
								dot: false,
								connectNulls: false,
								isAnimationActive: false
							}, line.key))
						]
					})
				}) : null
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: xLabel
			})
		]
	});
}
function HarmonicBars({ data }) {
	const [on, setOn] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setOn(true), []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "rounded-xl border border-border bg-surface p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
				className: "mb-1 text-sm font-medium",
				children: "谐波系数"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, { lines: [{
				key: "an",
				name: "an 余弦",
				tone: "accent"
			}, {
				key: "bn",
				name: "bn 正弦",
				tone: "primary"
			}] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-56",
				children: on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
						data,
						margin: {
							top: 8,
							right: 8,
							left: 0,
							bottom: 0
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
								stroke: "var(--color-border)",
								strokeDasharray: "3 6",
								vertical: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "n",
								stroke: "var(--color-muted)",
								tick: {
									fill: "var(--color-muted)",
									fontSize: 11
								},
								axisLine: false,
								tickLine: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								tickFormatter: fmtTick,
								stroke: "var(--color-muted)",
								tick: {
									fill: "var(--color-muted)",
									fontSize: 11
								},
								width: 44,
								axisLine: false,
								tickLine: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tip, {}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "an",
								name: "an",
								fill: "var(--color-accent)",
								isAnimationActive: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "bn",
								name: "bn",
								fill: "var(--color-primary)",
								isAnimationActive: false
							})
						]
					})
				}) : null
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: "n"
			})
		]
	});
}
function Tex({ source, display = false }) {
	const html = katex.renderToString(source, {
		throwOnError: false,
		displayMode: display,
		output: "html",
		strict: "ignore"
	});
	if (display) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-x-auto py-1",
		dangerouslySetInnerHTML: { __html: html }
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { dangerouslySetInnerHTML: { __html: html } });
}
var ParseError = class extends Error {
	index;
	constructor(message, index) {
		super(message);
		this.name = "ParseError";
		this.index = index;
	}
};
var FUNCTIONS = /* @__PURE__ */ new Set([
	"sin",
	"cos",
	"tan",
	"asin",
	"acos",
	"atan",
	"exp",
	"log",
	"ln",
	"abs",
	"sqrt",
	"sign",
	"sgn",
	"rect",
	"tri",
	"sinc",
	"heaviside",
	"u",
	"step",
	"floor",
	"ceil",
	"saw",
	"min",
	"max"
]);
var CONSTANTS = /* @__PURE__ */ new Set(["pi", "e"]);
var NAME_MAP = {
	π: "pi",
	τ: "tau",
	ω: "omega",
	φ: "phi",
	ϕ: "phi",
	α: "alpha",
	β: "beta",
	γ: "gamma"
};
function normalizeName(raw) {
	if (NAME_MAP[raw]) return NAME_MAP[raw];
	return raw;
}
function tokenize(src) {
	const s = src;
	const out = [];
	let i = 0;
	while (i < s.length) {
		const c = s[i];
		if (c === " " || c === "	" || c === "\n" || c === "\r") {
			i++;
			continue;
		}
		if (c === "(" || c === "（") {
			out.push({
				k: "lp",
				i
			});
			i++;
			continue;
		}
		if (c === ")" || c === "）") {
			out.push({
				k: "rp",
				i
			});
			i++;
			continue;
		}
		if (c === "," || c === "，") {
			out.push({
				k: "comma",
				i
			});
			i++;
			continue;
		}
		if (c === "*" && s[i + 1] === "*") {
			out.push({
				k: "op",
				op: "^",
				i
			});
			i += 2;
			continue;
		}
		if (c === "+" || c === "-" || c === "−" || c === "*" || c === "×" || c === "·" || c === "/" || c === "÷" || c === "^") {
			const op = c === "−" ? "-" : c === "×" || c === "·" ? "*" : c === "÷" ? "/" : c;
			out.push({
				k: "op",
				op,
				i
			});
			i++;
			continue;
		}
		if (c >= "0" && c <= "9" || c === "." && s[i + 1] >= "0" && s[i + 1] <= "9") {
			const start = i;
			let t = "";
			while (i < s.length && (s[i] >= "0" && s[i] <= "9" || s[i] === ".")) {
				t += s[i];
				i++;
			}
			if (i < s.length && (s[i] === "e" || s[i] === "E")) {
				const ePos = i;
				let j = i + 1;
				if (s[j] === "+" || s[j] === "-") j++;
				if (s[j] >= "0" && s[j] <= "9") {
					t += s.slice(i, j);
					i = j;
					while (i < s.length && s[i] >= "0" && s[i] <= "9") {
						t += s[i];
						i++;
					}
				} else i = ePos;
			}
			const v = Number(t);
			if (!Number.isFinite(v)) throw new ParseError("数字无效", start);
			out.push({
				k: "num",
				v,
				i: start
			});
			continue;
		}
		if (isIdentStart(c)) {
			const start = i;
			let name = "";
			while (i < s.length && isIdentCont(s[i])) {
				name += s[i];
				i++;
			}
			out.push({
				k: "id",
				name: normalizeName(name),
				i: start
			});
			continue;
		}
		throw new ParseError(`不能识别「${c}」`, i);
	}
	return out;
}
function isIdentStart(c) {
	return /[A-Za-z_\u0391-\u03c9\u03d5]/.test(c);
}
function isIdentCont(c) {
	return /[A-Za-z0-9_\u0391-\u03c9\u03d5]/.test(c);
}
var Parser = class {
	toks;
	pos = 0;
	constructor(toks) {
		this.toks = toks;
	}
	peek() {
		return this.toks[this.pos];
	}
	parse() {
		if (this.toks.length === 0) throw new ParseError("请输入 f(t)", 0);
		const e = this.parseAdd();
		if (this.pos < this.toks.length) throw new ParseError("这里后面多出来一段", this.peek()?.i ?? 0);
		return e;
	}
	parseAdd() {
		let left = this.parseMul();
		while (true) {
			const p = this.peek();
			if (p?.k === "op" && (p.op === "+" || p.op === "-")) {
				this.pos++;
				const right = this.parseMul();
				left = {
					t: "b",
					op: p.op,
					a: left,
					b: right
				};
				continue;
			}
			break;
		}
		return left;
	}
	parseMul() {
		let left = this.parseUnary();
		while (true) {
			const p = this.peek();
			if (p?.k === "op" && (p.op === "*" || p.op === "/")) {
				this.pos++;
				const right = this.parseUnary();
				left = {
					t: "b",
					op: p.op,
					a: left,
					b: right
				};
				continue;
			}
			if (p && (p.k === "num" || p.k === "id" || p.k === "lp")) {
				const right = this.parseUnary();
				left = {
					t: "b",
					op: "*",
					a: left,
					b: right
				};
				continue;
			}
			break;
		}
		return left;
	}
	parseUnary() {
		const p = this.peek();
		if (p?.k === "op" && p.op === "+") {
			this.pos++;
			return this.parseUnary();
		}
		if (p?.k === "op" && p.op === "-") {
			this.pos++;
			return {
				t: "u",
				op: "-",
				a: this.parseUnary()
			};
		}
		return this.parsePow();
	}
	parsePow() {
		const left = this.parsePrimary();
		const p = this.peek();
		if (p?.k === "op" && p.op === "^") {
			this.pos++;
			return {
				t: "b",
				op: "^",
				a: left,
				b: this.parseUnary()
			};
		}
		return left;
	}
	parsePrimary() {
		const p = this.peek();
		if (!p) throw new ParseError("表达式在这里断了", this.toks.at(-1)?.i ?? 0);
		if (p.k === "lp") {
			this.pos++;
			const e = this.parseAdd();
			if (this.peek()?.k !== "rp") throw new ParseError("少了一个右括号", p.i);
			this.pos++;
			return e;
		}
		if (p.k === "num") {
			this.pos++;
			return {
				t: "n",
				v: p.v
			};
		}
		if (p.k === "id") {
			this.pos++;
			const next = this.peek();
			if (next?.k === "lp" && FUNCTIONS.has(p.name)) {
				const args = this.parseArgs();
				return {
					t: "c",
					name: p.name,
					args
				};
			}
			if (next?.k === "lp") throw new ParseError(`未知函数 ${p.name}`, p.i);
			return {
				t: "v",
				name: p.name
			};
		}
		throw new ParseError("这里期望数字、变量或函数", p.i);
	}
	parseArgs() {
		const lp = this.peek();
		if (lp?.k !== "lp") throw new ParseError("函数后面需要括号", lp?.i ?? 0);
		this.pos++;
		if (this.peek()?.k === "rp") {
			this.pos++;
			return [];
		}
		const args = [this.parseAdd()];
		while (this.peek()?.k === "comma") {
			this.pos++;
			args.push(this.parseAdd());
		}
		if (this.peek()?.k !== "rp") throw new ParseError("函数参数没有写完", lp.i);
		this.pos++;
		return args;
	}
};
function parse(src) {
	if (src.trim().length > 400) throw new ParseError("表达式太长", 0);
	return new Parser(tokenize(src)).parse();
}
function collectParams(ast) {
	const found = /* @__PURE__ */ new Set();
	const walk = (a) => {
		if (a.t === "v") {
			if (a.name !== "t" && !CONSTANTS.has(a.name)) found.add(a.name);
			return;
		}
		if (a.t === "u") walk(a.a);
		else if (a.t === "b") {
			walk(a.a);
			walk(a.b);
		} else if (a.t === "c") a.args.forEach(walk);
	};
	walk(ast);
	return [...found];
}
function callFn(name, args) {
	const [x, y] = args;
	switch (name) {
		case "sin": return Math.sin(x);
		case "cos": return Math.cos(x);
		case "tan": return Math.tan(x);
		case "asin": return Math.asin(x);
		case "acos": return Math.acos(x);
		case "atan": return args.length >= 2 ? Math.atan2(x, y) : Math.atan(x);
		case "exp": return Math.exp(x);
		case "log":
		case "ln": return Math.log(x);
		case "abs": return Math.abs(x);
		case "sqrt": return Math.sqrt(x);
		case "sign":
		case "sgn": return x > 0 ? 1 : x < 0 ? -1 : 0;
		case "rect": {
			const ax = Math.abs(x);
			if (ax < .5) return 1;
			if (Math.abs(ax - .5) < 1e-12) return .5;
			return 0;
		}
		case "tri": return Math.max(0, 1 - Math.abs(x));
		case "sinc":
			if (Math.abs(x) < 1e-10) return 1;
			return Math.sin(Math.PI * x) / (Math.PI * x);
		case "heaviside":
		case "u":
		case "step": return x >= 0 ? 1 : 0;
		case "floor": return Math.floor(x);
		case "ceil": return Math.ceil(x);
		case "saw": return 2 * (x - Math.round(x));
		case "min": return Math.min(x, y);
		case "max": return Math.max(x, y);
		default: return NaN;
	}
}
function evaluate(ast, t, params) {
	switch (ast.t) {
		case "n": return ast.v;
		case "v":
			if (ast.name === "t") return t;
			if (ast.name === "pi") return Math.PI;
			if (ast.name === "e") return Math.E;
			return params[ast.name] ?? 0;
		case "u": return -evaluate(ast.a, t, params);
		case "b": {
			const a = evaluate(ast.a, t, params);
			const b = evaluate(ast.b, t, params);
			switch (ast.op) {
				case "+": return a + b;
				case "-": return a - b;
				case "*": return a * b;
				case "/": return a / b;
				case "^": return Math.pow(a, b);
			}
		}
		case "c": return callFn(ast.name, ast.args.map((x) => evaluate(x, t, params)));
	}
}
var GREEK$1 = {
	pi: "\\pi",
	phi: "\\varphi",
	tau: "\\tau",
	omega: "\\omega",
	alpha: "\\alpha",
	beta: "\\beta",
	gamma: "\\gamma"
};
function latexName(name) {
	if (name === "t") return "t";
	return GREEK$1[name] ?? name;
}
function isAtomAst(a) {
	return a.t === "n" || a.t === "v" || a.t === "c";
}
function astToLatex(ast) {
	const precAdd = 1;
	const precMul = 2;
	const precPow = 3;
	const go = (a, prec) => {
		if (a.t === "n") {
			const s = Number.isInteger(a.v) ? String(a.v) : String(Number(a.v.toPrecision(6)));
			return a.v < 0 && prec > 0 ? `(${s})` : s;
		}
		if (a.t === "v") return latexName(a.name);
		if (a.t === "u") {
			const s = `-${go(a.a, precPow)}`;
			return prec > precMul ? `(${s})` : s;
		}
		if (a.t === "c") {
			if (a.name === "abs" && a.args.length === 1) return `\\left|${go(a.args[0], 0)}\\right|`;
			if (a.name === "sqrt" && a.args.length === 1) return `\\sqrt{${go(a.args[0], 0)}}`;
			return `${a.name === "ln" || a.name === "log" ? "\\ln" : a.name === "sign" || a.name === "sgn" ? "\\operatorname{sign}" : a.name === "rect" || a.name === "tri" || a.name === "sinc" || a.name === "saw" ? `\\operatorname{${a.name}}` : a.name === "u" || a.name === "step" || a.name === "heaviside" ? "u" : `\\${[
				"sin",
				"cos",
				"tan",
				"exp"
			].includes(a.name) ? a.name : `operatorname{${a.name}}`}`}\\!\\left(${a.args.map((x) => go(x, 0)).join(", ")}\\right)`;
		}
		const op = a.op;
		if (op === "/") return `\\frac{${go(a.a, 0)}}{${go(a.b, 0)}}`;
		if (op === "^") {
			const s = `${isAtomAst(a.a) && !(a.a.t === "n" && a.a.v < 0) ? go(a.a, 0) : `(${go(a.a, 0)})`}^{${go(a.b, 0)}}`;
			return prec > precPow ? `(${s})` : s;
		}
		if (op === "*") {
			const left = go(a.a, precMul);
			const right = go(a.b, precMul);
			const s = `${left}${/\\[a-zA-Z]+$/.test(left) && /^[A-Za-z\\]/.test(right) ? " " : ""}${right}`;
			return prec > precMul ? `(${s})` : s;
		}
		const left = go(a.a, precAdd);
		const right = go(a.b, op === "-" ? precMul : precAdd);
		const s = op === "+" ? `${left}+${right}` : `${left}-${right}`;
		return prec > precAdd ? `(${s})` : s;
	};
	return go(ast, 0);
}
function defaultParam(name) {
	const table = {
		A: 1,
		B: .6,
		C: .5,
		a: 1,
		b: 1,
		c: 1,
		w: 4,
		omega: 4,
		wc: 6,
		w0: 4,
		f: 1,
		f0: 1,
		tau: 1.5,
		T: 2,
		phi: 0,
		t0: .4,
		sigma: 1,
		alpha: 1,
		beta: 1,
		gamma: 1,
		n: 1
	};
	if (name in table) return table[name];
	if (/^[A-Z]$/.test(name)) return 1;
	return 1;
}
function sliderRange(name, value) {
	let min = -2;
	let max = 3;
	let step = .01;
	if (name === "phi") {
		min = -Math.PI;
		max = Math.PI;
		step = .01;
	} else if (name === "a" || name === "b" || name === "c" || name === "sigma" || name === "alpha") {
		min = .05;
		max = 5;
		step = .01;
	} else if (name === "tau" || name === "t0") {
		min = .15;
		max = 8;
		step = .01;
	} else if (name === "w" || name === "omega" || name === "wc" || name === "w0" || name === "gamma") {
		min = 0;
		max = 20;
		step = .05;
	} else if (name === "T") {
		min = .4;
		max = 12;
		step = .05;
	} else if (name === "n") {
		min = 1;
		max = 24;
		step = 1;
	} else if (/^[A-Z]$/.test(name)) {
		min = -2;
		max = 3;
		step = .01;
	}
	if (value < min) min = Math.floor(value * 10) / 10;
	if (value > max) max = Math.ceil(value * 10) / 10;
	return {
		min,
		max,
		step
	};
}
function fft(re, im, inverse = false) {
	const n = re.length;
	for (let i = 1, j = 0; i < n; i++) {
		let bit = n >> 1;
		for (; j & bit; bit >>= 1) j ^= bit;
		j ^= bit;
		if (i < j) {
			const tr = re[i];
			re[i] = re[j];
			re[j] = tr;
			const ti = im[i];
			im[i] = im[j];
			im[j] = ti;
		}
	}
	const sign = inverse ? 1 : -1;
	for (let len = 2; len <= n; len <<= 1) {
		const ang = sign * 2 * Math.PI / len;
		const wlenRe = Math.cos(ang);
		const wlenIm = Math.sin(ang);
		for (let i = 0; i < n; i += len) {
			let wr = 1;
			let wi = 0;
			const half = len >> 1;
			for (let k = 0; k < half; k++) {
				const j = i + k + half;
				const uRe = re[i + k];
				const uIm = im[i + k];
				const vRe = re[j] * wr - im[j] * wi;
				const vIm = re[j] * wi + im[j] * wr;
				re[i + k] = uRe + vRe;
				im[i + k] = uIm + vIm;
				re[j] = uRe - vRe;
				im[j] = uIm - vIm;
				const nwr = wr * wlenRe - wi * wlenIm;
				wi = wr * wlenIm + wi * wlenRe;
				wr = nwr;
			}
		}
	}
	if (inverse) for (let i = 0; i < n; i++) {
		re[i] /= n;
		im[i] /= n;
	}
}
function transform(fn, L, n = 4096) {
	const N = n < 16 ? 16 : n;
	const dt = 2 * L / N;
	const re = new Float64Array(N);
	const im = new Float64Array(N);
	const t0 = -L;
	for (let i = 0; i < N; i++) {
		const y = fn(t0 + i * dt);
		re[i] = Number.isFinite(y) ? y : 0;
	}
	fft(re, im, false);
	const wRaw = new Float64Array(N);
	const Fr = new Float64Array(N);
	const Fi = new Float64Array(N);
	for (let k = 0; k < N; k++) {
		const kk = k <= N / 2 ? k : k - N;
		const omega = 2 * Math.PI * kk / (N * dt);
		const phase = -omega * t0;
		const cr = Math.cos(phase);
		const ci = Math.sin(phase);
		const xr = re[k] * dt;
		const xi = im[k] * dt;
		Fr[k] = xr * cr - xi * ci;
		Fi[k] = xr * ci + xi * cr;
		wRaw[k] = omega;
	}
	const order = Array.from({ length: N }, (_, i) => i).sort((a, b) => wRaw[a] - wRaw[b]);
	return {
		w: order.map((i) => wRaw[i]),
		re: order.map((i) => Fr[i]),
		im: order.map((i) => Fi[i]),
		dt,
		L
	};
}
function interp(spec, omega) {
	const w = spec.w;
	const n = w.length;
	if (n === 0) return {
		re: 0,
		im: 0
	};
	if (omega <= w[0]) return {
		re: spec.re[0],
		im: spec.im[0]
	};
	if (omega >= w[n - 1]) return {
		re: spec.re[n - 1],
		im: spec.im[n - 1]
	};
	let lo = 0;
	let hi = n - 1;
	while (hi - lo > 1) {
		const mid = lo + hi >> 1;
		if (w[mid] <= omega) lo = mid;
		else hi = mid;
	}
	const span = w[hi] - w[lo] || 1;
	const u = (omega - w[lo]) / span;
	return {
		re: spec.re[lo] * (1 - u) + spec.re[hi] * u,
		im: spec.im[lo] * (1 - u) + spec.im[hi] * u
	};
}
function fourierSeries(fn, T, harmonics, samples = 4096) {
	const H = Math.max(1, Math.min(64, harmonics));
	const dt = T / samples;
	const w0 = 2 * Math.PI / T;
	const a = new Float64Array(H + 1);
	const b = new Float64Array(H + 1);
	for (let i = 0; i < samples; i++) {
		const t = -T / 2 + (i + .5) * dt;
		const y0 = fn(t);
		const y = Number.isFinite(y0) ? y0 : 0;
		a[0] += y;
		for (let n = 1; n <= H; n++) {
			const th = n * w0 * t;
			a[n] += y * Math.cos(th);
			b[n] += y * Math.sin(th);
		}
	}
	a[0] = a[0] * dt / T;
	const an = [0];
	const bn = [0];
	for (let n = 1; n <= H; n++) {
		an.push(2 * a[n] * dt / T);
		bn.push(2 * b[n] * dt / T);
	}
	return {
		T,
		w0,
		a0: a[0],
		an,
		bn
	};
}
function reconstruct(t, series, harmonics) {
	const H = Math.min(series.an.length - 1, harmonics ?? series.an.length - 1);
	let s = series.a0;
	for (let n = 1; n <= H; n++) {
		const th = n * series.w0 * t;
		s += series.an[n] * Math.cos(th) + series.bn[n] * Math.sin(th);
	}
	return s;
}
function energy(fn, t0, t1, samples = 2e3) {
	if (t1 <= t0) return 0;
	const dt = (t1 - t0) / samples;
	let s = 0;
	for (let i = 0; i < samples; i++) {
		const y = fn(t0 + (i + .5) * dt);
		if (Number.isFinite(y)) s += y * y;
	}
	return s * dt;
}
function relError(a, b, wMax) {
	let num = 0;
	let den = 0;
	const n = Math.min(a.w.length, b.w.length);
	for (let i = 0; i < n; i++) {
		if (Math.abs(a.w[i]) > wMax) continue;
		const dr = a.re[i] - b.re[i];
		const di = a.im[i] - b.im[i];
		num += dr * dr + di * di;
		den += a.re[i] * a.re[i] + a.im[i] * a.im[i] + b.re[i] * b.re[i] + b.im[i] * b.im[i];
	}
	return Math.sqrt(num / Math.max(den, 1e-18));
}
function spectrumRows(spec, wMax, keys) {
	const rows = [];
	for (let i = 0; i < spec.w.length; i++) {
		const w = spec.w[i];
		if (w < -wMax || w > wMax) continue;
		const re = spec.re[i];
		const im = spec.im[i];
		const mag = Math.hypot(re, im);
		const row = { x: w };
		if (keys.re) row[keys.re] = re;
		if (keys.im) row[keys.im] = im;
		if (keys.mag) row[keys.mag] = mag;
		if (keys.db) row[keys.db] = 20 * Math.log10(mag + 1e-12);
		if (keys.phase) row[keys.phase] = Math.atan2(im, re);
		rows.push(row);
	}
	return rows;
}
function tone(err) {
	if (err < .04) return "ok";
	if (err < .12) return "warn";
	return "bad";
}
function toneText(err) {
	if (err < .04) return "两边重合，这条性质在当前参量下成立。";
	if (err < .12) return "大体一致。剩下的差别主要来自有限观察窗把信号截断了。";
	return "偏差偏大。把观察窗加大，或让信号在窗边先衰减完，再看一次。";
}
var EXPERIMENTS = [
	{
		id: "linear",
		index: "01",
		label: "线性"
	},
	{
		id: "shift",
		index: "02",
		label: "时移"
	},
	{
		id: "scale",
		index: "03",
		label: "尺度"
	},
	{
		id: "mod",
		index: "04",
		label: "调制"
	},
	{
		id: "diff",
		index: "05",
		label: "微分"
	},
	{
		id: "conv",
		index: "06",
		label: "卷积"
	},
	{
		id: "sym",
		index: "07",
		label: "对称"
	},
	{
		id: "parseval",
		index: "08",
		label: "帕塞瓦尔"
	},
	{
		id: "gibbs",
		index: "09",
		label: "吉布斯"
	}
];
var N = 2048;
function gOf(kind) {
	if (kind === "gauss") return (t) => Math.exp(-.7 * t * t);
	if (kind === "rect") return (t) => Math.abs(t) < .75 ? 1 : 0;
	return (t) => t >= 0 ? Math.exp(-t) : 0;
}
function pct$1(err) {
	const p = err * 100;
	return `${p < 10 ? p.toFixed(2) : p.toFixed(1)}%`;
}
function metric(label, err) {
	return {
		label,
		value: pct$1(err),
		tone: tone(err)
	};
}
function rows2(a, b, wMax, ka, kb) {
	const rows = [];
	const n = Math.min(a.w.length, b.w.length);
	for (let i = 0; i < n; i++) {
		const w = a.w[i];
		if (w < -wMax || w > wMax) continue;
		rows.push({
			x: w,
			[ka]: Math.hypot(a.re[i], a.im[i]),
			[kb]: Math.hypot(b.re[i], b.im[i])
		});
	}
	return rows;
}
function timeRows(x0, x1, count, series) {
	const rows = [];
	for (let i = 0; i < count; i++) {
		const x = x0 + (x1 - x0) * i / (count - 1);
		const row = { x };
		for (const s of series) {
			const y = s.fn(x);
			row[s.key] = Number.isFinite(y) ? y : null;
		}
		rows.push(row);
	}
	return rows;
}
function onGrid(base, map) {
	return {
		...base,
		re: base.w.map((w) => map(w).re),
		im: base.w.map((w) => map(w).im)
	};
}
function runExperiment(input) {
	const { fn, L, wMax } = input;
	const viewT = Math.min(Math.max(L, 2), 8);
	switch (input.id) {
		case "linear": return linear(input, viewT);
		case "shift": return shift(input, viewT);
		case "scale": return scaling(input, viewT);
		case "mod": return modulation(input, viewT);
		case "diff": return diff(input, viewT);
		case "conv": return conv(input, viewT);
		case "sym": return symmetry(input, viewT);
		case "parseval": return parsevalView(fn, L, wMax);
		case "gibbs": return gibbs(input.gibbsN);
		default: return linear(input, viewT);
	}
}
function linear(input, viewT) {
	const g = gOf(input.gKind);
	const { fn, L, wMax, alpha, beta } = input;
	const mix = (t) => alpha * fn(t) + beta * g(t);
	const Fa = transform(fn, L, N);
	const Fg = transform(g, L, N);
	const direct = transform(mix, L, N);
	const theorem = onGrid(Fa, (w) => {
		const a = interp(Fa, w);
		const b = interp(Fg, w);
		return {
			re: alpha * a.re + beta * b.re,
			im: alpha * a.im + beta * b.im
		};
	});
	const err = relError(direct, theorem, wMax);
	return {
		formula: "\\mathcal{F}\\{\\alpha f+\\beta g\\}=\\alpha F+\\beta G",
		blurb: `g 固定为${input.gKind === "gauss" ? "高斯" : input.gKind === "rect" ? "矩形" : "单边指数"}，不占用左侧表达式。α、β 只做数乘和相加，频谱必须同样数乘再相加。`,
		charts: [{
			title: "混合后的时域",
			xLabel: "t",
			data: timeRows(-viewT, viewT, 360, [{
				key: "f",
				fn
			}, {
				key: "mix",
				fn: mix
			}]),
			lines: [{
				key: "f",
				name: "f(t)",
				tone: "muted"
			}, {
				key: "mix",
				name: "αf+βg",
				tone: "primary"
			}]
		}, {
			title: "幅度谱对照",
			subtitle: "实线直接变换，虚线是 αF+βG",
			xLabel: "ω",
			data: rows2(direct, theorem, wMax, "direct", "theorem"),
			lines: [{
				key: "direct",
				name: "直接变换",
				tone: "primary"
			}, {
				key: "theorem",
				name: "αF+βG",
				tone: "accent",
				dash: true
			}]
		}],
		metrics: [metric("频谱相对误差", err), {
			label: "判读",
			value: toneText(err),
			tone: tone(err)
		}]
	};
}
function shift(input, viewT) {
	const { fn, L, wMax, t0 } = input;
	const shifted = (t) => fn(t - t0);
	const base = transform(fn, L, N);
	const direct = transform(shifted, L, N);
	const theorem = onGrid(base, (w) => {
		const z = interp(base, w);
		const c = Math.cos(-w * t0);
		const s = Math.sin(-w * t0);
		return {
			re: z.re * c - z.im * s,
			im: z.re * s + z.im * c
		};
	});
	const err = relError(direct, theorem, wMax);
	const T = 4;
	const s0 = fourierSeries(fn, T, 8, 2048);
	const s1 = fourierSeries(shifted, T, 8, 2048);
	let num = 0;
	let den = 0;
	for (let n = 1; n <= 8; n++) {
		const cRe = s0.an[n] / 2;
		const cIm = -s0.bn[n] / 2;
		const ang = -n * s0.w0 * t0;
		const pr = cRe * Math.cos(ang) - cIm * Math.sin(ang);
		const pi = cRe * Math.sin(ang) + cIm * Math.cos(ang);
		const qr = s1.an[n] / 2;
		const qi = -s1.bn[n] / 2;
		num += (pr - qr) ** 2 + (pi - qi) ** 2;
		den += pr * pr + pi * pi + qr * qr + qi * qi;
	}
	const fsErr = Math.sqrt(num / Math.max(den, 1e-18));
	return {
		formula: "f(t-t_0)\\leftrightarrow e^{-j\\omega t_0}F(\\omega),\\quad c_n\\mapsto c_n e^{-jn\\omega_0 t_0}",
		blurb: "平移不改变幅度谱，只把相位拧成斜率 −t0 的直线。级数系数同样只旋转相位。",
		charts: [{
			title: "时域平移",
			xLabel: "t",
			data: timeRows(-viewT, viewT, 360, [{
				key: "f",
				fn
			}, {
				key: "s",
				fn: shifted
			}]),
			lines: [{
				key: "f",
				name: "f(t)",
				tone: "muted"
			}, {
				key: "s",
				name: "f(t−t0)",
				tone: "primary"
			}]
		}, {
			title: "幅度谱应重合",
			xLabel: "ω",
			data: rows2(direct, theorem, wMax, "direct", "theorem"),
			lines: [{
				key: "direct",
				name: "|变换后|",
				tone: "primary"
			}, {
				key: "theorem",
				name: "|F| 不变",
				tone: "accent",
				dash: true
			}]
		}],
		metrics: [
			metric("频谱相对误差", err),
			metric("级数系数相位误差", fsErr),
			{
				label: "判读",
				value: toneText(Math.max(err, fsErr)),
				tone: tone(Math.max(err, fsErr))
			}
		]
	};
}
function scaling(input, viewT) {
	const a = input.scaleA === 0 ? .2 : input.scaleA;
	const { fn, L, wMax } = input;
	const scaled = (t) => fn(a * t);
	const base = transform(fn, L, N);
	const direct = transform(scaled, L, N);
	const theorem = onGrid(base, (w) => {
		const z = interp(base, w / a);
		const s = 1 / Math.abs(a);
		return {
			re: s * z.re,
			im: s * z.im
		};
	});
	const err = relError(direct, theorem, wMax);
	return {
		formula: "f(at)\\leftrightarrow\\dfrac{1}{|a|}F\\!\\left(\\dfrac{\\omega}{a}\\right)",
		blurb: "时域压窄 a 倍，频谱就展宽 a 倍，高度变成 1/|a|。a<1 时信号会探出观察窗，误差会上来。",
		charts: [{
			title: "时域尺度",
			xLabel: "t",
			data: timeRows(-viewT, viewT, 360, [{
				key: "f",
				fn
			}, {
				key: "s",
				fn: scaled
			}]),
			lines: [{
				key: "f",
				name: "f(t)",
				tone: "muted"
			}, {
				key: "s",
				name: "f(at)",
				tone: "primary"
			}]
		}, {
			title: "频谱展宽",
			xLabel: "ω",
			data: rows2(direct, theorem, wMax, "direct", "theorem"),
			lines: [{
				key: "direct",
				name: "直接变换",
				tone: "primary"
			}, {
				key: "theorem",
				name: "(1/|a|)F(ω/a)",
				tone: "accent",
				dash: true
			}]
		}],
		metrics: [metric("频谱相对误差", err), {
			label: "判读",
			value: toneText(err),
			tone: tone(err)
		}]
	};
}
function modulation(input, viewT) {
	const { fn, L, wMax, wc } = input;
	const mod = (t) => fn(t) * Math.cos(wc * t);
	const base = transform(fn, L, N);
	const direct = transform(mod, L, N);
	const theorem = onGrid(base, (w) => {
		const p = interp(base, w - wc);
		const m = interp(base, w + wc);
		return {
			re: .5 * (p.re + m.re),
			im: .5 * (p.im + m.im)
		};
	});
	const err = relError(direct, theorem, wMax);
	return {
		formula: "f(t)\\cos(\\omega_c t)\\leftrightarrow\\dfrac{1}{2}\\left(F(\\omega-\\omega_c)+F(\\omega+\\omega_c)\\right)",
		blurb: "乘上余弦，频谱被拆成两半，搬到 ±ωc。包络越窄，搬过去的每一团越宽。",
		charts: [{
			title: "被余弦乘过的时域",
			xLabel: "t",
			data: timeRows(-viewT, viewT, 420, [{
				key: "f",
				fn
			}, {
				key: "m",
				fn: mod
			}]),
			lines: [{
				key: "f",
				name: "f(t)",
				tone: "muted"
			}, {
				key: "m",
				name: "f(t)cos(ωc t)",
				tone: "primary"
			}]
		}, {
			title: "频谱搬移",
			xLabel: "ω",
			data: rows2(direct, theorem, wMax, "direct", "theorem"),
			lines: [{
				key: "direct",
				name: "直接变换",
				tone: "primary"
			}, {
				key: "theorem",
				name: "半份左右相加",
				tone: "accent",
				dash: true
			}]
		}],
		metrics: [metric("频谱相对误差", err), {
			label: "判读",
			value: toneText(err),
			tone: tone(err)
		}]
	};
}
function diff(input, viewT) {
	const { fn, L, wMax } = input;
	const h = .001;
	const fp = (t) => (fn(t + h) - fn(t - h)) / (2 * h);
	const base = transform(fn, L, N);
	const direct = transform(fp, L, N);
	const theorem = onGrid(base, (w) => {
		const z = interp(base, w);
		return {
			re: -w * z.im,
			im: w * z.re
		};
	});
	const err = relError(direct, theorem, wMax);
	return {
		formula: "\\dfrac{df}{dt}\\leftrightarrow j\\omega F(\\omega)",
		blurb: "求导等于频谱乘 jω，高频被抬起来。有跳跃的信号导数是冲激，数值差分会失真，换高斯或指数再看。",
		charts: [{
			title: "导数",
			xLabel: "t",
			data: timeRows(-viewT, viewT, 360, [{
				key: "d",
				fn: fp
			}]),
			lines: [{
				key: "d",
				name: "df/dt",
				tone: "primary"
			}]
		}, {
			title: "jωF 对照",
			xLabel: "ω",
			data: rows2(direct, theorem, wMax, "direct", "theorem"),
			lines: [{
				key: "direct",
				name: "|变换后的导数|",
				tone: "primary"
			}, {
				key: "theorem",
				name: "|jωF|",
				tone: "accent",
				dash: true
			}]
		}],
		metrics: [metric("频谱相对误差", err), {
			label: "判读",
			value: toneText(err),
			tone: tone(err)
		}]
	};
}
function conv(input, viewT) {
	const { fn, L, wMax, kernel } = input;
	const width = Math.max(.2, kernel);
	const g = (t) => Math.abs(t) <= width / 2 ? 1 : 0;
	const M = 480;
	const dt = 2 * L / M;
	const fs = new Float64Array(M);
	for (let i = 0; i < M; i++) {
		const y = fn(-L + (i + .5) * dt);
		fs[i] = Number.isFinite(y) ? y : 0;
	}
	const convolved = (t) => {
		let s = 0;
		for (let i = 0; i < M; i++) {
			const tau = -L + (i + .5) * dt;
			s += fs[i] * g(t - tau);
		}
		return s * dt;
	};
	const Fg = transform(g, L, N);
	const Ff = transform(fn, L, N);
	const direct = transform(convolved, L, 1024);
	const theorem = onGrid(direct, (w) => {
		const a = interp(Ff, w);
		const b = interp(Fg, w);
		return {
			re: a.re * b.re - a.im * b.im,
			im: a.re * b.im + a.im * b.re
		};
	});
	const err = relError(direct, theorem, wMax);
	return {
		formula: "(f*g)(t)=\\int f(\\tau)g(t-\\tau)\\,d\\tau\\leftrightarrow F(\\omega)G(\\omega)",
		blurb: "g 是宽为 τk 的矩形。时域卷积对应频谱相乘。信号若在窗边还没衰减完，卷积会被窗切掉一截。",
		charts: [{
			title: "卷积结果",
			xLabel: "t",
			data: timeRows(-viewT, viewT, 280, [{
				key: "f",
				fn
			}, {
				key: "c",
				fn: convolved
			}]),
			lines: [{
				key: "f",
				name: "f(t)",
				tone: "muted"
			}, {
				key: "c",
				name: "f ∗ rect",
				tone: "primary"
			}]
		}, {
			title: "频谱乘积",
			xLabel: "ω",
			data: rows2(direct, theorem, wMax, "direct", "theorem"),
			lines: [{
				key: "direct",
				name: "|变换(f∗g)|",
				tone: "primary"
			}, {
				key: "theorem",
				name: "|FG|",
				tone: "accent",
				dash: true
			}]
		}],
		metrics: [metric("频谱相对误差", err), {
			label: "判读",
			value: toneText(err),
			tone: tone(err)
		}]
	};
}
function symmetry(input, viewT) {
	const { fn, L, wMax } = input;
	const fe = (t) => .5 * (fn(t) + fn(-t));
	const fo = (t) => .5 * (fn(t) - fn(-t));
	const Fe = transform(fe, L, N);
	const Fo = transform(fo, L, N);
	const ratio = (spec, part) => {
		let partE = 0;
		let tot = 0;
		for (let i = 0; i < spec.w.length; i++) {
			if (Math.abs(spec.w[i]) > wMax) continue;
			const re = spec.re[i];
			const im = spec.im[i];
			tot += re * re + im * im;
			partE += part === "re" ? re * re : im * im;
		}
		return partE / Math.max(tot, 1e-18);
	};
	const oddLeak = ratio(Fe, "im");
	const evenLeak = ratio(Fo, "re");
	return {
		formula: "f_e(t)\\leftrightarrow \\operatorname{Re}F(\\omega),\\quad f_o(t)\\leftrightarrow j\\operatorname{Im}F(\\omega)",
		blurb: "任何实信号都能拆成偶部加奇部。偶部只留下实频谱，奇部只留下虚频谱。幅度谱偶、相位谱奇是这件事的另一面。",
		charts: [{
			title: "偶部与奇部",
			xLabel: "t",
			data: timeRows(-viewT, viewT, 360, [{
				key: "e",
				fn: fe
			}, {
				key: "o",
				fn: fo
			}]),
			lines: [{
				key: "e",
				name: "偶部",
				tone: "primary"
			}, {
				key: "o",
				name: "奇部",
				tone: "accent"
			}]
		}, {
			title: "偶部频谱（虚部应贴着 0）",
			xLabel: "ω",
			data: spectrumRows(Fe, wMax, {
				re: "re",
				im: "im"
			}),
			lines: [{
				key: "re",
				name: "实部",
				tone: "primary"
			}, {
				key: "im",
				name: "虚部",
				tone: "accent",
				dash: true
			}]
		}],
		metrics: [
			metric("偶部虚部能量占比", oddLeak),
			metric("奇部实部能量占比", evenLeak),
			{
				label: "判读",
				value: toneText(Math.max(oddLeak, evenLeak)),
				tone: tone(Math.max(oddLeak, evenLeak))
			}
		]
	};
}
function parsevalView(fn, L, wMax) {
	const spec = transform(fn, L, 4096);
	const n = spec.w.length;
	const dt = spec.dt;
	let time = 0;
	for (let i = 0; i < n; i++) {
		const y = fn(-L + i * dt);
		if (Number.isFinite(y)) time += y * y;
	}
	time *= dt;
	const dW = n > 1 ? spec.w[1] - spec.w[0] : 0;
	let acc = 0;
	for (let i = 0; i < n; i++) acc += spec.re[i] * spec.re[i] + spec.im[i] * spec.im[i];
	const freq = acc * dW / (2 * Math.PI);
	const err = Math.abs(time - freq) / Math.max(Math.abs(time), Math.abs(freq), 1e-12);
	const T = 4;
	const ser = fourierSeries(fn, T, 24, 4096);
	const eTime = energy(fn, -2, T / 2, 4e3) / T;
	let eSpec = ser.a0 * ser.a0;
	for (let k = 1; k < ser.an.length; k++) eSpec += (ser.an[k] * ser.an[k] + ser.bn[k] * ser.bn[k]) / 2;
	const fsErr = Math.abs(eTime - eSpec) / Math.max(eTime, 1e-12);
	return {
		formula: "\\int |f|^2\\,dt=\\dfrac{1}{2\\pi}\\int |F|^2\\,d\\omega",
		blurb: "能量在时域和频域是同一笔账。级数那边截到有限项，所以均方只会小于或等于一个周期里的均方，项数加够才补齐。",
		charts: [{
			title: "窗内的 |F(ω)|²",
			subtitle: "频域能量是它的积分再除以 2π",
			xLabel: "ω",
			data: spectrumRows(spec, wMax, { mag: "p" }).map((r) => ({
				x: r.x,
				p: typeof r.p === "number" ? r.p * r.p : null
			})),
			lines: [{
				key: "p",
				name: "|F|²",
				tone: "primary"
			}]
		}],
		metrics: [
			{
				label: "时域能量",
				value: time.toFixed(4),
				tone: "ok"
			},
			{
				label: "频域能量",
				value: freq.toFixed(4),
				tone: "ok"
			},
			metric("变换能量误差", err),
			{
				label: "级数已收能量",
				value: `${(eSpec / Math.max(eTime, 1e-12) * 100).toFixed(1)}%`,
				tone: fsErr < .08 ? "ok" : "warn"
			}
		]
	};
}
function gibbs(harmonics) {
	const T = 2;
	const fn = (t) => {
		const s = Math.sin(2 * Math.PI * t / T);
		return s > 0 ? 1 : s < 0 ? -1 : 0;
	};
	const ser = fourierSeries(fn, T, harmonics, 8192);
	let peak = 0;
	let peakAt = 0;
	const steps = 4e3;
	for (let i = 1; i < steps; i++) {
		const t = i / steps * (T / 2);
		const y = reconstruct(t, ser);
		if (y > peak) {
			peak = y;
			peakAt = t;
		}
	}
	const overshoot = (peak - 1) / 2;
	const near = overshoot > .07 && overshoot < .12;
	return {
		formula: "b_n=\\dfrac{4}{n\\pi}\\ (n\\ \\text{奇}),\\quad \\text{过冲}\\approx 9\\%",
		blurb: "这是周期为 2 的单位方波，用来把间断点看清楚。部分和在跳跃处多冲一截，谐波加再多也只是把过冲挤向间断点，高度停在跳变的大约 9%。",
		charts: [{
			title: "方波与部分和",
			subtitle: `${harmonics} 次谐波`,
			xLabel: "t",
			data: timeRows(-2, 2, 480, [{
				key: "f",
				fn
			}, {
				key: "s",
				fn: (t) => reconstruct(t, ser)
			}]),
			lines: [{
				key: "f",
				name: "方波",
				tone: "muted"
			}, {
				key: "s",
				name: "部分和",
				tone: "primary"
			}]
		}],
		metrics: [
			{
				label: "第一峰高度",
				value: peak.toFixed(3),
				tone: "ok"
			},
			{
				label: "相对整段跳变的过冲",
				value: `${(overshoot * 100).toFixed(1)}%`,
				tone: near || harmonics < 7 ? "ok" : "warn"
			},
			{
				label: "峰的位置 t",
				value: peakAt.toFixed(3),
				tone: "ok"
			},
			{
				label: "判读",
				value: near ? "过冲停在 9% 附近，没有随谐波增加而消失。" : harmonics < 7 ? "谐波还少，过冲还没稳定到 9%。把次数加到 20 以上再看。" : "峰值应接近 1.09。若偏离，检查周期是否为 2。",
				tone: near ? "ok" : "warn"
			}
		]
	};
}
var PRESETS = [
	{
		id: "exp",
		name: "双边指数",
		expr: "A*exp(-a*abs(t))",
		params: {
			A: 1,
			a: 1.2
		},
		half: 8,
		wMax: 16,
		blurb: "偶函数，频谱是实的洛伦兹"
	},
	{
		id: "gauss",
		name: "高斯",
		expr: "A*exp(-a*t^2)",
		params: {
			A: 1,
			a: .8
		},
		half: 6,
		wMax: 14,
		blurb: "变换后仍是高斯"
	},
	{
		id: "rect",
		name: "矩形",
		expr: "A*rect(t/tau)",
		params: {
			A: 1,
			tau: 1.6
		},
		half: 8,
		wMax: 24,
		blurb: "频谱是 sinc"
	},
	{
		id: "tri",
		name: "三角",
		expr: "A*tri(t/tau)",
		params: {
			A: 1,
			tau: 1.6
		},
		half: 8,
		wMax: 24,
		blurb: "频谱是 sinc 的平方"
	},
	{
		id: "causal",
		name: "单边指数",
		expr: "A*exp(-a*t)*u(t)",
		params: {
			A: 1,
			a: 1
		},
		half: 8,
		wMax: 16,
		blurb: "有实部也有虚部"
	},
	{
		id: "tone",
		name: "余弦",
		expr: "A*cos(2*pi*t/T+phi)",
		params: {
			A: 1,
			T: 2,
			phi: 0
		},
		half: 8,
		wMax: 12,
		blurb: "一根谐波，相位随 φ"
	},
	{
		id: "mod",
		name: "调制",
		expr: "A*exp(-a*abs(t))*cos(w*t)",
		params: {
			A: 1,
			a: .9,
			w: 6
		},
		half: 8,
		wMax: 18,
		blurb: "包络谱搬到 ±w"
	},
	{
		id: "square",
		name: "方波",
		expr: "A*sign(sin(2*pi*t/T))",
		params: {
			A: 1,
			T: 2
		},
		half: 6,
		wMax: 30,
		blurb: "只有奇次正弦"
	},
	{
		id: "saw",
		name: "锯齿",
		expr: "A*saw(t/T)",
		params: {
			A: 1,
			T: 2
		},
		half: 6,
		wMax: 30,
		blurb: "正弦项按 1/n 下降"
	},
	{
		id: "sinc",
		name: "sinc",
		expr: "A*sinc(t/tau)",
		params: {
			A: 1,
			tau: .8
		},
		half: 14,
		wMax: 16,
		blurb: "频谱应是矩形"
	},
	{
		id: "dual",
		name: "双音",
		expr: "A*cos(2*pi*t/T)+B*sin(4*pi*t/T)",
		params: {
			A: 1,
			B: .55,
			T: 2
		},
		half: 8,
		wMax: 14,
		blurb: "第 1、2 号谐波"
	}
];
var num = (v) => ({
	k: "num",
	v
});
function norm(e) {
	switch (e.k) {
		case "num":
		case "sym": return e;
		case "call": return {
			k: "call",
			name: e.name,
			args: e.args.map(norm)
		};
		case "pow": {
			const base = norm(e.base);
			const exp = norm(e.exp);
			if (exp.k === "num" && exp.v === 1) return base;
			if (exp.k === "num" && exp.v === 0) return num(1);
			if (base.k === "pow" && exp.k === "num" && base.exp.k === "num") return norm({
				k: "pow",
				base: base.base,
				exp: num(base.exp.v * exp.v)
			});
			if (base.k === "num" && exp.k === "num" && Number.isFinite(Math.pow(base.v, exp.v))) return num(Math.pow(base.v, exp.v));
			return {
				k: "pow",
				base,
				exp
			};
		}
		case "mul": {
			const xs = e.xs.flatMap((x) => {
				const n = norm(x);
				return n.k === "mul" ? n.xs : [n];
			});
			let coef = 1;
			const rest = [];
			for (const x of xs) if (x.k === "num") coef *= x.v;
			else rest.push(x);
			if (!Number.isFinite(coef) || coef === 0) return num(0);
			if (rest.length === 0) return num(coef);
			if (Math.abs(coef - 1) > 1e-15) rest.unshift(num(coef));
			return rest.length === 1 ? rest[0] : {
				k: "mul",
				xs: rest
			};
		}
		case "add": {
			const xs = e.xs.flatMap((x) => {
				const n = norm(x);
				return n.k === "add" ? n.xs : [n];
			});
			let coef = 0;
			const rest = [];
			for (const x of xs) if (x.k === "num") coef += x.v;
			else rest.push(x);
			if (Math.abs(coef) > 1e-15) rest.unshift(num(coef));
			if (rest.length === 0) return num(0);
			return rest.length === 1 ? rest[0] : {
				k: "add",
				xs: rest
			};
		}
	}
}
function fromAst(a) {
	switch (a.t) {
		case "n": return num(a.v);
		case "v": return {
			k: "sym",
			name: a.name
		};
		case "u": return norm({
			k: "mul",
			xs: [num(-1), fromAst(a.a)]
		});
		case "b": {
			const A = fromAst(a.a);
			const B = fromAst(a.b);
			if (a.op === "+") return norm({
				k: "add",
				xs: [A, B]
			});
			if (a.op === "-") return norm({
				k: "add",
				xs: [A, {
					k: "mul",
					xs: [num(-1), B]
				}]
			});
			if (a.op === "*") return norm({
				k: "mul",
				xs: [A, B]
			});
			if (a.op === "/") return norm({
				k: "mul",
				xs: [A, {
					k: "pow",
					base: B,
					exp: num(-1)
				}]
			});
			return norm({
				k: "pow",
				base: A,
				exp: B
			});
		}
		case "c": return norm({
			k: "call",
			name: a.name,
			args: a.args.map(fromAst)
		});
	}
}
function dependsOnT(e) {
	if (e.k === "sym") return e.name === "t";
	if (e.k === "num") return false;
	if (e.k === "add" || e.k === "mul") return e.xs.some(dependsOnT);
	if (e.k === "pow") return dependsOnT(e.base) || dependsOnT(e.exp);
	return e.args.some(dependsOnT);
}
function splitAdd(e) {
	if (e.k === "add") return e.xs.flatMap(splitAdd);
	return [e];
}
function splitMul(e) {
	if (e.k === "mul") return e.xs.flatMap(splitMul);
	if (e.k === "num" && e.v === 1) return [];
	return [e];
}
function mulOf(xs) {
	if (xs.length === 0) return num(1);
	if (xs.length === 1) return xs[0];
	return norm({
		k: "mul",
		xs
	});
}
function addOf(a, b) {
	return norm({
		k: "add",
		xs: [a, b]
	});
}
function mul(a, b) {
	return norm({
		k: "mul",
		xs: [a, b]
	});
}
function neg(e) {
	return mul(num(-1), e);
}
function isPlainT(e) {
	return e.k === "sym" && e.name === "t";
}
function isAbsT(e) {
	if (e.k !== "call" || e.name !== "abs" || e.args.length !== 1) return false;
	const a = e.args[0];
	if (isPlainT(a)) return true;
	if (a.k === "mul" && a.xs.length === 2 && a.xs[0].k === "num" && a.xs[0].v === -1 && isPlainT(a.xs[1])) return true;
	return false;
}
function isTSquared(e) {
	if (e.k === "pow" && isPlainT(e.base) && e.exp.k === "num" && e.exp.v === 2) return true;
	return false;
}
function isUnitStep(e) {
	return e.k === "call" && (e.name === "u" || e.name === "heaviside" || e.name === "step") && e.args.length === 1 && isPlainT(e.args[0]);
}
/** arg = -a * pattern, return a. pattern counted by `hit`. */
function decayCoeff(arg, hit) {
	const factors = splitMul(arg);
	let hits = 0;
	const rest = [];
	for (const f of factors) if (hit(f)) hits++;
	else rest.push(f);
	if (hits !== 1) return null;
	if (rest.some(dependsOnT)) return null;
	return neg(mulOf(rest));
}
function linearT(e) {
	if (isPlainT(e)) return {
		w: num(1),
		phi: num(0)
	};
	if (!dependsOnT(e)) return {
		w: num(0),
		phi: e
	};
	if (e.k === "add") {
		let w = num(0);
		let phi = num(0);
		for (const p of e.xs) {
			const lin = linearT(p);
			if (!lin) return null;
			w = addOf(w, lin.w);
			phi = addOf(phi, lin.phi);
		}
		return {
			w,
			phi
		};
	}
	if (e.k === "mul") {
		const deps = e.xs.filter(dependsOnT);
		const cons = e.xs.filter((x) => !dependsOnT(x));
		if (deps.length !== 1) return null;
		const lin = linearT(deps[0]);
		if (!lin) return null;
		const c = mulOf(cons);
		return {
			w: mul(c, lin.w),
			phi: mul(c, lin.phi)
		};
	}
	return null;
}
function asScaledT(e) {
	const factors = splitMul(e);
	let tcount = 0;
	const rest = [];
	for (const f of factors) if (isPlainT(f)) tcount++;
	else rest.push(f);
	if (tcount !== 1) return null;
	if (rest.some(dependsOnT)) return null;
	return mulOf(rest);
}
function matchTrig(e) {
	if (e.k !== "call" || e.name !== "cos" && e.name !== "sin" || e.args.length !== 1) return null;
	const lin = linearT(e.args[0]);
	if (!lin) return null;
	if (lin.w.k === "num" && Math.abs(lin.w.v) < 1e-15) return null;
	return {
		which: e.name,
		w: lin.w,
		phi: lin.phi
	};
}
function matchPlain(e) {
	if (e.k !== "call") return null;
	if (e.name === "exp" && e.args.length === 1) {
		const aAbs = decayCoeff(e.args[0], isAbsT);
		if (aAbs) return {
			kind: "expabs",
			a: aAbs
		};
		const aG = decayCoeff(e.args[0], isTSquared);
		if (aG) return {
			kind: "gauss",
			a: aG
		};
		return null;
	}
	if ((e.name === "rect" || e.name === "tri" || e.name === "sinc") && e.args.length === 1) {
		const c = asScaledT(e.args[0]);
		if (!c) return null;
		const tau = norm({
			k: "pow",
			base: c,
			exp: num(-1)
		});
		if (e.name === "rect") return {
			kind: "rect",
			tau
		};
		if (e.name === "tri") return {
			kind: "tri",
			tau
		};
		return {
			kind: "sinc",
			tau
		};
	}
	if ((e.name === "sign" || e.name === "sgn") && e.args.length === 1) {
		const inner = e.args[0];
		if (inner.k === "call" && inner.name === "sin" && inner.args.length === 1) {
			const lin = linearT(inner.args[0]);
			if (lin && !(lin.w.k === "num" && Math.abs(lin.w.v) < 1e-15)) return {
				kind: "square",
				w: lin.w,
				phi: lin.phi
			};
		}
		return null;
	}
	if (e.name === "saw" && e.args.length === 1) {
		const c = asScaledT(e.args[0]);
		if (!c) return null;
		return {
			kind: "saw",
			T: norm({
				k: "pow",
				base: c,
				exp: num(-1)
			})
		};
	}
	return null;
}
function isCausalExp(e) {
	if (e.k !== "call" || e.name !== "exp" || e.args.length !== 1) return null;
	return decayCoeff(e.args[0], isPlainT);
}
function productToSum(a, b) {
	const sum = {
		w: addOf(a.w, b.w),
		phi: addOf(a.phi, b.phi)
	};
	const diff = {
		w: addOf(a.w, neg(b.w)),
		phi: addOf(a.phi, neg(b.phi))
	};
	const cos = (lin) => ({
		kind: "cos",
		w: lin.w,
		phi: lin.phi
	});
	const sin = (lin) => ({
		kind: "sin",
		w: lin.w,
		phi: lin.phi
	});
	if (a.which === "cos" && b.which === "cos") return [{
		scale: .5,
		core: cos(sum)
	}, {
		scale: .5,
		core: cos(diff)
	}];
	if (a.which === "sin" && b.which === "sin") return [{
		scale: -.5,
		core: cos(sum)
	}, {
		scale: .5,
		core: cos(diff)
	}];
	if (a.which === "sin" && b.which === "cos") return [{
		scale: .5,
		core: sin(sum)
	}, {
		scale: .5,
		core: sin(diff)
	}];
	return [{
		scale: .5,
		core: sin(sum)
	}, {
		scale: -.5,
		core: sin(diff)
	}];
}
function matchProduct(e) {
	if (!dependsOnT(e)) return [{
		coeff: e,
		core: { kind: "dc" }
	}];
	const factors = splitMul(e);
	const cons = [];
	const deps = [];
	for (const f of factors) (dependsOnT(f) ? deps : cons).push(f);
	const coeff = mulOf(cons);
	const reduced = [];
	let stepped = false;
	for (const d of deps) if (isUnitStep(d)) stepped = true;
	else reduced.push(d);
	if (stepped) {
		const idx = reduced.findIndex((d) => isCausalExp(d));
		if (idx < 0) return null;
		const a = isCausalExp(reduced[idx]);
		if (!a) return null;
		reduced.splice(idx, 1);
		const inner = {
			kind: "cexp",
			a
		};
		if (reduced.length === 0) return [{
			coeff,
			core: inner
		}];
		if (reduced.length === 1) {
			const trig = matchTrig(reduced[0]);
			if (!trig) return null;
			return [{
				coeff,
				core: trig.which === "cos" ? {
					kind: "modcos",
					inner,
					w: trig.w,
					phi: trig.phi
				} : {
					kind: "modsin",
					inner,
					w: trig.w,
					phi: trig.phi
				}
			}];
		}
		return null;
	}
	if (reduced.length === 1) {
		const trig = matchTrig(reduced[0]);
		if (trig) return [{
			coeff,
			core: {
				kind: trig.which,
				w: trig.w,
				phi: trig.phi
			}
		}];
		const plain = matchPlain(reduced[0]);
		if (!plain) return null;
		return [{
			coeff,
			core: plain
		}];
	}
	if (reduced.length === 2) {
		const t1 = matchTrig(reduced[0]);
		const t2 = matchTrig(reduced[1]);
		if (t1 && t2) return productToSum(t1, t2).map((x) => ({
			coeff: mul(coeff, num(x.scale)),
			core: x.core
		}));
		const pair = (trigF, envF) => {
			const trig = matchTrig(trigF);
			const env = matchPlain(envF);
			if (!trig || !env) return null;
			if (env.kind === "square" || env.kind === "saw") return null;
			const inner = env;
			return [{
				coeff,
				core: trig.which === "cos" ? {
					kind: "modcos",
					inner,
					w: trig.w,
					phi: trig.phi
				} : {
					kind: "modsin",
					inner,
					w: trig.w,
					phi: trig.phi
				}
			}];
		};
		return pair(reduced[0], reduced[1]) ?? pair(reduced[1], reduced[0]);
	}
	return null;
}
function isDistributional(core) {
	return core.kind === "dc" || core.kind === "cos" || core.kind === "sin" || core.kind === "square" || core.kind === "saw";
}
var GREEK = {
	pi: "\\pi",
	phi: "\\varphi",
	tau: "\\tau",
	omega: "\\omega",
	alpha: "\\alpha",
	beta: "\\beta",
	gamma: "\\gamma"
};
function peel(e) {
	if (e.k === "num" && e.v < 0) return {
		neg: true,
		rest: num(-e.v)
	};
	if (e.k === "mul" && e.xs[0]?.k === "num" && e.xs[0].v < 0) {
		const v = -e.xs[0].v;
		const restxs = Math.abs(v - 1) < 1e-12 ? e.xs.slice(1) : [num(v), ...e.xs.slice(1)];
		return {
			neg: true,
			rest: restxs.length === 0 ? num(1) : restxs.length === 1 ? restxs[0] : {
				k: "mul",
				xs: restxs
			}
		};
	}
	return {
		neg: false,
		rest: e
	};
}
function latexSym(e) {
	const { neg, rest } = peel(e);
	const body = latexBody(rest);
	return neg ? `-${body}` : body;
}
function joinParts(parts) {
	let s = parts[0] ?? "1";
	for (let i = 1; i < parts.length; i++) {
		const p = parts[i];
		if (/[A-Za-z]$/.test(s) && /^[A-Za-z\\]/.test(p)) s += " ";
		s += p;
	}
	return s;
}
function latexBody(e) {
	if (e.k === "num") {
		if (Number.isInteger(e.v)) return String(e.v);
		return String(Number(e.v.toPrecision(6)));
	}
	if (e.k === "sym") return GREEK[e.name] ?? e.name;
	if (e.k === "pow") {
		if (e.exp.k === "num" && e.exp.v === -1) return `\\frac{1}{${latexAtom(e.base)}}`;
		return `${latexAtom(e.base)}^{${latexSym(e.exp)}}`;
	}
	if (e.k === "mul") {
		const dens = [];
		const tops = [];
		for (const x of e.xs) if (x.k === "pow" && x.exp.k === "num" && x.exp.v < 0 && Number.isInteger(x.exp.v)) {
			if (x.exp.v === -1) dens.push(x.base);
			else dens.push({
				k: "pow",
				base: x.base,
				exp: num(-x.exp.v)
			});
		} else tops.push(x);
		const topS = tops.length ? joinParts(tops.map(latexAtom)) : "1";
		if (!dens.length) return topS;
		return `\\frac{${topS}}{${dens.length === 1 ? latexAtom(dens[0]) : joinParts(dens.map(latexAtom))}}`;
	}
	if (e.k === "add") {
		let s = "";
		e.xs.forEach((x, i) => {
			const p = peel(x);
			const body = latexBody(p.rest);
			if (i === 0) s += p.neg ? `-${body}` : body;
			else s += p.neg ? `-${body}` : `+${body}`;
		});
		return s;
	}
	return `${e.name === "sin" || e.name === "cos" || e.name === "exp" ? `\\${e.name}` : `\\operatorname{${e.name}}`}\\!\\left(${e.args.map(latexSym).join(", ")}\\right)`;
}
function latexAtom(e) {
	if (e.k === "num" || e.k === "sym" || e.k === "call") return latexBody(e);
	if (e.k === "pow" && (e.base.k === "sym" || e.base.k === "num")) return latexBody(e);
	if (e.k === "mul" || e.k === "pow" || e.k === "add") {
		const inner = latexBody(e);
		if (inner.startsWith("\\frac") || inner.startsWith("-")) return `(${inner})`;
		if (e.k === "add") return `(${inner})`;
		return inner;
	}
	return `(${latexBody(e)})`;
}
function isOne(e) {
	return e.k === "num" && Math.abs(e.v - 1) < 1e-12;
}
function wrap(e) {
	const s = latexSym(e);
	if (e.k === "num" || e.k === "sym") return s;
	if (s.startsWith("\\frac")) return s;
	return `(${s})`;
}
function evalSym(e, params) {
	switch (e.k) {
		case "num": return e.v;
		case "sym":
			if (e.name === "pi") return Math.PI;
			if (e.name === "e") return Math.E;
			if (e.name === "t") return NaN;
			return params[e.name] ?? 0;
		case "add": return e.xs.reduce((s, x) => s + evalSym(x, params), 0);
		case "mul": return e.xs.reduce((s, x) => s * evalSym(x, params), 1);
		case "pow": return Math.pow(evalSym(e.base, params), evalSym(e.exp, params));
		case "call": return NaN;
	}
}
function cAdd(a, b) {
	return {
		re: a.re + b.re,
		im: a.im + b.im
	};
}
function cScale(a, s) {
	return {
		re: a.re * s,
		im: a.im * s
	};
}
function cMul(a, b) {
	return {
		re: a.re * b.re - a.im * b.im,
		im: a.re * b.im + a.im * b.re
	};
}
function sinc(x) {
	if (Math.abs(x) < 1e-8) return 1;
	return Math.sin(Math.PI * x) / (Math.PI * x);
}
function evalOrdinary(core, omega, params) {
	if (core.kind === "expabs" || core.kind === "gauss" || core.kind === "cexp") {
		const a = evalSym(core.a, params);
		if (!(a > 0) || !Number.isFinite(a)) return null;
		if (core.kind === "expabs") return {
			re: 2 * a / (a * a + omega * omega),
			im: 0
		};
		if (core.kind === "gauss") return {
			re: Math.sqrt(Math.PI / a) * Math.exp(-(omega * omega) / (4 * a)),
			im: 0
		};
		const den = a * a + omega * omega;
		return {
			re: a / den,
			im: -omega / den
		};
	}
	if (core.kind === "rect" || core.kind === "tri" || core.kind === "sinc") {
		const tau = evalSym(core.tau, params);
		if (!Number.isFinite(tau) || Math.abs(tau) < 1e-9) return null;
		if (core.kind === "rect") return {
			re: Math.abs(tau) * sinc(omega * Math.abs(tau) / (2 * Math.PI)),
			im: 0
		};
		if (core.kind === "tri") {
			const s = sinc(omega * Math.abs(tau) / (2 * Math.PI));
			return {
				re: Math.abs(tau) * s * s,
				im: 0
			};
		}
		const x = Math.abs(omega * tau / (2 * Math.PI));
		return {
			re: x < .5 ? Math.abs(tau) : Math.abs(x - .5) < 1e-8 ? Math.abs(tau) / 2 : 0,
			im: 0
		};
	}
	return null;
}
function evalCore(core, omega, params) {
	if (core.kind === "dc" || core.kind === "cos" || core.kind === "sin" || core.kind === "square" || core.kind === "saw") return null;
	if (core.kind === "modcos" || core.kind === "modsin") {
		const w = evalSym(core.w, params);
		const phi = evalSym(core.phi, params);
		if (!Number.isFinite(w) || !Number.isFinite(phi)) return null;
		const Fp = evalOrdinary(core.inner, omega - w, params);
		const Fm = evalOrdinary(core.inner, omega + w, params);
		if (!Fp || !Fm) return null;
		const ej = {
			re: Math.cos(phi),
			im: Math.sin(phi)
		};
		const ejn = {
			re: Math.cos(phi),
			im: -Math.sin(phi)
		};
		if (core.kind === "modcos") return cScale(cAdd(cMul(ej, Fp), cMul(ejn, Fm)), .5);
		return cMul({
			re: 0,
			im: -.5
		}, cAdd(cMul(ej, Fp), cScale(cMul(ejn, Fm), -1)));
	}
	return evalOrdinary(core, omega, params);
}
function termLatex(term, envelope = false) {
	const C = term.coeff;
	const core = term.core;
	const withC = (body) => isOne(C) ? body : `${latexAtom(C)}\\,${body}`;
	if (core.kind === "dc") return withC("2\\pi\\,\\delta(\\omega)");
	if (core.kind === "expabs") {
		const a = wrap(core.a);
		return `\\dfrac{${isOne(C) ? `2${a}` : `2${a}${latexAtom(C)}`}}{${a}^{2}+\\omega^{2}}`;
	}
	if (core.kind === "gauss") {
		const a = wrap(core.a);
		return withC(`\\sqrt{\\dfrac{\\pi}{${a}}}\\exp\\!\\left(-\\dfrac{\\omega^{2}}{4${a}}\\right)`);
	}
	if (core.kind === "rect") {
		const tau = wrap(core.tau);
		return `${isOne(C) ? tau : `${latexAtom(C)}${tau}`}\\operatorname{sinc}\\!\\left(\\dfrac{\\omega ${tau}}{2\\pi}\\right)`;
	}
	if (core.kind === "tri") {
		const tau = wrap(core.tau);
		return `${isOne(C) ? tau : `${latexAtom(C)}${tau}`}\\operatorname{sinc}^{2}\\!\\left(\\dfrac{\\omega ${tau}}{2\\pi}\\right)`;
	}
	if (core.kind === "cexp") {
		const a = wrap(core.a);
		return `\\dfrac{${isOne(C) ? "1" : latexAtom(C)}}{${a}+j\\omega}`;
	}
	if (core.kind === "sinc") {
		const tau = wrap(core.tau);
		return `${isOne(C) ? `\\left|${tau}\\right|` : `${latexAtom(C)}\\left|${tau}\\right|`}\\operatorname{rect}\\!\\left(\\dfrac{\\omega ${tau}}{2\\pi}\\right)`;
	}
	if (core.kind === "cos" || core.kind === "sin") {
		const w = wrap(core.w);
		const phi = latexSym(core.phi);
		const phi0 = core.phi.k === "num" && Math.abs(core.phi.v) < 1e-12;
		const amp = isOne(C) ? "\\pi" : `${latexAtom(C)}\\pi`;
		if (core.kind === "cos") {
			if (phi0) return `${amp}\\left(\\delta(\\omega-${w})+\\delta(\\omega+${w})\\right)`;
			return `${amp}\\left(e^{j${phi}}\\delta(\\omega-${w})+e^{-j${phi}}\\delta(\\omega+${w})\\right)`;
		}
		if (phi0) return `-j${amp}\\left(\\delta(\\omega-${w})-\\delta(\\omega+${w})\\right)`;
		return `-j${amp}\\left(e^{j${phi}}\\delta(\\omega-${w})-e^{-j${phi}}\\delta(\\omega+${w})\\right)`;
	}
	if (core.kind === "square" || core.kind === "saw") return "2\\pi\\sum_{n} c_n\\delta(\\omega-n\\omega_0)";
	const w = wrap(core.w);
	const phi0 = core.phi.k === "num" && Math.abs(core.phi.v) < 1e-12;
	const env = termLatex({
		coeff: num(1),
		core: core.inner
	}, true);
	const name = envelope ? "G" : "F_1";
	if (core.kind === "modcos") {
		if (phi0) return `\\dfrac{1}{2}${latexAtom(C)}\\left(${name}(\\omega-${w})+${name}(\\omega+${w})\\right)`;
		return `\\dfrac{${latexAtom(C)}}{2}\\left(e^{j${latexSym(core.phi)}}${name}(\\omega-${w})+e^{-j${latexSym(core.phi)}}${name}(\\omega+${w})\\right)`;
	}
	return `${phi0 ? `-\\dfrac{j}{2}${latexAtom(C)}\\left(${name}(\\omega-${w})-${name}(\\omega+${w})\\right)` : `\\dfrac{${latexAtom(C)}}{2j}\\left(e^{j${latexSym(core.phi)}}${name}(\\omega-${w})-e^{-j${latexSym(core.phi)}}${name}(\\omega+${w})\\right)`}\\\\ ${name}(\\omega)=${env}`;
}
function seriesLatexFor(terms) {
	if (terms.length === 1 && terms[0].core.kind === "square") {
		const C = latexAtom(terms[0].coeff);
		const phi = terms[0].core.phi;
		if (phi.k === "num" && Math.abs(phi.v) < 1e-12) return `a_0=0,\\ a_n=0,\\ b_n=\\begin{cases}\\dfrac{4${C}}{n\\pi}& n\\ \\text{奇}\\\\ 0& n\\ \\text{偶}\\end{cases}`;
		return `n\\ \\text{奇时}\\ a_n=\\dfrac{4${C}}{n\\pi}\\sin(n\\varphi),\\ b_n=\\dfrac{4${C}}{n\\pi}\\cos(n\\varphi);\\ n\\ \\text{偶时为}\\ 0`;
	}
	if (terms.length === 1 && terms[0].core.kind === "saw") return `a_0=0,\\ a_n=0,\\ b_n=\\dfrac{2${latexAtom(terms[0].coeff)}(-1)^{n+1}}{n\\pi}`;
	if (terms.every((t) => t.core.kind === "cos" || t.core.kind === "sin") && terms.length > 0) return "若\\ \\omega=n\\omega_0,\\ \\cos(\\omega t+\\varphi)\\ \\text{给出}\\ a_n=A\\cos\\varphi,\\ b_n=-A\\sin\\varphi;\\ \\sin\\ \\text{给出}\\ a_n=A\\sin\\varphi,\\ b_n=A\\cos\\varphi";
	if (terms.every((t) => !isDistributional(t.core) && t.core.kind !== "modcos" && t.core.kind !== "modsin")) return "c_n=\\dfrac{1}{T}F(n\\omega_0),\\quad a_0=c_0,\\ a_n=2\\operatorname{Re}c_n,\\ b_n=-2\\operatorname{Im}c_n";
	if (terms.some((t) => t.core.kind === "modcos" || t.core.kind === "modsin")) return "c_n=\\dfrac{1}{T}F(n\\omega_0)\\ \\text{（信号需几乎落在一个周期内）}";
	return null;
}
function buildFLatex(terms) {
	const chunks = [];
	const extras = [];
	terms.forEach((term, i) => {
		const peeled = peel(term.coeff);
		let piece = termLatex({
			coeff: peeled.rest,
			core: term.core
		});
		const extraIdx = piece.indexOf("\\\\");
		if (extraIdx >= 0) {
			extras.push(piece.slice(extraIdx + 2).trim());
			piece = piece.slice(0, extraIdx).trim();
		}
		const formulaNeg = piece.startsWith("-");
		const body = formulaNeg ? piece.slice(1) : piece;
		const neg = peeled.neg !== formulaNeg;
		if (i === 0) chunks.push(neg ? `-${body}` : body);
		else chunks.push(neg ? `-${body}` : `+${body}`);
	});
	let s = chunks.join("");
	if (extras.length) s += ",\\quad " + extras.join(",\\ ");
	return s;
}
function notesFor(terms) {
	const notes = [];
	if (terms.some((t) => t.core.kind === "cos" || t.core.kind === "sin" || t.core.kind === "dc" || t.core.kind === "square" || t.core.kind === "saw")) notes.push("冲激只在分布意义下成立。数值频谱看到的是观察窗的窄峰，不是无限高的 δ。");
	if (terms.some((t) => t.core.kind === "rect" || t.core.kind === "tri" || t.core.kind === "sinc")) notes.push("\\operatorname{sinc}x=\\sin(\\pi x)/(\\pi x)，\\operatorname{rect} 在 |x|<1/2 为 1。");
	if (terms.some((t) => t.core.kind === "sinc")) notes.push("sinc 拖尾很长，观察窗要开大，数值谱才接近矩形。");
	if (terms.some((t) => t.core.kind === "square")) notes.push("方波级数默认分析周期等于信号周期。只保留奇次正弦项。");
	if (terms.some((t) => t.core.kind === "saw")) notes.push("锯齿波级数默认分析周期等于参量里的周期。");
	return notes;
}
function recognize(ast) {
	const parts = splitAdd(fromAst(ast));
	const terms = [];
	for (const p of parts) {
		if (p.k === "num" && p.v === 0) continue;
		const m = matchProduct(p);
		if (!m) return null;
		terms.push(...m);
	}
	if (terms.length === 0) return null;
	const distributional = terms.some((t) => isDistributional(t.core));
	const ordinaryOnly = terms.every((t) => !isDistributional(t.core));
	return {
		terms,
		fLatex: astToLatex(ast),
		FLatex: buildFLatex(terms),
		seriesLatex: seriesLatexFor(terms),
		distributional,
		notes: notesFor(terms),
		evalAt: (omega, params) => {
			if (!ordinaryOnly) return null;
			let acc = {
				re: 0,
				im: 0
			};
			for (const term of terms) {
				const c = evalSym(term.coeff, params);
				const v = evalCore(term.core, omega, params);
				if (!v || !Number.isFinite(c) || !Number.isFinite(v.re) || !Number.isFinite(v.im)) return null;
				acc = cAdd(acc, cScale(v, c));
			}
			return acc;
		}
	};
}
function liveNote(form, params) {
	if (form.terms.length !== 1) return "这是几项之和。变换按项相加，拖动每一项自己的参量，看它只改自己那一支频谱。";
	const term = form.terms[0];
	const C = evalSym(term.coeff, params);
	const core = term.core;
	if (core.kind === "expabs") return `双边指数。频谱是洛伦兹函数，降到峰值一半时 |ω| = a = ${fmt$1(evalSym(core.a, params))}。a 越大，时域越瘦、频谱越宽。`;
	if (core.kind === "gauss") return `高斯的变换仍是高斯。a = ${fmt$1(evalSym(core.a, params))} 时频域指数是 ω²/(4a)。a 越大，脉冲越窄，频谱越铺开。`;
	if (core.kind === "rect") {
		const tau = evalSym(core.tau, params);
		return `矩形宽 τ = ${fmt$1(tau)}。sinc 的主瓣零点在 ω = ±2π/τ = ±${fmt$1(2 * Math.PI / tau)}。τ 加大，主瓣变窄。`;
	}
	if (core.kind === "tri") {
		const tau = evalSym(core.tau, params);
		return `三角脉冲的频谱是 sinc²，旁瓣比矩形低。零点仍在 2π/τ = ${fmt$1(2 * Math.PI / tau)} 的整数倍。`;
	}
	if (core.kind === "cexp") return `单边指数。F(ω) = 1/(a+jω)，幅度 1/√(a²+ω²)。a = ${fmt$1(evalSym(core.a, params))}，3 dB 点大约在 |ω| = a。`;
	if (core.kind === "sinc") {
		const tau = evalSym(core.tau, params);
		return `sinc 的变换是矩形，截止在 |ω| = π/|τ| = ${fmt$1(Math.PI / Math.abs(tau || 1))}。时域越宽，频域矩形越窄。`;
	}
	if (core.kind === "cos" || core.kind === "sin") {
		const w = evalSym(core.w, params);
		return `永恒${core.kind === "cos" ? "余弦" : "正弦"}在 ±ω = ±${fmt$1(w)} 各有一根冲激。窗内数值谱是两根窄峰，相位由 φ 决定。`;
	}
	if (core.kind === "square") return `方波只含奇次正弦。第一项 b₁ = 4A/π = ${fmt$1(4 * C / Math.PI)}。谐波次数加大，平顶更平，但间断点的过冲不消失。`;
	if (core.kind === "saw") return `锯齿波只有正弦项，bₙ = 2A(−1)^{n+1}/(nπ)。第一项 |b₁| = 2A/π = ${fmt$1(2 * Math.abs(C) / Math.PI)}。`;
	if (core.kind === "modcos" || core.kind === "modsin") return `调制把包络的频谱对半拆开，搬到 ±ωc = ±${fmt$1(evalSym(core.w, params))}。包络越窄，每一团频谱越宽。`;
	return "拖动参量，对照封闭形式和数值曲线。";
}
function fmt$1(n) {
	if (!Number.isFinite(n)) return "—";
	const a = Math.abs(n);
	if (a >= 100) return n.toFixed(1);
	if (a >= 10) return n.toFixed(2);
	return n.toFixed(3);
}
function theoryError(form, w, re, im, params, wMax) {
	let num = 0;
	let den = 0;
	let hit = 0;
	for (let i = 0; i < w.length; i++) {
		if (Math.abs(w[i]) > wMax) continue;
		const th = form.evalAt(w[i], params);
		if (!th) return null;
		const dr = re[i] - th.re;
		const di = im[i] - th.im;
		num += dr * dr + di * di;
		den += th.re * th.re + th.im * th.im + re[i] * re[i] + im[i] * im[i];
		hit++;
	}
	if (!hit) return null;
	return Math.sqrt(num / Math.max(den, 1e-18));
}
var TABS = [
	{
		id: "wave",
		label: "频谱"
	},
	{
		id: "series",
		label: "级数"
	},
	{
		id: "transform",
		label: "变换"
	},
	{
		id: "law",
		label: "性质"
	}
];
var SNIPS = [
	"pi",
	"t",
	"sin(",
	"cos(",
	"exp(",
	"abs(",
	"rect(",
	"tri(",
	"sinc(",
	"u("
];
function fmt(n) {
	if (!Number.isFinite(n)) return "—";
	const a = Math.abs(n);
	if (a < 5e-4) return "0";
	if (a >= 1e3 || a > 0 && a < .001) return n.toExponential(2);
	if (a >= 10) return n.toFixed(2);
	if (a >= 1) return n.toFixed(3);
	return n.toFixed(4);
}
function pct(err) {
	const p = err * 100;
	return `${p < 10 ? p.toFixed(2) : p.toFixed(1)}%`;
}
function FourierLab() {
	const [presetId, setPresetId] = (0, import_react.useState)("exp");
	const [expr, setExpr] = (0, import_react.useState)(PRESETS[0].expr);
	const [params, setParams] = (0, import_react.useState)({ ...PRESETS[0].params });
	const [period, setPeriod] = (0, import_react.useState)(8);
	const [half, setHalf] = (0, import_react.useState)(PRESETS[0].half);
	const [wMax, setWMax] = (0, import_react.useState)(PRESETS[0].wMax);
	const [harmonics, setHarmonics] = (0, import_react.useState)(12);
	const [tab, setTab] = (0, import_react.useState)("wave");
	const [showSum, setShowSum] = (0, import_react.useState)(true);
	const [showPhase, setShowPhase] = (0, import_react.useState)(false);
	const [useDb, setUseDb] = (0, import_react.useState)(false);
	const [law, setLaw] = (0, import_react.useState)("linear");
	const [alpha, setAlpha] = (0, import_react.useState)(1);
	const [beta, setBeta] = (0, import_react.useState)(.7);
	const [gKind, setGKind] = (0, import_react.useState)("gauss");
	const [t0, setT0] = (0, import_react.useState)(.6);
	const [scaleA, setScaleA] = (0, import_react.useState)(1.6);
	const [wc, setWc] = (0, import_react.useState)(5);
	const [kernel, setKernel] = (0, import_react.useState)(1.2);
	const [gibbsN, setGibbsN] = (0, import_react.useState)(21);
	const parsed = (0, import_react.useMemo)(() => {
		try {
			const ast = parse(expr);
			return {
				ast,
				names: collectParams(ast),
				error: null
			};
		} catch (e) {
			return {
				ast: null,
				names: [],
				error: e instanceof Error ? e.message : "无法解析"
			};
		}
	}, [expr]);
	const analysisT = params.T && params.T > .05 ? params.T : period;
	const model = (0, import_react.useMemo)(() => {
		if (!parsed.ast) return null;
		const ast = parsed.ast;
		let bad = 0;
		const fn = (t) => {
			const y = evaluate(ast, t, params);
			if (!Number.isFinite(y)) {
				bad += 1;
				return 0;
			}
			return y;
		};
		const spec = transform(fn, Math.max(.5, half), 4096);
		const ser = fourierSeries(fn, Math.max(.2, analysisT), harmonics, 4096);
		const form = recognize(ast);
		const err = form ? theoryError(form, spec.w, spec.re, spec.im, params, wMax) : null;
		const view = Math.min(Math.max(half, 1), 10);
		const timeFns = { f: fn };
		if (showSum) timeFns.sum = (t) => reconstruct(t, ser);
		const steps = 420;
		const time = [];
		for (let i = 0; i < steps; i++) {
			const x = -view + 2 * view * i / 419;
			const y = fn(x);
			const row = {
				x,
				f: Number.isFinite(y) ? y : null
			};
			if (showSum) row.sum = reconstruct(x, ser);
			time.push(row);
		}
		const eIn = energy(fn, -analysisT / 2, analysisT / 2, 2400);
		const eWin = energy(fn, -half, half, 2400);
		let fsPow = ser.a0 * ser.a0;
		for (let n = 1; n < ser.an.length; n++) fsPow += (ser.an[n] ** 2 + ser.bn[n] ** 2) / 2;
		const outside = eWin > 0 ? Math.max(0, 1 - eIn / eWin) : 1;
		let sampleErr = null;
		if (form && !form.distributional && outside < .12) {
			let num = 0;
			let den = 0;
			for (let n = 0; n < ser.an.length; n++) {
				const th = form.evalAt(n * ser.w0, params);
				if (!th) {
					sampleErr = null;
					break;
				}
				const cRe = n === 0 ? ser.a0 : ser.an[n] / 2;
				const cIm = n === 0 ? 0 : -ser.bn[n] / 2;
				const pRe = th.re / analysisT;
				const pIm = th.im / analysisT;
				num += (cRe - pRe) ** 2 + (cIm - pIm) ** 2;
				den += cRe * cRe + cIm * cIm + pRe * pRe + pIm * pIm;
				sampleErr = Math.sqrt(num / Math.max(den, 1e-18));
			}
		}
		let peak = 0;
		let peakW = 0;
		for (let i = 0; i < spec.w.length; i++) {
			if (Math.abs(spec.w[i]) > wMax) continue;
			const m = Math.hypot(spec.re[i], spec.im[i]);
			if (m > peak) {
				peak = m;
				peakW = spec.w[i];
			}
		}
		const rows = spectrumRows(spec, wMax, {
			mag: "mag",
			phase: "phase",
			re: "re",
			im: "im"
		});
		const magRows = rows.map((r) => ({
			x: r.x,
			y: useDb && peak > 0 && typeof r.mag === "number" ? 20 * Math.log10((r.mag + 1e-12) / peak) : r.mag ?? null
		}));
		return {
			fn,
			bad,
			spec,
			ser,
			form,
			err,
			time,
			magRows,
			phaseRows: rows.map((r) => ({
				x: r.x,
				phase: r.phase
			})),
			partRows: rows.map((r) => ({
				x: r.x,
				re: r.re,
				im: r.im
			})),
			eIn,
			fsPow,
			outside,
			sampleErr,
			peak,
			peakW,
			view
		};
	}, [
		parsed.ast,
		params,
		half,
		analysisT,
		harmonics,
		wMax,
		showSum,
		useDb
	]);
	const experiment = (0, import_react.useMemo)(() => {
		if (tab !== "law" || !model) return null;
		return runExperiment({
			id: law,
			fn: model.fn,
			L: Math.max(half, 1),
			wMax,
			alpha,
			beta,
			gKind,
			t0,
			scaleA,
			wc,
			kernel,
			gibbsN
		});
	}, [
		tab,
		model,
		law,
		half,
		wMax,
		alpha,
		beta,
		gKind,
		t0,
		scaleA,
		wc,
		kernel,
		gibbsN
	]);
	function updateExpr(next) {
		setExpr(next);
		setPresetId("custom");
		try {
			const names = collectParams(parse(next));
			setParams((prev) => {
				const merged = {};
				for (const name of names) merged[name] = prev[name] ?? defaultParam(name);
				return merged;
			});
		} catch {}
	}
	function applyPreset(id) {
		const preset = PRESETS.find((p) => p.id === id);
		if (!preset) return;
		setPresetId(preset.id);
		setExpr(preset.expr);
		setParams({ ...preset.params });
		setHalf(preset.half);
		setWMax(preset.wMax);
		setPeriod(preset.params.T ?? 8);
	}
	const timeLines = showSum ? [{
		key: "f",
		name: "f(t)",
		tone: "primary"
	}, {
		key: "sum",
		name: "级数部分和",
		tone: "accent",
		dash: true
	}] : [{
		key: "f",
		name: "f(t)",
		tone: "primary"
	}];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "border-b border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-col gap-2 px-4 py-4 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-widest text-primary",
					children: "FOURIER BENCH"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl leading-tight text-balance",
					children: "傅里叶性质台"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-md text-sm text-pretty text-muted",
					children: "写下 f(t)，读出级数和变换。再拧参量，看线性、时移、尺度这些定理还成不成立。"
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-4 px-4 py-4 pb-24 lg:grid-cols-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "min-w-0 lg:col-span-4 lg:sticky lg:top-4 lg:max-h-[calc(100dvh-2rem)] lg:overflow-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-4 rounded-xl border border-border border-t-2 border-t-primary bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium",
							children: "信号"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: PRESETS.map((preset) => {
								const on = preset.id === presetId;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => applyPreset(preset.id),
									className: on ? "min-h-11 rounded-full bg-primary px-3 text-sm font-medium text-primary-fg" : "min-h-11 rounded-full border border-border bg-surface-2 px-3 text-sm text-fg",
									children: preset.name
								}, preset.id);
							})
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted",
								children: "f(t)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								id: "expr",
								value: expr,
								spellCheck: false,
								rows: 3,
								onChange: (e) => updateExpr(e.target.value),
								className: "mt-1 w-full resize-y rounded-lg border border-border bg-surface-2 px-3 py-3 font-mono text-sm text-fg outline-none focus-visible:ring-2 focus-visible:ring-primary"
							})]
						}),
						parsed.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-danger",
							children: parsed.error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: SNIPS.map((snip) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => updateExpr(expr.trim() ? `${expr}*${snip}` : snip),
								className: "min-h-11 rounded-lg border border-border bg-surface-2 px-3 text-sm text-muted",
								children: snip.replace("(", "")
							}, snip))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
							className: "text-sm text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
								className: "min-h-11 cursor-pointer py-2 text-fg",
								children: "表达式怎么写"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-pretty",
								children: "变量是 t，常数是 pi 和 e。乘号可以省：2pi t、A cos(w t)。函数有 sin、cos、exp、abs、sqrt、sign、rect、tri、sinc、u、saw。 rect(t/τ) 在半宽 τ/2 以内为 1；tri(t/τ) 底宽 2τ；sinc(0)=1；saw(t/T) 在一个周期里从 −1 升到 1。"
							})]
						}),
						parsed.names.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-medium",
								children: "参量"
							}), parsed.names.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								label: name,
								value: params[name] ?? defaultParam(name),
								onChange: (value) => setParams((prev) => ({
									...prev,
									[name]: value
								})),
								...sliderRange(name, params[name] ?? defaultParam(name))
							}, name))]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-medium",
									children: "分析"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
									label: "观察窗半宽 L",
									value: half,
									min: 1,
									max: 20,
									step: .1,
									onChange: setHalf
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
									label: "频率显示 ±ω",
									value: wMax,
									min: 2,
									max: 40,
									step: .5,
									onChange: setWMax
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
									label: "谐波个数",
									value: harmonics,
									min: 1,
									max: 40,
									step: 1,
									onChange: setHarmonics
								}),
								"T" in params ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
									label: "级数周期",
									value: period,
									min: .5,
									max: 16,
									step: .1,
									onChange: setPeriod
								})
							]
						})
					]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex min-w-0 flex-col gap-4 lg:col-span-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2 overflow-x-auto",
					role: "tablist",
					children: TABS.map((item) => {
						const on = tab === item.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							role: "tab",
							"aria-selected": on,
							onClick: () => setTab(item.id),
							className: on ? "min-h-11 shrink-0 rounded-full bg-primary px-4 text-sm font-medium text-primary-fg" : "min-h-11 shrink-0 rounded-full border border-border bg-surface px-4 text-sm text-fg",
							children: item.label
						}, item.id);
					})
				}), model ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "直流 a0",
								value: fmt(model.ser.a0)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "主峰 |F|",
								value: fmt(model.peak)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "主峰位置 ω",
								value: fmt(model.peakW)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "封闭形式误差",
								value: model.err === null ? "分布" : pct(model.err)
							})
						]
					}),
					model.bad > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-primary",
						children: "有些时刻表达式没有定义，这些点按 0 计入积分。"
					}) : null,
					tab === "wave" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WavePane, {
						model,
						timeLines,
						useDb,
						showPhase,
						showSum,
						setUseDb,
						setShowPhase,
						setShowSum
					}) : null,
					tab === "series" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeriesPane, {
						model,
						T: analysisT
					}) : null,
					tab === "transform" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TransformPane, {
						model,
						params
					}) : null,
					tab === "law" && experiment ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LawPane, {
						law,
						setLaw,
						view: experiment,
						alpha,
						setAlpha,
						beta,
						setBeta,
						gKind,
						setGKind,
						t0,
						setT0,
						scaleA,
						setScaleA,
						wc,
						setWc,
						kernel,
						setKernel,
						gibbsN,
						setGibbsN
					}) : null
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-xl border border-border bg-surface p-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "表达式还不能计算。改对之后，时域、级数和频谱会一起出现。"
					})
				})]
			})]
		})]
	});
}
function Slider({ label, value, min, max, step, onChange }) {
	const shown = Number.isFinite(value) ? value : min;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex items-baseline justify-between gap-3 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "tabular-nums text-primary",
				children: fmt(shown)
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "range",
			min,
			max,
			step,
			value: Math.min(max, Math.max(min, shown)),
			"aria-label": label,
			onChange: (e) => onChange(Number(e.target.value)),
			className: "mt-1 h-11 w-full"
		})]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-surface px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 truncate text-lg tabular-nums",
			children: value
		})]
	});
}
function WavePane({ model, timeLines, useDb, showPhase, showSum, setUseDb, setShowPhase, setShowSum }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						on: showSum,
						onClick: () => setShowSum(!showSum),
						label: "叠上部分和"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						on: showPhase,
						onClick: () => setShowPhase(!showPhase),
						label: "相位"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						on: useDb,
						onClick: () => setUseDb(!useDb),
						label: "相对 dB"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinePlot, {
				title: "时域",
				subtitle: `显示 ±${fmt(model.view)}`,
				xLabel: "t",
				data: model.time,
				lines: timeLines
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinePlot, {
				title: useDb ? "幅度谱（相对主峰）" : "幅度谱",
				subtitle: "数值积分，窗为 [−L, L]",
				xLabel: "ω",
				data: model.magRows,
				lines: [{
					key: "y",
					name: useDb ? "dB" : "|F(ω)|",
					tone: "primary"
				}]
			}),
			showPhase ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinePlot, {
				title: "相位",
				xLabel: "ω",
				data: model.phaseRows,
				lines: [{
					key: "phase",
					name: "arg F",
					tone: "accent"
				}],
				yDomain: [-3.2, 3.2]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-pretty text-muted",
				children: "数值频谱是观察窗里的积分。脉冲若在窗边已经消失，它就接近无限长时间的变换；永远不停的正弦会被窗切成窄峰，而不是理想冲激。"
			})
		]
	});
}
function SeriesPane({ model, T }) {
	const rows = [];
	for (let n = 1; n < model.ser.an.length; n++) {
		const an = model.ser.an[n];
		const bn = model.ser.bn[n];
		const re = an / 2;
		const im = -bn / 2;
		rows.push({
			n,
			an,
			bn,
			mag: Math.hypot(re, im),
			arg: Math.atan2(im, re)
		});
	}
	const mean = model.eIn / T;
	const captured = mean > 1e-8 ? model.fsPow / mean : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-xl border border-border bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "一个周期上的三角级数"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tex, {
						display: true,
						source: `f(t)\\sim a_0+\\sum_{n=1}^{N}(a_n\\cos n\\omega_0 t+b_n\\sin n\\omega_0 t),\\ \\omega_0=\\frac{2\\pi}{T},\\ T=${fmt(T)}`
					}),
					model.form?.seriesLatex ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tex, {
						display: true,
						source: model.form.seriesLatex
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "没有配上封闭系数。表里是数值积分，照样能用。"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-pretty text-muted",
						children: "a0 是周期平均值。n≥1 时 an、bn 用 2/T 归一，这样部分和直接相加就回到波形。复数系数 c0=a0，cn=(an−j bn)/2。"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "周期均方",
						value: fmt(mean)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "级数已收能量",
						value: pct(captured)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "窗外汇占总能量",
						value: pct(model.outside)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-pretty text-muted",
				children: model.form?.distributional ? "这条信号的变换里有冲激列。表上的系数就是那些冲激的重量，不要把它当成一条连续曲线的采样。" : model.sampleErr === null ? "信号伸到了一个周期外面，cn 就不是整条 F(ω) 的采样。把级数周期加大，让脉冲几乎落在一个周期里，再看这条关系。" : `在这个周期里信号几乎衰减完，所以 cn ≈ F(nω0)/T。相对误差 ${pct(model.sampleErr)}。`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HarmonicBars, { data: rows.map((r) => ({
				n: r.n,
				an: r.an,
				bn: r.bn
			})) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-xl border border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[28rem] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-surface-2 text-xs text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "n"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "an"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "bn"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "|cn|"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "arg cn"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 tabular-nums",
								children: r.n
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 tabular-nums",
								children: fmt(r.an)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 tabular-nums",
								children: fmt(r.bn)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 tabular-nums",
								children: fmt(r.mag)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 tabular-nums",
								children: fmt(r.arg)
							})
						]
					}, r.n)) })]
				})
			})
		]
	});
}
function TransformPane({ model, params }) {
	const form = model.form;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-xl border border-border bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "约定"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tex, {
						display: true,
						source: "F(\\\\omega)=\\\\int_{-\\\\infty}^{\\\\infty} f(t)e^{-j\\\\omega t}\\\\,dt"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-pretty text-muted",
						children: "角频率。反变换前面带 1/2π，所以尺度定理是 1/|a|，帕塞瓦尔也带 1/2π。"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-xl border border-border bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "f(t) 与 F(ω)"
					}),
					form ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tex, {
							display: true,
							source: `f(t)=${form.fLatex}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tex, {
							display: true,
							source: `F(\\omega)=${form.FLatex}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-pretty text-fg",
							children: liveNote(form, params)
						}),
						form.notes.map((note) => note.includes("\\") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tex, {
							display: true,
							source: note
						}, note) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-pretty text-muted",
							children: note
						}, note))
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-pretty text-muted",
						children: "这个式子没有自动配上封闭形式。下面的频谱仍是数值积分，性质实验照样拿它做对照。"
					}),
					model.err !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm text-accent",
						children: [
							"封闭形式和数值谱的相对误差 ",
							pct(model.err),
							"。改参量时两边应当一起动。"
						]
					}) : form ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "这里含有冲激，不能逐点跟数值谱比高低，只能比峰的位置和级数系数。"
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinePlot, {
				title: "实部与虚部",
				xLabel: "ω",
				data: model.partRows,
				lines: [{
					key: "re",
					name: "实部",
					tone: "primary"
				}, {
					key: "im",
					name: "虚部",
					tone: "accent",
					dash: true
				}]
			})
		]
	});
}
function LawPane(props) {
	const { view } = props;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2 sm:grid-cols-3",
				children: EXPERIMENTS.map((item) => {
					const on = props.law === item.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => props.setLaw(item.id),
						className: on ? "min-h-11 rounded-xl bg-primary px-3 text-left text-sm font-medium text-primary-fg" : "min-h-11 rounded-xl border border-border bg-surface px-3 text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mr-2 tabular-nums opacity-70",
							children: item.index
						}), item.label]
					}, item.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-xl border border-border bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tex, {
					display: true,
					source: view.formula
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-pretty text-muted",
					children: view.blurb
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-border bg-surface p-4",
				children: [
					props.law === "linear" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-sm",
								children: ["第二条信号", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: props.gKind,
									onChange: (e) => props.setGKind(e.target.value),
									className: "mt-1 h-11 w-full rounded-lg border border-border bg-surface-2 px-3 text-fg",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "gauss",
											children: "高斯"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "rect",
											children: "矩形"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "exp",
											children: "单边指数"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								label: "α",
								value: props.alpha,
								min: -1.5,
								max: 2,
								step: .05,
								onChange: props.setAlpha
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								label: "β",
								value: props.beta,
								min: -1.5,
								max: 2,
								step: .05,
								onChange: props.setBeta
							})
						]
					}) : null,
					props.law === "shift" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						label: "平移 t0",
						value: props.t0,
						min: -2,
						max: 2,
						step: .05,
						onChange: props.setT0
					}) : null,
					props.law === "scale" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						label: "尺度 a",
						value: props.scaleA,
						min: .4,
						max: 3,
						step: .05,
						onChange: props.setScaleA
					}) : null,
					props.law === "mod" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						label: "载波 ωc",
						value: props.wc,
						min: 0,
						max: 14,
						step: .1,
						onChange: props.setWc
					}) : null,
					props.law === "conv" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						label: "矩形核宽度",
						value: props.kernel,
						min: .3,
						max: 4,
						step: .05,
						onChange: props.setKernel
					}) : null,
					props.law === "gibbs" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						label: "方波谐波次数",
						value: props.gibbsN,
						min: 1,
						max: 48,
						step: 1,
						onChange: props.setGibbsN
					}) : null,
					props.law === "diff" || props.law === "sym" || props.law === "parseval" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "这一条跟着左侧的 f(t) 和观察窗走。换信号或加大 L，误差会跟着变。"
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2 sm:grid-cols-2",
				children: view.metrics.map((metric) => metric.value.length > 28 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: `text-sm text-pretty sm:col-span-2 ${toneClass(metric.tone)}`,
					children: metric.value
				}, metric.label) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: metric.label,
					value: metric.value
				}, metric.label))
			}),
			view.charts.map((chart) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinePlot, {
				title: chart.title,
				subtitle: chart.subtitle,
				xLabel: chart.xLabel,
				data: chart.data,
				lines: chart.lines
			}, chart.title))
		]
	});
}
function toneClass(tone) {
	if (tone === "ok") return "text-accent";
	if (tone === "warn") return "text-primary";
	return "text-danger";
}
function Toggle({ on, onClick, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": on,
		onClick,
		className: on ? "min-h-11 rounded-full bg-surface-2 px-4 text-sm text-primary" : "min-h-11 rounded-full border border-border px-4 text-sm text-muted",
		children: label
	});
}
var SplitComponent = FourierLab;
//#endregion
export { SplitComponent as component };
