import { useMemo, useState } from "react";
import { HarmonicBars, LinePlot, type PlotLine } from "@/components/fourier/charts";
import { Tex } from "@/components/fourier/tex";
import {
  collectParams,
  defaultParam,
  evaluate,
  parse,
  sliderRange,
  type Ast,
} from "@/lib/fourier/expr";
import { energy, fourierSeries, reconstruct, spectrumRows, transform, type Series } from "@/lib/fourier/num";
import { EXPERIMENTS, runExperiment, type ExperimentId } from "@/lib/fourier/properties";
import { PRESETS } from "@/lib/fourier/presets";
import { liveNote, recognize, theoryError, type ClosedForm } from "@/lib/fourier/symbolic";

type Tab = "wave" | "series" | "transform" | "law";

const TABS: { id: Tab; label: string }[] = [
  { id: "wave", label: "频谱" },
  { id: "series", label: "级数" },
  { id: "transform", label: "变换" },
  { id: "law", label: "性质" },
];

const SNIPS = ["pi", "t", "sin(", "cos(", "exp(", "abs(", "rect(", "tri(", "sinc(", "u("];

function fmt(n: number): string {
  if (!Number.isFinite(n)) return "—";
  const a = Math.abs(n);
  if (a < 5e-4) return "0";
  if (a >= 1000 || (a > 0 && a < 0.001)) return n.toExponential(2);
  if (a >= 10) return n.toFixed(2);
  if (a >= 1) return n.toFixed(3);
  return n.toFixed(4);
}

function pct(err: number): string {
  const p = err * 100;
  return `${p < 10 ? p.toFixed(2) : p.toFixed(1)}%`;
}

export function FourierLab() {
  const [presetId, setPresetId] = useState("exp");
  const [expr, setExpr] = useState(PRESETS[0].expr);
  const [params, setParams] = useState<Record<string, number>>({ ...PRESETS[0].params });
  const [period, setPeriod] = useState(8);
  const [half, setHalf] = useState(PRESETS[0].half);
  const [wMax, setWMax] = useState(PRESETS[0].wMax);
  const [harmonics, setHarmonics] = useState(12);
  const [tab, setTab] = useState<Tab>("wave");
  const [showSum, setShowSum] = useState(true);
  const [showPhase, setShowPhase] = useState(false);
  const [useDb, setUseDb] = useState(false);
  const [law, setLaw] = useState<ExperimentId>("linear");
  const [alpha, setAlpha] = useState(1);
  const [beta, setBeta] = useState(0.7);
  const [gKind, setGKind] = useState<"gauss" | "rect" | "exp">("gauss");
  const [t0, setT0] = useState(0.6);
  const [scaleA, setScaleA] = useState(1.6);
  const [wc, setWc] = useState(5);
  const [kernel, setKernel] = useState(1.2);
  const [gibbsN, setGibbsN] = useState(21);

  const parsed = useMemo(() => {
    try {
      const ast = parse(expr);
      return { ast, names: collectParams(ast), error: null as string | null };
    } catch (e) {
      return { ast: null as Ast | null, names: [] as string[], error: e instanceof Error ? e.message : "无法解析" };
    }
  }, [expr]);

  const analysisT = params.T && params.T > 0.05 ? params.T : period;

  const model = useMemo(() => {
    if (!parsed.ast) return null;
    const ast = parsed.ast;
    let bad = 0;
    const fn = (t: number) => {
      const y = evaluate(ast, t, params);
      if (!Number.isFinite(y)) {
        bad += 1;
        return 0;
      }
      return y;
    };
    const spec = transform(fn, Math.max(0.5, half), 4096);
    const ser = fourierSeries(fn, Math.max(0.2, analysisT), harmonics, 4096);
    const form = recognize(ast);
    const err = form ? theoryError(form, spec.w, spec.re, spec.im, params, wMax) : null;
    const view = Math.min(Math.max(half, 1), 10);
    const timeFns: Record<string, (t: number) => number> = { f: fn };
    if (showSum) timeFns.sum = (t) => reconstruct(t, ser);
    const steps = 420;
    const time: Record<string, number | null>[] = [];
    for (let i = 0; i < steps; i++) {
      const x = -view + (2 * view * i) / (steps - 1);
      const y = fn(x);
      const row: Record<string, number | null> = { x, f: Number.isFinite(y) ? y : null };
      if (showSum) row.sum = reconstruct(x, ser);
      time.push(row);
    }
    const eIn = energy(fn, -analysisT / 2, analysisT / 2, 2400);
    const eWin = energy(fn, -half, half, 2400);
    let fsPow = ser.a0 * ser.a0;
    for (let n = 1; n < ser.an.length; n++) fsPow += (ser.an[n] ** 2 + ser.bn[n] ** 2) / 2;
    const outside = eWin > 0 ? Math.max(0, 1 - eIn / eWin) : 1;
    let sampleErr: number | null = null;
    if (form && !form.distributional && outside < 0.12) {
      let num = 0;
      let den = 0;
      for (let n = 0; n < ser.an.length; n++) {
        const th = form.evalAt(n * ser.w0, params);
        if (!th) {
          sampleErr = null;
          break;
        }
        const cRe = n === 0 ? ser.a0 : ser.an[n] / 2;
        const cIm = n === 0 ? 0 : -ser.bn[n] / 2;
        const pRe = th.re / analysisT;
        const pIm = th.im / analysisT;
        num += (cRe - pRe) ** 2 + (cIm - pIm) ** 2;
        den += cRe * cRe + cIm * cIm + pRe * pRe + pIm * pIm;
        sampleErr = Math.sqrt(num / Math.max(den, 1e-18));
      }
    }
    let peak = 0;
    let peakW = 0;
    for (let i = 0; i < spec.w.length; i++) {
      if (Math.abs(spec.w[i]) > wMax) continue;
      const m = Math.hypot(spec.re[i], spec.im[i]);
      if (m > peak) {
        peak = m;
        peakW = spec.w[i];
      }
    }
    const rows = spectrumRows(spec, wMax, { mag: "mag", phase: "phase", re: "re", im: "im" });
    const magRows = rows.map((r) => ({
      x: r.x,
      y:
        useDb && peak > 0 && typeof r.mag === "number"
          ? 20 * Math.log10((r.mag + 1e-12) / peak)
          : (r.mag ?? null),
    }));
    return {
      fn,
      bad,
      spec,
      ser,
      form,
      err,
      time,
      magRows,
      phaseRows: rows.map((r) => ({ x: r.x, phase: r.phase })),
      partRows: rows.map((r) => ({ x: r.x, re: r.re, im: r.im })),
      eIn,
      fsPow,
      outside,
      sampleErr,
      peak,
      peakW,
      view,
    };
  }, [parsed.ast, params, half, analysisT, harmonics, wMax, showSum, useDb]);

  const experiment = useMemo(() => {
    if (tab !== "law" || !model) return null;
    return runExperiment({
      id: law,
      fn: model.fn,
      L: Math.max(half, 1),
      wMax,
      alpha,
      beta,
      gKind,
      t0,
      scaleA,
      wc,
      kernel,
      gibbsN,
    });
  }, [tab, model, law, half, wMax, alpha, beta, gKind, t0, scaleA, wc, kernel, gibbsN]);

  function updateExpr(next: string) {
    setExpr(next);
    setPresetId("custom");
    try {
      const names = collectParams(parse(next));
      setParams((prev) => {
        const merged: Record<string, number> = {};
        for (const name of names) merged[name] = prev[name] ?? defaultParam(name);
        return merged;
      });
    } catch {
      /* keep the last good parameters */
    }
  }

  function applyPreset(id: string) {
    const preset = PRESETS.find((p) => p.id === id);
    if (!preset) return;
    setPresetId(preset.id);
    setExpr(preset.expr);
    setParams({ ...preset.params });
    setHalf(preset.half);
    setWMax(preset.wMax);
    setPeriod(preset.params.T ?? 8);
  }

  const timeLines: PlotLine[] = showSum
    ? [
        { key: "f", name: "f(t)", tone: "primary" },
        { key: "sum", name: "级数部分和", tone: "accent", dash: true },
      ]
    : [{ key: "f", name: "f(t)", tone: "primary" }];

  return (
    <main className="min-h-screen bg-bg text-fg">
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-4 py-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-xs font-medium tracking-widest text-primary">FOURIER BENCH</p>
            <h1 className="font-display text-3xl leading-tight text-balance">傅里叶性质台</h1>
          </div>
          <p className="max-w-md text-sm text-pretty text-muted">
            写下 f(t)，读出级数和变换。再拧参量，看线性、时移、尺度这些定理还成不成立。
          </p>
        </div>
      </header>

      <div className="mx-auto grid max-w-6xl gap-4 px-4 py-4 pb-24 lg:grid-cols-12">
        <section className="min-w-0 lg:col-span-4 lg:sticky lg:top-4 lg:max-h-[calc(100dvh-2rem)] lg:overflow-auto">
          <div className="flex flex-col gap-4 rounded-xl border border-border border-t-2 border-t-primary bg-surface p-4">
            <div>
              <h2 className="text-sm font-medium">信号</h2>
              <div className="mt-3 flex flex-wrap gap-2">
                {PRESETS.map((preset) => {
                  const on = preset.id === presetId;
                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => applyPreset(preset.id)}
                      className={
                        on
                          ? "min-h-11 rounded-full bg-primary px-3 text-sm font-medium text-primary-fg"
                          : "min-h-11 rounded-full border border-border bg-surface-2 px-3 text-sm text-fg"
                      }
                    >
                      {preset.name}
                    </button>
                  );
                })}
              </div>
            </div>

            <label className="block">
              <span className="text-xs text-muted">f(t)</span>
              <textarea
                id="expr"
                value={expr}
                spellCheck={false}
                rows={3}
                onChange={(e) => updateExpr(e.target.value)}
                className="mt-1 w-full resize-y rounded-lg border border-border bg-surface-2 px-3 py-3 font-mono text-sm text-fg outline-none focus-visible:ring-2 focus-visible:ring-primary"
              />
            </label>
            {parsed.error ? <p className="text-sm text-danger">{parsed.error}</p> : null}
            <div className="flex flex-wrap gap-2">
              {SNIPS.map((snip) => (
                <button
                  key={snip}
                  type="button"
                  onClick={() => updateExpr(expr.trim() ? `${expr}*${snip}` : snip)}
                  className="min-h-11 rounded-lg border border-border bg-surface-2 px-3 text-sm text-muted"
                >
                  {snip.replace("(", "")}
                </button>
              ))}
            </div>
            <details className="text-sm text-muted">
              <summary className="min-h-11 cursor-pointer py-2 text-fg">表达式怎么写</summary>
              <p className="text-pretty">
                变量是 t，常数是 pi 和 e。乘号可以省：2pi t、A cos(w t)。函数有 sin、cos、exp、abs、sqrt、sign、rect、tri、sinc、u、saw。
                rect(t/τ) 在半宽 τ/2 以内为 1；tri(t/τ) 底宽 2τ；sinc(0)=1；saw(t/T) 在一个周期里从 −1 升到 1。
              </p>
            </details>

            {parsed.names.length > 0 ? (
              <div className="flex flex-col gap-3">
                <h2 className="text-sm font-medium">参量</h2>
                {parsed.names.map((name) => (
                  <Slider
                    key={name}
                    label={name}
                    value={params[name] ?? defaultParam(name)}
                    onChange={(value) => setParams((prev) => ({ ...prev, [name]: value }))}
                    {...sliderRange(name, params[name] ?? defaultParam(name))}
                  />
                ))}
              </div>
            ) : null}

            <div className="flex flex-col gap-3">
              <h2 className="text-sm font-medium">分析</h2>
              <Slider label="观察窗半宽 L" value={half} min={1} max={20} step={0.1} onChange={setHalf} />
              <Slider label="频率显示 ±ω" value={wMax} min={2} max={40} step={0.5} onChange={setWMax} />
              <Slider label="谐波个数" value={harmonics} min={1} max={40} step={1} onChange={setHarmonics} />
              {"T" in params ? null : (
                <Slider label="级数周期" value={period} min={0.5} max={16} step={0.1} onChange={setPeriod} />
              )}
            </div>
          </div>
        </section>

        <section className="flex min-w-0 flex-col gap-4 lg:col-span-8">
          <div className="flex gap-2 overflow-x-auto" role="tablist">
            {TABS.map((item) => {
              const on = tab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  role="tab"
                  aria-selected={on}
                  onClick={() => setTab(item.id)}
                  className={
                    on
                      ? "min-h-11 shrink-0 rounded-full bg-primary px-4 text-sm font-medium text-primary-fg"
                      : "min-h-11 shrink-0 rounded-full border border-border bg-surface px-4 text-sm text-fg"
                  }
                >
                  {item.label}
                </button>
              );
            })}
          </div>

          {model ? (
            <>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                <Stat label="直流 a0" value={fmt(model.ser.a0)} />
                <Stat label="主峰 |F|" value={fmt(model.peak)} />
                <Stat label="主峰位置 ω" value={fmt(model.peakW)} />
                <Stat
                  label="封闭形式误差"
                  value={model.err === null ? "分布" : pct(model.err)}
                />
              </div>
              {model.bad > 0 ? (
                <p className="text-sm text-primary">有些时刻表达式没有定义，这些点按 0 计入积分。</p>
              ) : null}

              {tab === "wave" ? (
                <WavePane model={model} timeLines={timeLines} useDb={useDb} showPhase={showPhase} showSum={showSum} setUseDb={setUseDb} setShowPhase={setShowPhase} setShowSum={setShowSum} />
              ) : null}
              {tab === "series" ? <SeriesPane model={model} T={analysisT} /> : null}
              {tab === "transform" ? <TransformPane model={model} params={params} /> : null}
              {tab === "law" && experiment ? (
                <LawPane
                  law={law}
                  setLaw={setLaw}
                  view={experiment}
                  alpha={alpha}
                  setAlpha={setAlpha}
                  beta={beta}
                  setBeta={setBeta}
                  gKind={gKind}
                  setGKind={setGKind}
                  t0={t0}
                  setT0={setT0}
                  scaleA={scaleA}
                  setScaleA={setScaleA}
                  wc={wc}
                  setWc={setWc}
                  kernel={kernel}
                  setKernel={setKernel}
                  gibbsN={gibbsN}
                  setGibbsN={setGibbsN}
                />
              ) : null}
            </>
          ) : (
            <div className="rounded-xl border border-border bg-surface p-6">
              <p className="text-sm text-muted">表达式还不能计算。改对之后，时域、级数和频谱会一起出现。</p>
            </div>
          )}
        </section>
      </div>
    </main>
  );
}

function Slider({
  label,
  value,
  min,
  max,
  step,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (value: number) => void;
}) {
  const shown = Number.isFinite(value) ? value : min;
  return (
    <label className="block">
      <span className="flex items-baseline justify-between gap-3 text-sm">
        <span>{label}</span>
        <span className="tabular-nums text-primary">{fmt(shown)}</span>
      </span>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={Math.min(max, Math.max(min, shown))}
        aria-label={label}
        onChange={(e) => onChange(Number(e.target.value))}
        className="mt-1 h-11 w-full"
      />
    </label>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-border bg-surface px-3 py-3">
      <p className="text-xs text-muted">{label}</p>
      <p className="mt-1 truncate text-lg tabular-nums">{value}</p>
    </div>
  );
}

function WavePane({
  model,
  timeLines,
  useDb,
  showPhase,
  showSum,
  setUseDb,
  setShowPhase,
  setShowSum,
}: {
  model: NonNullable<ReturnType<typeof useModelShape>>;
  timeLines: PlotLine[];
  useDb: boolean;
  showPhase: boolean;
  showSum: boolean;
  setUseDb: (v: boolean) => void;
  setShowPhase: (v: boolean) => void;
  setShowSum: (v: boolean) => void;
}) {
  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap gap-2">
        <Toggle on={showSum} onClick={() => setShowSum(!showSum)} label="叠上部分和" />
        <Toggle on={showPhase} onClick={() => setShowPhase(!showPhase)} label="相位" />
        <Toggle on={useDb} onClick={() => setUseDb(!useDb)} label="相对 dB" />
      </div>
      <LinePlot title="时域" subtitle={`显示 ±${fmt(model.view)}`} xLabel="t" data={model.time} lines={timeLines} />
      <LinePlot
        title={useDb ? "幅度谱（相对主峰）" : "幅度谱"}
        subtitle="数值积分，窗为 [−L, L]"
        xLabel="ω"
        data={model.magRows}
        lines={[{ key: "y", name: useDb ? "dB" : "|F(ω)|", tone: "primary" }]}
      />
      {showPhase ? (
        <LinePlot
          title="相位"
          xLabel="ω"
          data={model.phaseRows}
          lines={[{ key: "phase", name: "arg F", tone: "accent" }]}
          yDomain={[-3.2, 3.2]}
        />
      ) : null}
      <p className="text-sm text-pretty text-muted">
        数值频谱是观察窗里的积分。脉冲若在窗边已经消失，它就接近无限长时间的变换；永远不停的正弦会被窗切成窄峰，而不是理想冲激。
      </p>
    </div>
  );
}

function useModelShape() {
  return null as unknown as {
    time: Record<string, number | null>[];
    magRows: Record<string, number | null>[];
    phaseRows: Record<string, number | null>[];
    partRows: Record<string, number | null>[];
    view: number;
    ser: Series;
    form: ClosedForm | null;
    err: number | null;
    eIn: number;
    fsPow: number;
    outside: number;
    sampleErr: number | null;
    peak: number;
    peakW: number;
    bad: number;
    fn: (t: number) => number;
  };
}

function SeriesPane({
  model,
  T,
}: {
  model: NonNullable<ReturnType<typeof useModelShape>>;
  T: number;
}) {
  const rows = [];
  for (let n = 1; n < model.ser.an.length; n++) {
    const an = model.ser.an[n];
    const bn = model.ser.bn[n];
    const re = an / 2;
    const im = -bn / 2;
    rows.push({
      n,
      an,
      bn,
      mag: Math.hypot(re, im),
      arg: Math.atan2(im, re),
    });
  }
  const mean = model.eIn / T;
  const captured = mean > 1e-8 ? model.fsPow / mean : 0;
  return (
    <div className="flex flex-col gap-4">
      <article className="rounded-xl border border-border bg-surface p-4">
        <h2 className="text-sm font-medium">一个周期上的三角级数</h2>
        <Tex
          display
          source={`f(t)\\sim a_0+\\sum_{n=1}^{N}(a_n\\cos n\\omega_0 t+b_n\\sin n\\omega_0 t),\\ \\omega_0=\\frac{2\\pi}{T},\\ T=${fmt(T)}`}
        />
        {model.form?.seriesLatex ? <Tex display source={model.form.seriesLatex} /> : (
          <p className="text-sm text-muted">没有配上封闭系数。表里是数值积分，照样能用。</p>
        )}
        <p className="text-sm text-pretty text-muted">
          a0 是周期平均值。n≥1 时 an、bn 用 2/T 归一，这样部分和直接相加就回到波形。复数系数 c0=a0，cn=(an−j bn)/2。
        </p>
      </article>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        <Stat label="周期均方" value={fmt(mean)} />
        <Stat label="级数已收能量" value={pct(captured)} />
        <Stat label="窗外汇占总能量" value={pct(model.outside)} />
      </div>
        <p className="text-sm text-pretty text-muted">
          {model.form?.distributional
            ? "这条信号的变换里有冲激列。表上的系数就是那些冲激的重量，不要把它当成一条连续曲线的采样。"
            : model.sampleErr === null
              ? "信号伸到了一个周期外面，cn 就不是整条 F(ω) 的采样。把级数周期加大，让脉冲几乎落在一个周期里，再看这条关系。"
              : `在这个周期里信号几乎衰减完，所以 cn ≈ F(nω0)/T。相对误差 ${pct(model.sampleErr)}。`}
        </p>
      <HarmonicBars data={rows.map((r) => ({ n: r.n, an: r.an, bn: r.bn }))} />
      <div className="overflow-x-auto rounded-xl border border-border">
        <table className="w-full min-w-[28rem] text-left text-sm">
          <thead className="bg-surface-2 text-xs text-muted">
            <tr>
              <th className="px-3 py-3 font-medium">n</th>
              <th className="px-3 py-3 font-medium">an</th>
              <th className="px-3 py-3 font-medium">bn</th>
              <th className="px-3 py-3 font-medium">|cn|</th>
              <th className="px-3 py-3 font-medium">arg cn</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.n} className="border-t border-border">
                <td className="px-3 py-2 tabular-nums">{r.n}</td>
                <td className="px-3 py-2 tabular-nums">{fmt(r.an)}</td>
                <td className="px-3 py-2 tabular-nums">{fmt(r.bn)}</td>
                <td className="px-3 py-2 tabular-nums">{fmt(r.mag)}</td>
                <td className="px-3 py-2 tabular-nums">{fmt(r.arg)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function TransformPane({
  model,
  params,
}: {
  model: NonNullable<ReturnType<typeof useModelShape>>;
  params: Record<string, number>;
}) {
  const form = model.form;
  return (
    <div className="flex flex-col gap-4">
      <article className="rounded-xl border border-border bg-surface p-4">
        <h2 className="text-sm font-medium">约定</h2>
        <Tex display source="F(\\omega)=\\int_{-\\infty}^{\\infty} f(t)e^{-j\\omega t}\\,dt" />
        <p className="text-sm text-pretty text-muted">角频率。反变换前面带 1/2π，所以尺度定理是 1/|a|，帕塞瓦尔也带 1/2π。</p>
      </article>
      <article className="rounded-xl border border-border bg-surface p-4">
        <h2 className="text-sm font-medium">f(t) 与 F(ω)</h2>
        {form ? (
          <>
            <Tex display source={`f(t)=${form.fLatex}`} />
            <Tex display source={`F(\\omega)=${form.FLatex}`} />
            <p className="mt-2 text-sm text-pretty text-fg">{liveNote(form, params)}</p>
            {form.notes.map((note) =>
              note.includes("\\") ? (
                <Tex key={note} display source={note} />
              ) : (
                <p key={note} className="mt-2 text-sm text-pretty text-muted">
                  {note}
                </p>
              ),
            )}
          </>
        ) : (
          <p className="text-sm text-pretty text-muted">
            这个式子没有自动配上封闭形式。下面的频谱仍是数值积分，性质实验照样拿它做对照。
          </p>
        )}
        {model.err !== null ? (
          <p className="mt-3 text-sm text-accent">封闭形式和数值谱的相对误差 {pct(model.err)}。改参量时两边应当一起动。</p>
        ) : form ? (
          <p className="mt-3 text-sm text-muted">这里含有冲激，不能逐点跟数值谱比高低，只能比峰的位置和级数系数。</p>
        ) : null}
      </article>
      <LinePlot
        title="实部与虚部"
        xLabel="ω"
        data={model.partRows}
        lines={[
          { key: "re", name: "实部", tone: "primary" },
          { key: "im", name: "虚部", tone: "accent", dash: true },
        ]}
      />
    </div>
  );
}

function LawPane(props: {
  law: ExperimentId;
  setLaw: (id: ExperimentId) => void;
  view: NonNullable<ReturnType<typeof runExperiment>>;
  alpha: number;
  setAlpha: (v: number) => void;
  beta: number;
  setBeta: (v: number) => void;
  gKind: "gauss" | "rect" | "exp";
  setGKind: (v: "gauss" | "rect" | "exp") => void;
  t0: number;
  setT0: (v: number) => void;
  scaleA: number;
  setScaleA: (v: number) => void;
  wc: number;
  setWc: (v: number) => void;
  kernel: number;
  setKernel: (v: number) => void;
  gibbsN: number;
  setGibbsN: (v: number) => void;
}) {
  const { view } = props;
  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        {EXPERIMENTS.map((item) => {
          const on = props.law === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => props.setLaw(item.id)}
              className={
                on
                  ? "min-h-11 rounded-xl bg-primary px-3 text-left text-sm font-medium text-primary-fg"
                  : "min-h-11 rounded-xl border border-border bg-surface px-3 text-left text-sm"
              }
            >
              <span className="mr-2 tabular-nums opacity-70">{item.index}</span>
              {item.label}
            </button>
          );
        })}
      </div>
      <article className="rounded-xl border border-border bg-surface p-4">
        <Tex display source={view.formula} />
        <p className="text-sm text-pretty text-muted">{view.blurb}</p>
      </article>
      <div className="rounded-xl border border-border bg-surface p-4">
        {props.law === "linear" ? (
          <div className="flex flex-col gap-3">
            <label className="block text-sm">
              第二条信号
              <select
                value={props.gKind}
                onChange={(e) => props.setGKind(e.target.value as "gauss" | "rect" | "exp")}
                className="mt-1 h-11 w-full rounded-lg border border-border bg-surface-2 px-3 text-fg"
              >
                <option value="gauss">高斯</option>
                <option value="rect">矩形</option>
                <option value="exp">单边指数</option>
              </select>
            </label>
            <Slider label="α" value={props.alpha} min={-1.5} max={2} step={0.05} onChange={props.setAlpha} />
            <Slider label="β" value={props.beta} min={-1.5} max={2} step={0.05} onChange={props.setBeta} />
          </div>
        ) : null}
        {props.law === "shift" ? <Slider label="平移 t0" value={props.t0} min={-2} max={2} step={0.05} onChange={props.setT0} /> : null}
        {props.law === "scale" ? (
          <Slider label="尺度 a" value={props.scaleA} min={0.4} max={3} step={0.05} onChange={props.setScaleA} />
        ) : null}
        {props.law === "mod" ? <Slider label="载波 ωc" value={props.wc} min={0} max={14} step={0.1} onChange={props.setWc} /> : null}
        {props.law === "conv" ? (
          <Slider label="矩形核宽度" value={props.kernel} min={0.3} max={4} step={0.05} onChange={props.setKernel} />
        ) : null}
        {props.law === "gibbs" ? (
          <Slider label="方波谐波次数" value={props.gibbsN} min={1} max={48} step={1} onChange={props.setGibbsN} />
        ) : null}
        {props.law === "diff" || props.law === "sym" || props.law === "parseval" ? (
          <p className="text-sm text-muted">这一条跟着左侧的 f(t) 和观察窗走。换信号或加大 L，误差会跟着变。</p>
        ) : null}
      </div>
      <div className="grid gap-2 sm:grid-cols-2">
        {view.metrics.map((metric) =>
          metric.value.length > 28 ? (
            <p key={metric.label} className={`text-sm text-pretty sm:col-span-2 ${toneClass(metric.tone)}`}>
              {metric.value}
            </p>
          ) : (
            <Stat key={metric.label} label={metric.label} value={metric.value} />
          ),
        )}
      </div>
      {view.charts.map((chart) => (
        <LinePlot
          key={chart.title}
          title={chart.title}
          subtitle={chart.subtitle}
          xLabel={chart.xLabel}
          data={chart.data}
          lines={chart.lines}
        />
      ))}
    </div>
  );
}

function toneClass(tone: "ok" | "warn" | "bad"): string {
  if (tone === "ok") return "text-accent";
  if (tone === "warn") return "text-primary";
  return "text-danger";
}

function Toggle({ on, onClick, label }: { on: boolean; onClick: () => void; label: string }) {
  return (
    <button
      type="button"
      aria-pressed={on}
      onClick={onClick}
      className={
        on
          ? "min-h-11 rounded-full bg-surface-2 px-4 text-sm text-primary"
          : "min-h-11 rounded-full border border-border px-4 text-sm text-muted"
      }
    >
      {label}
    </button>
  );
}
