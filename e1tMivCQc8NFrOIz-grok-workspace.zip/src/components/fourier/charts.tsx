import { useEffect, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

export type PlotLine = {
  key: string;
  name: string;
  tone: "primary" | "accent" | "muted";
  dash?: boolean;
};

const STROKE = {
  primary: "var(--color-primary)",
  accent: "var(--color-accent)",
  muted: "var(--color-muted)",
} as const;

function fmtTick(v: number): string {
  if (!Number.isFinite(v)) return "";
  const a = Math.abs(v);
  if (a !== 0 && (a >= 1000 || a < 0.01)) return v.toExponential(0);
  if (a >= 10) return v.toFixed(0);
  if (a >= 1) return String(Math.round(v * 10) / 10);
  return String(Math.round(v * 100) / 100);
}

function Tip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: { name?: string; value?: number; color?: string }[];
  label?: number | string;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg border border-border bg-surface px-3 py-2 text-xs text-fg shadow-none">
      <p className="mb-1 tabular-nums text-muted">{fmtTick(Number(label))}</p>
      {payload.map((p) => (
        <p key={p.name} className="tabular-nums" style={{ color: p.color }}>
          {p.name} {fmtTick(Number(p.value))}
        </p>
      ))}
    </div>
  );
}

function Legend({ lines }: { lines: PlotLine[] }) {
  return (
    <ul className="mb-2 flex flex-wrap gap-x-4 gap-y-1">
      {lines.map((line) => (
        <li key={line.key} className="flex items-center gap-2 text-xs text-muted">
          <span
            className="inline-block h-0.5 w-4"
            style={{
              background: STROKE[line.tone],
              outline: line.dash ? "1px dashed var(--color-border)" : undefined,
            }}
          />
          {line.name}
        </li>
      ))}
    </ul>
  );
}

export function LinePlot({
  title,
  subtitle,
  xLabel,
  data,
  lines,
  yDomain,
}: {
  title: string;
  subtitle?: string;
  xLabel: string;
  data: Record<string, number | null>[];
  lines: PlotLine[];
  yDomain?: [number, number];
}) {
  const [on, setOn] = useState(false);
  useEffect(() => setOn(true), []);
  return (
    <figure className="rounded-xl border border-border bg-surface p-3">
      <figcaption className="mb-1 flex flex-wrap items-baseline justify-between gap-2">
        <span className="text-sm font-medium">{title}</span>
        {subtitle ? <span className="text-xs text-muted">{subtitle}</span> : null}
      </figcaption>
      <Legend lines={lines} />
      <div className="h-56">
        {on ? (
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
              <CartesianGrid stroke="var(--color-border)" strokeDasharray="3 6" vertical={false} />
              <XAxis
                dataKey="x"
                tickFormatter={fmtTick}
                stroke="var(--color-muted)"
                tick={{ fill: "var(--color-muted)", fontSize: 11 }}
                minTickGap={32}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                domain={yDomain ?? ["auto", "auto"]}
                tickFormatter={fmtTick}
                stroke="var(--color-muted)"
                tick={{ fill: "var(--color-muted)", fontSize: 11 }}
                width={44}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip content={<Tip />} />
              {lines.map((line) => (
                <Line
                  key={line.key}
                  type="monotone"
                  dataKey={line.key}
                  name={line.name}
                  stroke={STROKE[line.tone]}
                  strokeWidth={line.tone === "muted" ? 1.25 : 1.75}
                  strokeDasharray={line.dash ? "5 4" : undefined}
                  dot={false}
                  connectNulls={false}
                  isAnimationActive={false}
                />
              ))}
            </LineChart>
          </ResponsiveContainer>
        ) : null}
      </div>
      <p className="mt-1 text-xs text-muted">{xLabel}</p>
    </figure>
  );
}

export function HarmonicBars({
  data,
}: {
  data: { n: number; an: number; bn: number }[];
}) {
  const [on, setOn] = useState(false);
  useEffect(() => setOn(true), []);
  return (
    <figure className="rounded-xl border border-border bg-surface p-3">
      <figcaption className="mb-1 text-sm font-medium">谐波系数</figcaption>
      <Legend
        lines={[
          { key: "an", name: "an 余弦", tone: "accent" },
          { key: "bn", name: "bn 正弦", tone: "primary" },
        ]}
      />
      <div className="h-56">
        {on ? (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
              <CartesianGrid stroke="var(--color-border)" strokeDasharray="3 6" vertical={false} />
              <XAxis
                dataKey="n"
                stroke="var(--color-muted)"
                tick={{ fill: "var(--color-muted)", fontSize: 11 }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                tickFormatter={fmtTick}
                stroke="var(--color-muted)"
                tick={{ fill: "var(--color-muted)", fontSize: 11 }}
                width={44}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip content={<Tip />} />
              <Bar dataKey="an" name="an" fill="var(--color-accent)" isAnimationActive={false} />
              <Bar dataKey="bn" name="bn" fill="var(--color-primary)" isAnimationActive={false} />
            </BarChart>
          </ResponsiveContainer>
        ) : null}
      </div>
      <p className="mt-1 text-xs text-muted">n</p>
    </figure>
  );
}
