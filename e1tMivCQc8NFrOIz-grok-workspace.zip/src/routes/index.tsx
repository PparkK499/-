import { createFileRoute } from "@tanstack/react-router";
import { FourierLab } from "@/components/fourier/lab";

export const Route = createFileRoute("/")({
  component: FourierLab,
});
