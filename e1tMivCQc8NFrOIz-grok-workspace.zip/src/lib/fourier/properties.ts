import {
  energy,
  fourierSeries,
  interp,
  reconstruct,
  relError,
  spectrumRows,
  tone,
  toneText,
  transform,
  type Spectrum,
} from "./num.ts";

export type Tone = "ok" | "warn" | "bad";
export type Metric = { label: string; value: string; tone: Tone };
export type LineSpec = { key: string; name: string; tone: "primary" | "accent" | "muted"; dash?: boolean };
export type ChartSpec = {
  title: string;
  subtitle?: string;
  xLabel: string;
  data: Record<string, number | null>[];
  lines: LineSpec[];
};
export type ExperimentView = {
  formula: string;
  blurb: string;
  charts: ChartSpec[];
  metrics: Metric[];
};

export const EXPERIMENTS = [
  { id: "linear", index: "01", label: "线性" },
  { id: "shift", index: "02", label: "时移" },
  { id: "scale", index: "03", label: "尺度" },
  { id: "mod", index: "04", label: "调制" },
  { id: "diff", index: "05", label: "微分" },
  { id: "conv", index: "06", label: "卷积" },
  { id: "sym", index: "07", label: "对称" },
  { id: "parseval", index: "08", label: "帕塞瓦尔" },
  { id: "gibbs", index: "09", label: "吉布斯" },
] as const;

export type ExperimentId = (typeof EXPERIMENTS)[number]["id"];

export type ExperimentInput = {
  id: ExperimentId;
  fn: (t: number) => number;
  L: number;
  wMax: number;
  alpha: number;
  beta: number;
  gKind: "gauss" | "rect" | "exp";
  t0: number;
  scaleA: number;
  wc: number;
  kernel: number;
  gibbsN: number;
};

const N = 2048;

function gOf(kind: ExperimentInput["gKind"]): (t: number) => number {
  if (kind === "gauss") return (t) => Math.exp(-0.7 * t * t);
  if (kind === "rect") return (t) => (Math.abs(t) < 0.75 ? 1 : 0);
  return (t) => (t >= 0 ? Math.exp(-t) : 0);
}

function pct(err: number): string {
  const p = err * 100;
  return `${p < 10 ? p.toFixed(2) : p.toFixed(1)}%`;
}

function metric(label: string, err: number): Metric {
  return { label, value: pct(err), tone: tone(err) };
}

function rows2(a: Spectrum, b: Spectrum, wMax: number, ka: string, kb: string): Record<string, number | null>[] {
  const rows: Record<string, number | null>[] = [];
  const n = Math.min(a.w.length, b.w.length);
  for (let i = 0; i < n; i++) {
    const w = a.w[i];
    if (w < -wMax || w > wMax) continue;
    rows.push({
      x: w,
      [ka]: Math.hypot(a.re[i], a.im[i]),
      [kb]: Math.hypot(b.re[i], b.im[i]),
    });
  }
  return rows;
}

function timeRows(
  x0: number,
  x1: number,
  count: number,
  series: { key: string; fn: (t: number) => number }[],
): Record<string, number | null>[] {
  const rows: Record<string, number | null>[] = [];
  for (let i = 0; i < count; i++) {
    const x = x0 + ((x1 - x0) * i) / (count - 1);
    const row: Record<string, number | null> = { x };
    for (const s of series) {
      const y = s.fn(x);
      row[s.key] = Number.isFinite(y) ? y : null;
    }
    rows.push(row);
  }
  return rows;
}

function onGrid(base: Spectrum, map: (w: number) => { re: number; im: number }): Spectrum {
  return {
    ...base,
    re: base.w.map((w) => map(w).re),
    im: base.w.map((w) => map(w).im),
  };
}

export function runExperiment(input: ExperimentInput): ExperimentView {
  const { fn, L, wMax } = input;
  const viewT = Math.min(Math.max(L, 2), 8);
  switch (input.id) {
    case "linear":
      return linear(input, viewT);
    case "shift":
      return shift(input, viewT);
    case "scale":
      return scaling(input, viewT);
    case "mod":
      return modulation(input, viewT);
    case "diff":
      return diff(input, viewT);
    case "conv":
      return conv(input, viewT);
    case "sym":
      return symmetry(input, viewT);
    case "parseval":
      return parsevalView(fn, L, wMax);
    case "gibbs":
      return gibbs(input.gibbsN);
    default:
      return linear(input, viewT);
  }
}

function linear(input: ExperimentInput, viewT: number): ExperimentView {
  const g = gOf(input.gKind);
  const { fn, L, wMax, alpha, beta } = input;
  const mix = (t: number) => alpha * fn(t) + beta * g(t);
  const Fa = transform(fn, L, N);
  const Fg = transform(g, L, N);
  const direct = transform(mix, L, N);
  const theorem = onGrid(Fa, (w) => {
    const a = interp(Fa, w);
    const b = interp(Fg, w);
    return { re: alpha * a.re + beta * b.re, im: alpha * a.im + beta * b.im };
  });
  const err = relError(direct, theorem, wMax);
  const gName = input.gKind === "gauss" ? "高斯" : input.gKind === "rect" ? "矩形" : "单边指数";
  return {
    formula: "\\mathcal{F}\\{\\alpha f+\\beta g\\}=\\alpha F+\\beta G",
    blurb: `g 固定为${gName}，不占用左侧表达式。α、β 只做数乘和相加，频谱必须同样数乘再相加。`,
    charts: [
      {
        title: "混合后的时域",
        xLabel: "t",
        data: timeRows(-viewT, viewT, 360, [
          { key: "f", fn },
          { key: "mix", fn: mix },
        ]),
        lines: [
          { key: "f", name: "f(t)", tone: "muted" },
          { key: "mix", name: "αf+βg", tone: "primary" },
        ],
      },
      {
        title: "幅度谱对照",
        subtitle: "实线直接变换，虚线是 αF+βG",
        xLabel: "ω",
        data: rows2(direct, theorem, wMax, "direct", "theorem"),
        lines: [
          { key: "direct", name: "直接变换", tone: "primary" },
          { key: "theorem", name: "αF+βG", tone: "accent", dash: true },
        ],
      },
    ],
    metrics: [metric("频谱相对误差", err), { label: "判读", value: toneText(err), tone: tone(err) }],
  };
}

function shift(input: ExperimentInput, viewT: number): ExperimentView {
  const { fn, L, wMax, t0 } = input;
  const shifted = (t: number) => fn(t - t0);
  const base = transform(fn, L, N);
  const direct = transform(shifted, L, N);
  const theorem = onGrid(base, (w) => {
    const z = interp(base, w);
    const c = Math.cos(-w * t0);
    const s = Math.sin(-w * t0);
    return { re: z.re * c - z.im * s, im: z.re * s + z.im * c };
  });
  const err = relError(direct, theorem, wMax);
  const T = 4;
  const s0 = fourierSeries(fn, T, 8, 2048);
  const s1 = fourierSeries(shifted, T, 8, 2048);
  let num = 0;
  let den = 0;
  for (let n = 1; n <= 8; n++) {
    const cRe = s0.an[n] / 2;
    const cIm = -s0.bn[n] / 2;
    const ang = -n * s0.w0 * t0;
    const pr = cRe * Math.cos(ang) - cIm * Math.sin(ang);
    const pi = cRe * Math.sin(ang) + cIm * Math.cos(ang);
    const qr = s1.an[n] / 2;
    const qi = -s1.bn[n] / 2;
    num += (pr - qr) ** 2 + (pi - qi) ** 2;
    den += pr * pr + pi * pi + qr * qr + qi * qi;
  }
  const fsErr = Math.sqrt(num / Math.max(den, 1e-18));
  return {
    formula: "f(t-t_0)\\leftrightarrow e^{-j\\omega t_0}F(\\omega),\\quad c_n\\mapsto c_n e^{-jn\\omega_0 t_0}",
    blurb: "平移不改变幅度谱，只把相位拧成斜率 −t0 的直线。级数系数同样只旋转相位。",
    charts: [
      {
        title: "时域平移",
        xLabel: "t",
        data: timeRows(-viewT, viewT, 360, [
          { key: "f", fn },
          { key: "s", fn: shifted },
        ]),
        lines: [
          { key: "f", name: "f(t)", tone: "muted" },
          { key: "s", name: "f(t−t0)", tone: "primary" },
        ],
      },
      {
        title: "幅度谱应重合",
        xLabel: "ω",
        data: rows2(direct, theorem, wMax, "direct", "theorem"),
        lines: [
          { key: "direct", name: "|变换后|", tone: "primary" },
          { key: "theorem", name: "|F| 不变", tone: "accent", dash: true },
        ],
      },
    ],
    metrics: [
      metric("频谱相对误差", err),
      metric("级数系数相位误差", fsErr),
      { label: "判读", value: toneText(Math.max(err, fsErr)), tone: tone(Math.max(err, fsErr)) },
    ],
  };
}

function scaling(input: ExperimentInput, viewT: number): ExperimentView {
  const a = input.scaleA === 0 ? 0.2 : input.scaleA;
  const { fn, L, wMax } = input;
  const scaled = (t: number) => fn(a * t);
  const base = transform(fn, L, N);
  const direct = transform(scaled, L, N);
  const theorem = onGrid(base, (w) => {
    const z = interp(base, w / a);
    const s = 1 / Math.abs(a);
    return { re: s * z.re, im: s * z.im };
  });
  const err = relError(direct, theorem, wMax);
  return {
    formula: "f(at)\\leftrightarrow\\dfrac{1}{|a|}F\\!\\left(\\dfrac{\\omega}{a}\\right)",
    blurb: "时域压窄 a 倍，频谱就展宽 a 倍，高度变成 1/|a|。a<1 时信号会探出观察窗，误差会上来。",
    charts: [
      {
        title: "时域尺度",
        xLabel: "t",
        data: timeRows(-viewT, viewT, 360, [
          { key: "f", fn },
          { key: "s", fn: scaled },
        ]),
        lines: [
          { key: "f", name: "f(t)", tone: "muted" },
          { key: "s", name: "f(at)", tone: "primary" },
        ],
      },
      {
        title: "频谱展宽",
        xLabel: "ω",
        data: rows2(direct, theorem, wMax, "direct", "theorem"),
        lines: [
          { key: "direct", name: "直接变换", tone: "primary" },
          { key: "theorem", name: "(1/|a|)F(ω/a)", tone: "accent", dash: true },
        ],
      },
    ],
    metrics: [metric("频谱相对误差", err), { label: "判读", value: toneText(err), tone: tone(err) }],
  };
}

function modulation(input: ExperimentInput, viewT: number): ExperimentView {
  const { fn, L, wMax, wc } = input;
  const mod = (t: number) => fn(t) * Math.cos(wc * t);
  const base = transform(fn, L, N);
  const direct = transform(mod, L, N);
  const theorem = onGrid(base, (w) => {
    const p = interp(base, w - wc);
    const m = interp(base, w + wc);
    return { re: 0.5 * (p.re + m.re), im: 0.5 * (p.im + m.im) };
  });
  const err = relError(direct, theorem, wMax);
  return {
    formula: "f(t)\\cos(\\omega_c t)\\leftrightarrow\\dfrac{1}{2}\\left(F(\\omega-\\omega_c)+F(\\omega+\\omega_c)\\right)",
    blurb: "乘上余弦，频谱被拆成两半，搬到 ±ωc。包络越窄，搬过去的每一团越宽。",
    charts: [
      {
        title: "被余弦乘过的时域",
        xLabel: "t",
        data: timeRows(-viewT, viewT, 420, [
          { key: "f", fn },
          { key: "m", fn: mod },
        ]),
        lines: [
          { key: "f", name: "f(t)", tone: "muted" },
          { key: "m", name: "f(t)cos(ωc t)", tone: "primary" },
        ],
      },
      {
        title: "频谱搬移",
        xLabel: "ω",
        data: rows2(direct, theorem, wMax, "direct", "theorem"),
        lines: [
          { key: "direct", name: "直接变换", tone: "primary" },
          { key: "theorem", name: "半份左右相加", tone: "accent", dash: true },
        ],
      },
    ],
    metrics: [metric("频谱相对误差", err), { label: "判读", value: toneText(err), tone: tone(err) }],
  };
}

function diff(input: ExperimentInput, viewT: number): ExperimentView {
  const { fn, L, wMax } = input;
  const h = 1e-3;
  const fp = (t: number) => (fn(t + h) - fn(t - h)) / (2 * h);
  const base = transform(fn, L, N);
  const direct = transform(fp, L, N);
  const theorem = onGrid(base, (w) => {
    const z = interp(base, w);
    return { re: -w * z.im, im: w * z.re };
  });
  const err = relError(direct, theorem, wMax);
  return {
    formula: "\\dfrac{df}{dt}\\leftrightarrow j\\omega F(\\omega)",
    blurb: "求导等于频谱乘 jω，高频被抬起来。有跳跃的信号导数是冲激，数值差分会失真，换高斯或指数再看。",
    charts: [
      {
        title: "导数",
        xLabel: "t",
        data: timeRows(-viewT, viewT, 360, [{ key: "d", fn: fp }]),
        lines: [{ key: "d", name: "df/dt", tone: "primary" }],
      },
      {
        title: "jωF 对照",
        xLabel: "ω",
        data: rows2(direct, theorem, wMax, "direct", "theorem"),
        lines: [
          { key: "direct", name: "|变换后的导数|", tone: "primary" },
          { key: "theorem", name: "|jωF|", tone: "accent", dash: true },
        ],
      },
    ],
    metrics: [metric("频谱相对误差", err), { label: "判读", value: toneText(err), tone: tone(err) }],
  };
}

function conv(input: ExperimentInput, viewT: number): ExperimentView {
  const { fn, L, wMax, kernel } = input;
  const width = Math.max(0.2, kernel);
  const g = (t: number) => (Math.abs(t) <= width / 2 ? 1 : 0);
  const M = 480;
  const dt = (2 * L) / M;
  const fs = new Float64Array(M);
  for (let i = 0; i < M; i++) {
    const y = fn(-L + (i + 0.5) * dt);
    fs[i] = Number.isFinite(y) ? y : 0;
  }
  const convolved = (t: number) => {
    let s = 0;
    for (let i = 0; i < M; i++) {
      const tau = -L + (i + 0.5) * dt;
      s += fs[i] * g(t - tau);
    }
    return s * dt;
  };
  const Fg = transform(g, L, N);
  const Ff = transform(fn, L, N);
  const direct = transform(convolved, L, 1024);
  const theorem = onGrid(direct, (w) => {
    const a = interp(Ff, w);
    const b = interp(Fg, w);
    return { re: a.re * b.re - a.im * b.im, im: a.re * b.im + a.im * b.re };
  });
  const err = relError(direct, theorem, wMax);
  return {
    formula: "(f*g)(t)=\\int f(\\tau)g(t-\\tau)\\,d\\tau\\leftrightarrow F(\\omega)G(\\omega)",
    blurb: "g 是宽为 τk 的矩形。时域卷积对应频谱相乘。信号若在窗边还没衰减完，卷积会被窗切掉一截。",
    charts: [
      {
        title: "卷积结果",
        xLabel: "t",
        data: timeRows(-viewT, viewT, 280, [
          { key: "f", fn },
          { key: "c", fn: convolved },
        ]),
        lines: [
          { key: "f", name: "f(t)", tone: "muted" },
          { key: "c", name: "f ∗ rect", tone: "primary" },
        ],
      },
      {
        title: "频谱乘积",
        xLabel: "ω",
        data: rows2(direct, theorem, wMax, "direct", "theorem"),
        lines: [
          { key: "direct", name: "|变换(f∗g)|", tone: "primary" },
          { key: "theorem", name: "|FG|", tone: "accent", dash: true },
        ],
      },
    ],
    metrics: [metric("频谱相对误差", err), { label: "判读", value: toneText(err), tone: tone(err) }],
  };
}

function symmetry(input: ExperimentInput, viewT: number): ExperimentView {
  const { fn, L, wMax } = input;
  const fe = (t: number) => 0.5 * (fn(t) + fn(-t));
  const fo = (t: number) => 0.5 * (fn(t) - fn(-t));
  const Fe = transform(fe, L, N);
  const Fo = transform(fo, L, N);
  const ratio = (spec: Spectrum, part: "re" | "im") => {
    let partE = 0;
    let tot = 0;
    for (let i = 0; i < spec.w.length; i++) {
      if (Math.abs(spec.w[i]) > wMax) continue;
      const re = spec.re[i];
      const im = spec.im[i];
      tot += re * re + im * im;
      partE += part === "re" ? re * re : im * im;
    }
    return partE / Math.max(tot, 1e-18);
  };
  const oddLeak = ratio(Fe, "im");
  const evenLeak = ratio(Fo, "re");
  return {
    formula: "f_e(t)\\leftrightarrow \\operatorname{Re}F(\\omega),\\quad f_o(t)\\leftrightarrow j\\operatorname{Im}F(\\omega)",
    blurb: "任何实信号都能拆成偶部加奇部。偶部只留下实频谱，奇部只留下虚频谱。幅度谱偶、相位谱奇是这件事的另一面。",
    charts: [
      {
        title: "偶部与奇部",
        xLabel: "t",
        data: timeRows(-viewT, viewT, 360, [
          { key: "e", fn: fe },
          { key: "o", fn: fo },
        ]),
        lines: [
          { key: "e", name: "偶部", tone: "primary" },
          { key: "o", name: "奇部", tone: "accent" },
        ],
      },
      {
        title: "偶部频谱（虚部应贴着 0）",
        xLabel: "ω",
        data: spectrumRows(Fe, wMax, { re: "re", im: "im" }),
        lines: [
          { key: "re", name: "实部", tone: "primary" },
          { key: "im", name: "虚部", tone: "accent", dash: true },
        ],
      },
    ],
    metrics: [
      metric("偶部虚部能量占比", oddLeak),
      metric("奇部实部能量占比", evenLeak),
      {
        label: "判读",
        value: toneText(Math.max(oddLeak, evenLeak)),
        tone: tone(Math.max(oddLeak, evenLeak)),
      },
    ],
  };
}

function parsevalView(fn: (t: number) => number, L: number, wMax: number): ExperimentView {
  const spec = transform(fn, L, 4096);
  const n = spec.w.length;
  const dt = spec.dt;
  let time = 0;
  for (let i = 0; i < n; i++) {
    const y = fn(-L + i * dt);
    if (Number.isFinite(y)) time += y * y;
  }
  time *= dt;
  const dW = n > 1 ? spec.w[1] - spec.w[0] : 0;
  let acc = 0;
  for (let i = 0; i < n; i++) acc += spec.re[i] * spec.re[i] + spec.im[i] * spec.im[i];
  const freq = (acc * dW) / (2 * Math.PI);
  const err = Math.abs(time - freq) / Math.max(Math.abs(time), Math.abs(freq), 1e-12);
  const T = 4;
  const ser = fourierSeries(fn, T, 24, 4096);
  const eTime = energy(fn, -T / 2, T / 2, 4000) / T;
  let eSpec = ser.a0 * ser.a0;
  for (let k = 1; k < ser.an.length; k++) eSpec += (ser.an[k] * ser.an[k] + ser.bn[k] * ser.bn[k]) / 2;
  const fsErr = Math.abs(eTime - eSpec) / Math.max(eTime, 1e-12);
  return {
    formula: "\\int |f|^2\\,dt=\\dfrac{1}{2\\pi}\\int |F|^2\\,d\\omega",
    blurb: "能量在时域和频域是同一笔账。级数那边截到有限项，所以均方只会小于或等于一个周期里的均方，项数加够才补齐。",
    charts: [
      {
        title: "窗内的 |F(ω)|²",
        subtitle: "频域能量是它的积分再除以 2π",
        xLabel: "ω",
        data: spectrumRows(spec, wMax, { mag: "p" }).map((r) => ({
          x: r.x,
          p: typeof r.p === "number" ? r.p * r.p : null,
        })),
        lines: [{ key: "p", name: "|F|²", tone: "primary" }],
      },
    ],
    metrics: [
      { label: "时域能量", value: time.toFixed(4), tone: "ok" },
      { label: "频域能量", value: freq.toFixed(4), tone: "ok" },
      metric("变换能量误差", err),
      {
        label: "级数已收能量",
        value: `${((eSpec / Math.max(eTime, 1e-12)) * 100).toFixed(1)}%`,
        tone: fsErr < 0.08 ? "ok" : "warn",
      },
    ],
  };
}

function gibbs(harmonics: number): ExperimentView {
  const T = 2;
  const fn = (t: number) => {
    const s = Math.sin((2 * Math.PI * t) / T);
    return s > 0 ? 1 : s < 0 ? -1 : 0;
  };
  const ser = fourierSeries(fn, T, harmonics, 8192);
  let peak = 0;
  let peakAt = 0;
  const steps = 4000;
  for (let i = 1; i < steps; i++) {
    const t = (i / steps) * (T / 2);
    const y = reconstruct(t, ser);
    if (y > peak) {
      peak = y;
      peakAt = t;
    }
  }
  const overshoot = (peak - 1) / 2;
  const near = overshoot > 0.07 && overshoot < 0.12;
  return {
    formula: "b_n=\\dfrac{4}{n\\pi}\\ (n\\ \\text{奇}),\\quad \\text{过冲}\\approx 9\\%",
    blurb: "这是周期为 2 的单位方波，用来把间断点看清楚。部分和在跳跃处多冲一截，谐波加再多也只是把过冲挤向间断点，高度停在跳变的大约 9%。",
    charts: [
      {
        title: "方波与部分和",
        subtitle: `${harmonics} 次谐波`,
        xLabel: "t",
        data: timeRows(-2, 2, 480, [
          { key: "f", fn },
          { key: "s", fn: (t) => reconstruct(t, ser) },
        ]),
        lines: [
          { key: "f", name: "方波", tone: "muted" },
          { key: "s", name: "部分和", tone: "primary" },
        ],
      },
    ],
    metrics: [
      { label: "第一峰高度", value: peak.toFixed(3), tone: "ok" },
      {
        label: "相对整段跳变的过冲",
        value: `${(overshoot * 100).toFixed(1)}%`,
        tone: near || harmonics < 7 ? "ok" : "warn",
      },
      { label: "峰的位置 t", value: peakAt.toFixed(3), tone: "ok" },
      {
        label: "判读",
        value: near
          ? "过冲停在 9% 附近，没有随谐波增加而消失。"
          : harmonics < 7
            ? "谐波还少，过冲还没稳定到 9%。把次数加到 20 以上再看。"
            : "峰值应接近 1.09。若偏离，检查周期是否为 2。",
        tone: near ? "ok" : "warn",
      },
    ],
  };
}

export function fsEnergy(fn: (t: number) => number, T: number, harmonics: number): { time: number; spec: number } {
  const ser = fourierSeries(fn, T, harmonics, 4096);
  const time = energy(fn, -T / 2, T / 2, 4000) / T;
  let spec = ser.a0 * ser.a0;
  for (let n = 1; n < ser.an.length; n++) spec += (ser.an[n] ** 2 + ser.bn[n] ** 2) / 2;
  return { time, spec };
}
