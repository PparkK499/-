import { astToLatex, type Ast } from "./expr.ts";

type Sym =
  | { k: "num"; v: number }
  | { k: "sym"; name: string }
  | { k: "add"; xs: Sym[] }
  | { k: "mul"; xs: Sym[] }
  | { k: "pow"; base: Sym; exp: Sym }
  | { k: "call"; name: string; args: Sym[] };

export type Complex = { re: number; im: number };

type Ordinary =
  | { kind: "expabs"; a: Sym }
  | { kind: "gauss"; a: Sym }
  | { kind: "rect"; tau: Sym }
  | { kind: "tri"; tau: Sym }
  | { kind: "cexp"; a: Sym }
  | { kind: "sinc"; tau: Sym };

type Core =
  | { kind: "dc" }
  | Ordinary
  | { kind: "cos"; w: Sym; phi: Sym }
  | { kind: "sin"; w: Sym; phi: Sym }
  | { kind: "square"; w: Sym; phi: Sym }
  | { kind: "saw"; T: Sym }
  | { kind: "modcos"; inner: Ordinary; w: Sym; phi: Sym }
  | { kind: "modsin"; inner: Ordinary; w: Sym; phi: Sym };

type Term = { coeff: Sym; core: Core };

export type ClosedForm = {
  terms: Term[];
  fLatex: string;
  FLatex: string;
  seriesLatex: string | null;
  /** True when F(ω) contains Dirac deltas, so pointwise numbers are not comparable. */
  distributional: boolean;
  notes: string[];
  evalAt: (omega: number, params: Record<string, number>) => Complex | null;
};

const num = (v: number): Sym => ({ k: "num", v });

function norm(e: Sym): Sym {
  switch (e.k) {
    case "num":
    case "sym":
      return e;
    case "call":
      return { k: "call", name: e.name, args: e.args.map(norm) };
    case "pow": {
      const base = norm(e.base);
      const exp = norm(e.exp);
      if (exp.k === "num" && exp.v === 1) return base;
      if (exp.k === "num" && exp.v === 0) return num(1);
      if (base.k === "pow" && exp.k === "num" && base.exp.k === "num") {
        return norm({ k: "pow", base: base.base, exp: num(base.exp.v * exp.v) });
      }
      if (base.k === "num" && exp.k === "num" && Number.isFinite(Math.pow(base.v, exp.v))) {
        return num(Math.pow(base.v, exp.v));
      }
      return { k: "pow", base, exp };
    }
    case "mul": {
      const xs = e.xs.flatMap((x) => {
        const n = norm(x);
        return n.k === "mul" ? n.xs : [n];
      });
      let coef = 1;
      const rest: Sym[] = [];
      for (const x of xs) {
        if (x.k === "num") coef *= x.v;
        else rest.push(x);
      }
      if (!Number.isFinite(coef) || coef === 0) return num(0);
      if (rest.length === 0) return num(coef);
      if (Math.abs(coef - 1) > 1e-15) rest.unshift(num(coef));
      return rest.length === 1 ? rest[0] : { k: "mul", xs: rest };
    }
    case "add": {
      const xs = e.xs.flatMap((x) => {
        const n = norm(x);
        return n.k === "add" ? n.xs : [n];
      });
      let coef = 0;
      const rest: Sym[] = [];
      for (const x of xs) {
        if (x.k === "num") coef += x.v;
        else rest.push(x);
      }
      if (Math.abs(coef) > 1e-15) rest.unshift(num(coef));
      if (rest.length === 0) return num(0);
      return rest.length === 1 ? rest[0] : { k: "add", xs: rest };
    }
  }
}

function fromAst(a: Ast): Sym {
  switch (a.t) {
    case "n":
      return num(a.v);
    case "v":
      return { k: "sym", name: a.name };
    case "u":
      return norm({ k: "mul", xs: [num(-1), fromAst(a.a)] });
    case "b": {
      const A = fromAst(a.a);
      const B = fromAst(a.b);
      if (a.op === "+") return norm({ k: "add", xs: [A, B] });
      if (a.op === "-") return norm({ k: "add", xs: [A, { k: "mul", xs: [num(-1), B] }] });
      if (a.op === "*") return norm({ k: "mul", xs: [A, B] });
      if (a.op === "/") return norm({ k: "mul", xs: [A, { k: "pow", base: B, exp: num(-1) }] });
      return norm({ k: "pow", base: A, exp: B });
    }
    case "c":
      return norm({ k: "call", name: a.name, args: a.args.map(fromAst) });
  }
}

function dependsOnT(e: Sym): boolean {
  if (e.k === "sym") return e.name === "t";
  if (e.k === "num") return false;
  if (e.k === "add" || e.k === "mul") return e.xs.some(dependsOnT);
  if (e.k === "pow") return dependsOnT(e.base) || dependsOnT(e.exp);
  return e.args.some(dependsOnT);
}

function splitAdd(e: Sym): Sym[] {
  if (e.k === "add") return e.xs.flatMap(splitAdd);
  return [e];
}

function splitMul(e: Sym): Sym[] {
  if (e.k === "mul") return e.xs.flatMap(splitMul);
  if (e.k === "num" && e.v === 1) return [];
  return [e];
}

function mulOf(xs: Sym[]): Sym {
  if (xs.length === 0) return num(1);
  if (xs.length === 1) return xs[0];
  return norm({ k: "mul", xs });
}

function addOf(a: Sym, b: Sym): Sym {
  return norm({ k: "add", xs: [a, b] });
}

function mul(a: Sym, b: Sym): Sym {
  return norm({ k: "mul", xs: [a, b] });
}

function neg(e: Sym): Sym {
  return mul(num(-1), e);
}

function isPlainT(e: Sym): boolean {
  return e.k === "sym" && e.name === "t";
}

function isAbsT(e: Sym): boolean {
  if (e.k !== "call" || e.name !== "abs" || e.args.length !== 1) return false;
  const a = e.args[0];
  if (isPlainT(a)) return true;
  if (a.k === "mul" && a.xs.length === 2 && a.xs[0].k === "num" && a.xs[0].v === -1 && isPlainT(a.xs[1])) return true;
  return false;
}

function isTSquared(e: Sym): boolean {
  if (e.k === "pow" && isPlainT(e.base) && e.exp.k === "num" && e.exp.v === 2) return true;
  return false;
}

function isUnitStep(e: Sym): boolean {
  return (
    e.k === "call" &&
    (e.name === "u" || e.name === "heaviside" || e.name === "step") &&
    e.args.length === 1 &&
    isPlainT(e.args[0])
  );
}

/** arg = -a * pattern, return a. pattern counted by `hit`. */
function decayCoeff(arg: Sym, hit: (e: Sym) => boolean): Sym | null {
  const factors = splitMul(arg);
  let hits = 0;
  const rest: Sym[] = [];
  for (const f of factors) {
    if (hit(f)) hits++;
    else rest.push(f);
  }
  if (hits !== 1) return null;
  if (rest.some(dependsOnT)) return null;
  return neg(mulOf(rest));
}

type Lin = { w: Sym; phi: Sym };

function linearT(e: Sym): Lin | null {
  if (isPlainT(e)) return { w: num(1), phi: num(0) };
  if (!dependsOnT(e)) return { w: num(0), phi: e };
  if (e.k === "add") {
    let w: Sym = num(0);
    let phi: Sym = num(0);
    for (const p of e.xs) {
      const lin = linearT(p);
      if (!lin) return null;
      w = addOf(w, lin.w);
      phi = addOf(phi, lin.phi);
    }
    return { w, phi };
  }
  if (e.k === "mul") {
    const deps = e.xs.filter(dependsOnT);
    const cons = e.xs.filter((x) => !dependsOnT(x));
    if (deps.length !== 1) return null;
    const lin = linearT(deps[0]);
    if (!lin) return null;
    const c = mulOf(cons);
    return { w: mul(c, lin.w), phi: mul(c, lin.phi) };
  }
  return null;
}

function asScaledT(e: Sym): Sym | null {
  const factors = splitMul(e);
  let tcount = 0;
  const rest: Sym[] = [];
  for (const f of factors) {
    if (isPlainT(f)) tcount++;
    else rest.push(f);
  }
  if (tcount !== 1) return null;
  if (rest.some(dependsOnT)) return null;
  return mulOf(rest);
}

type Trig = { which: "cos" | "sin"; w: Sym; phi: Sym };

function matchTrig(e: Sym): Trig | null {
  if (e.k !== "call" || (e.name !== "cos" && e.name !== "sin") || e.args.length !== 1) return null;
  const lin = linearT(e.args[0]);
  if (!lin) return null;
  if (lin.w.k === "num" && Math.abs(lin.w.v) < 1e-15) return null;
  return { which: e.name, w: lin.w, phi: lin.phi };
}

function matchPlain(e: Sym): Ordinary | { kind: "square"; w: Sym; phi: Sym } | { kind: "saw"; T: Sym } | null {
  if (e.k !== "call") return null;
  if (e.name === "exp" && e.args.length === 1) {
    const aAbs = decayCoeff(e.args[0], isAbsT);
    if (aAbs) return { kind: "expabs", a: aAbs };
    const aG = decayCoeff(e.args[0], isTSquared);
    if (aG) return { kind: "gauss", a: aG };
    return null;
  }
  if ((e.name === "rect" || e.name === "tri" || e.name === "sinc") && e.args.length === 1) {
    const c = asScaledT(e.args[0]);
    if (!c) return null;
    const tau = norm({ k: "pow", base: c, exp: num(-1) });
    if (e.name === "rect") return { kind: "rect", tau };
    if (e.name === "tri") return { kind: "tri", tau };
    return { kind: "sinc", tau };
  }
  if ((e.name === "sign" || e.name === "sgn") && e.args.length === 1) {
    const inner = e.args[0];
    if (inner.k === "call" && inner.name === "sin" && inner.args.length === 1) {
      const lin = linearT(inner.args[0]);
      if (lin && !(lin.w.k === "num" && Math.abs(lin.w.v) < 1e-15)) return { kind: "square", w: lin.w, phi: lin.phi };
    }
    return null;
  }
  if (e.name === "saw" && e.args.length === 1) {
    const c = asScaledT(e.args[0]);
    if (!c) return null;
    return { kind: "saw", T: norm({ k: "pow", base: c, exp: num(-1) }) };
  }
  return null;
}

function isCausalExp(e: Sym): Sym | null {
  if (e.k !== "call" || e.name !== "exp" || e.args.length !== 1) return null;
  return decayCoeff(e.args[0], isPlainT);
}

function productToSum(a: Trig, b: Trig): { scale: number; core: Core }[] {
  const sum = { w: addOf(a.w, b.w), phi: addOf(a.phi, b.phi) };
  const diff = { w: addOf(a.w, neg(b.w)), phi: addOf(a.phi, neg(b.phi)) };
  const cos = (lin: Lin): Core => ({ kind: "cos", w: lin.w, phi: lin.phi });
  const sin = (lin: Lin): Core => ({ kind: "sin", w: lin.w, phi: lin.phi });
  if (a.which === "cos" && b.which === "cos")
    return [
      { scale: 0.5, core: cos(sum) },
      { scale: 0.5, core: cos(diff) },
    ];
  if (a.which === "sin" && b.which === "sin")
    return [
      { scale: -0.5, core: cos(sum) },
      { scale: 0.5, core: cos(diff) },
    ];
  if (a.which === "sin" && b.which === "cos")
    return [
      { scale: 0.5, core: sin(sum) },
      { scale: 0.5, core: sin(diff) },
    ];
  return [
    { scale: 0.5, core: sin(sum) },
    { scale: -0.5, core: sin(diff) },
  ];
}

function matchProduct(e: Sym): Term[] | null {
  if (!dependsOnT(e)) return [{ coeff: e, core: { kind: "dc" } }];
  const factors = splitMul(e);
  const cons: Sym[] = [];
  const deps: Sym[] = [];
  for (const f of factors) (dependsOnT(f) ? deps : cons).push(f);
  const coeff = mulOf(cons);

  const reduced: Sym[] = [];
  let stepped = false;
  for (const d of deps) {
    if (isUnitStep(d)) stepped = true;
    else reduced.push(d);
  }

  if (stepped) {
    const idx = reduced.findIndex((d) => isCausalExp(d));
    if (idx < 0) return null;
    const a = isCausalExp(reduced[idx]);
    if (!a) return null;
    reduced.splice(idx, 1);
    const inner: Ordinary = { kind: "cexp", a };
    if (reduced.length === 0) return [{ coeff, core: inner }];
    if (reduced.length === 1) {
      const trig = matchTrig(reduced[0]);
      if (!trig) return null;
      return [
        {
          coeff,
          core:
            trig.which === "cos"
              ? { kind: "modcos", inner, w: trig.w, phi: trig.phi }
              : { kind: "modsin", inner, w: trig.w, phi: trig.phi },
        },
      ];
    }
    return null;
  }

  if (reduced.length === 1) {
    const trig = matchTrig(reduced[0]);
    if (trig) return [{ coeff, core: { kind: trig.which, w: trig.w, phi: trig.phi } }];
    const plain = matchPlain(reduced[0]);
    if (!plain) return null;
    return [{ coeff, core: plain }];
  }

  if (reduced.length === 2) {
    const t1 = matchTrig(reduced[0]);
    const t2 = matchTrig(reduced[1]);
    if (t1 && t2) {
      return productToSum(t1, t2).map((x) => ({ coeff: mul(coeff, num(x.scale)), core: x.core }));
    }
    const pair = (trigF: Sym, envF: Sym): Term[] | null => {
      const trig = matchTrig(trigF);
      const env = matchPlain(envF);
      if (!trig || !env) return null;
      if (env.kind === "square" || env.kind === "saw") return null;
      const inner = env;
      return [
        {
          coeff,
          core:
            trig.which === "cos"
              ? { kind: "modcos", inner, w: trig.w, phi: trig.phi }
              : { kind: "modsin", inner, w: trig.w, phi: trig.phi },
        },
      ];
    };
    return pair(reduced[0], reduced[1]) ?? pair(reduced[1], reduced[0]);
  }
  return null;
}

function isDistributional(core: Core): boolean {
  return core.kind === "dc" || core.kind === "cos" || core.kind === "sin" || core.kind === "square" || core.kind === "saw";
}

const GREEK: Record<string, string> = {
  pi: "\\pi",
  phi: "\\varphi",
  tau: "\\tau",
  omega: "\\omega",
  alpha: "\\alpha",
  beta: "\\beta",
  gamma: "\\gamma",
};

function peel(e: Sym): { neg: boolean; rest: Sym } {
  if (e.k === "num" && e.v < 0) return { neg: true, rest: num(-e.v) };
  if (e.k === "mul" && e.xs[0]?.k === "num" && e.xs[0].v < 0) {
    const v = -e.xs[0].v;
    const restxs = Math.abs(v - 1) < 1e-12 ? e.xs.slice(1) : [num(v), ...e.xs.slice(1)];
    const rest = restxs.length === 0 ? num(1) : restxs.length === 1 ? restxs[0] : { k: "mul" as const, xs: restxs };
    return { neg: true, rest };
  }
  return { neg: false, rest: e };
}

function latexSym(e: Sym): string {
  const { neg, rest } = peel(e);
  const body = latexBody(rest);
  return neg ? `-${body}` : body;
}

function joinParts(parts: string[]): string {
  let s = parts[0] ?? "1";
  for (let i = 1; i < parts.length; i++) {
    const p = parts[i];
    if (/[A-Za-z]$/.test(s) && /^[A-Za-z\\]/.test(p)) s += " ";
    s += p;
  }
  return s;
}

function latexBody(e: Sym): string {
  if (e.k === "num") {
    if (Number.isInteger(e.v)) return String(e.v);
    return String(Number(e.v.toPrecision(6)));
  }
  if (e.k === "sym") return GREEK[e.name] ?? e.name;
  if (e.k === "pow") {
    if (e.exp.k === "num" && e.exp.v === -1) return `\\frac{1}{${latexAtom(e.base)}}`;
    return `${latexAtom(e.base)}^{${latexSym(e.exp)}}`;
  }
  if (e.k === "mul") {
    const dens: Sym[] = [];
    const tops: Sym[] = [];
    for (const x of e.xs) {
      if (x.k === "pow" && x.exp.k === "num" && x.exp.v < 0 && Number.isInteger(x.exp.v)) {
        if (x.exp.v === -1) dens.push(x.base);
        else dens.push({ k: "pow", base: x.base, exp: num(-x.exp.v) });
      } else tops.push(x);
    }
    const topS = tops.length ? joinParts(tops.map(latexAtom)) : "1";
    if (!dens.length) return topS;
    const botS = dens.length === 1 ? latexAtom(dens[0]) : joinParts(dens.map(latexAtom));
    return `\\frac{${topS}}{${botS}}`;
  }
  if (e.k === "add") {
    let s = "";
    e.xs.forEach((x, i) => {
      const p = peel(x);
      const body = latexBody(p.rest);
      if (i === 0) s += p.neg ? `-${body}` : body;
      else s += p.neg ? `-${body}` : `+${body}`;
    });
    return s;
  }
  const fn =
    e.name === "sin" || e.name === "cos" || e.name === "exp"
      ? `\\${e.name}`
      : `\\operatorname{${e.name}}`;
  return `${fn}\\!\\left(${e.args.map(latexSym).join(", ")}\\right)`;
}

function latexAtom(e: Sym): string {
  if (e.k === "num" || e.k === "sym" || e.k === "call") return latexBody(e);
  if (e.k === "pow" && (e.base.k === "sym" || e.base.k === "num")) return latexBody(e);
  if (e.k === "mul" || e.k === "pow" || e.k === "add") {
    const inner = latexBody(e);
    if (inner.startsWith("\\frac") || inner.startsWith("-")) return `(${inner})`;
    if (e.k === "add") return `(${inner})`;
    return inner;
  }
  return `(${latexBody(e)})`;
}

function isOne(e: Sym): boolean {
  return e.k === "num" && Math.abs(e.v - 1) < 1e-12;
}

function wrap(e: Sym): string {
  const s = latexSym(e);
  if (e.k === "num" || e.k === "sym") return s;
  if (s.startsWith("\\frac")) return s;
  return `(${s})`;
}

function evalSym(e: Sym, params: Record<string, number>): number {
  switch (e.k) {
    case "num":
      return e.v;
    case "sym":
      if (e.name === "pi") return Math.PI;
      if (e.name === "e") return Math.E;
      if (e.name === "t") return NaN;
      return params[e.name] ?? 0;
    case "add":
      return e.xs.reduce((s, x) => s + evalSym(x, params), 0);
    case "mul":
      return e.xs.reduce((s, x) => s * evalSym(x, params), 1);
    case "pow":
      return Math.pow(evalSym(e.base, params), evalSym(e.exp, params));
    case "call":
      return NaN;
  }
}

function cAdd(a: Complex, b: Complex): Complex {
  return { re: a.re + b.re, im: a.im + b.im };
}
function cScale(a: Complex, s: number): Complex {
  return { re: a.re * s, im: a.im * s };
}
function cMul(a: Complex, b: Complex): Complex {
  return { re: a.re * b.re - a.im * b.im, im: a.re * b.im + a.im * b.re };
}

function sinc(x: number): number {
  if (Math.abs(x) < 1e-8) return 1;
  return Math.sin(Math.PI * x) / (Math.PI * x);
}

function evalOrdinary(core: Ordinary, omega: number, params: Record<string, number>): Complex | null {
  if (core.kind === "expabs" || core.kind === "gauss" || core.kind === "cexp") {
    const a = evalSym(core.a, params);
    if (!(a > 0) || !Number.isFinite(a)) return null;
    if (core.kind === "expabs") {
      return { re: (2 * a) / (a * a + omega * omega), im: 0 };
    }
    if (core.kind === "gauss") {
      return { re: Math.sqrt(Math.PI / a) * Math.exp(-(omega * omega) / (4 * a)), im: 0 };
    }
    const den = a * a + omega * omega;
    return { re: a / den, im: -omega / den };
  }
  if (core.kind === "rect" || core.kind === "tri" || core.kind === "sinc") {
    const tau = evalSym(core.tau, params);
    if (!Number.isFinite(tau) || Math.abs(tau) < 1e-9) return null;
    if (core.kind === "rect") return { re: Math.abs(tau) * sinc((omega * Math.abs(tau)) / (2 * Math.PI)), im: 0 };
    if (core.kind === "tri") {
      const s = sinc((omega * Math.abs(tau)) / (2 * Math.PI));
      return { re: Math.abs(tau) * s * s, im: 0 };
    }
    const x = Math.abs((omega * tau) / (2 * Math.PI));
    const re = x < 0.5 ? Math.abs(tau) : Math.abs(x - 0.5) < 1e-8 ? Math.abs(tau) / 2 : 0;
    return { re, im: 0 };
  }
  return null;
}

function evalCore(core: Core, omega: number, params: Record<string, number>): Complex | null {
  if (core.kind === "dc" || core.kind === "cos" || core.kind === "sin" || core.kind === "square" || core.kind === "saw") {
    return null;
  }
  if (core.kind === "modcos" || core.kind === "modsin") {
    const w = evalSym(core.w, params);
    const phi = evalSym(core.phi, params);
    if (!Number.isFinite(w) || !Number.isFinite(phi)) return null;
    const Fp = evalOrdinary(core.inner, omega - w, params);
    const Fm = evalOrdinary(core.inner, omega + w, params);
    if (!Fp || !Fm) return null;
    const ej = { re: Math.cos(phi), im: Math.sin(phi) };
    const ejn = { re: Math.cos(phi), im: -Math.sin(phi) };
    if (core.kind === "modcos") return cScale(cAdd(cMul(ej, Fp), cMul(ejn, Fm)), 0.5);
    const diff = cAdd(cMul(ej, Fp), cScale(cMul(ejn, Fm), -1));
    return cMul({ re: 0, im: -0.5 }, diff);
  }
  return evalOrdinary(core, omega, params);
}

function termLatex(term: Term, envelope = false): string {
  const C = term.coeff;
  const core = term.core;
  const withC = (body: string) => (isOne(C) ? body : `${latexAtom(C)}\\,${body}`);
  if (core.kind === "dc") return withC("2\\pi\\,\\delta(\\omega)");
  if (core.kind === "expabs") {
    const a = wrap(core.a);
    const top = isOne(C) ? `2${a}` : `2${a}${latexAtom(C)}`;
    return `\\dfrac{${top}}{${a}^{2}+\\omega^{2}}`;
  }
  if (core.kind === "gauss") {
    const a = wrap(core.a);
    return withC(`\\sqrt{\\dfrac{\\pi}{${a}}}\\exp\\!\\left(-\\dfrac{\\omega^{2}}{4${a}}\\right)`);
  }
  if (core.kind === "rect") {
    const tau = wrap(core.tau);
    const amp = isOne(C) ? tau : `${latexAtom(C)}${tau}`;
    return `${amp}\\operatorname{sinc}\\!\\left(\\dfrac{\\omega ${tau}}{2\\pi}\\right)`;
  }
  if (core.kind === "tri") {
    const tau = wrap(core.tau);
    const amp = isOne(C) ? tau : `${latexAtom(C)}${tau}`;
    return `${amp}\\operatorname{sinc}^{2}\\!\\left(\\dfrac{\\omega ${tau}}{2\\pi}\\right)`;
  }
  if (core.kind === "cexp") {
    const a = wrap(core.a);
    const top = isOne(C) ? "1" : latexAtom(C);
    return `\\dfrac{${top}}{${a}+j\\omega}`;
  }
  if (core.kind === "sinc") {
    const tau = wrap(core.tau);
    const amp = isOne(C) ? `\\left|${tau}\\right|` : `${latexAtom(C)}\\left|${tau}\\right|`;
    return `${amp}\\operatorname{rect}\\!\\left(\\dfrac{\\omega ${tau}}{2\\pi}\\right)`;
  }
  if (core.kind === "cos" || core.kind === "sin") {
    const w = wrap(core.w);
    const phi = latexSym(core.phi);
    const phi0 = core.phi.k === "num" && Math.abs(core.phi.v) < 1e-12;
    const amp = isOne(C) ? "\\pi" : `${latexAtom(C)}\\pi`;
    if (core.kind === "cos") {
      if (phi0) return `${amp}\\left(\\delta(\\omega-${w})+\\delta(\\omega+${w})\\right)`;
      return `${amp}\\left(e^{j${phi}}\\delta(\\omega-${w})+e^{-j${phi}}\\delta(\\omega+${w})\\right)`;
    }
    if (phi0) return `-j${amp}\\left(\\delta(\\omega-${w})-\\delta(\\omega+${w})\\right)`;
    return `-j${amp}\\left(e^{j${phi}}\\delta(\\omega-${w})-e^{-j${phi}}\\delta(\\omega+${w})\\right)`;
  }
  if (core.kind === "square" || core.kind === "saw") {
    return "2\\pi\\sum_{n} c_n\\delta(\\omega-n\\omega_0)";
  }
  const w = wrap(core.w);
  const phi0 = core.phi.k === "num" && Math.abs(core.phi.v) < 1e-12;
  const env = termLatex({ coeff: num(1), core: core.inner }, true);
  const name = envelope ? "G" : "F_1";
  if (core.kind === "modcos") {
    if (phi0) return `\\dfrac{1}{2}${latexAtom(C)}\\left(${name}(\\omega-${w})+${name}(\\omega+${w})\\right)`;
    return `\\dfrac{${latexAtom(C)}}{2}\\left(e^{j${latexSym(core.phi)}}${name}(\\omega-${w})+e^{-j${latexSym(core.phi)}}${name}(\\omega+${w})\\right)`;
  }
  const sinBody = phi0
    ? `-\\dfrac{j}{2}${latexAtom(C)}\\left(${name}(\\omega-${w})-${name}(\\omega+${w})\\right)`
    : `\\dfrac{${latexAtom(C)}}{2j}\\left(e^{j${latexSym(core.phi)}}${name}(\\omega-${w})-e^{-j${latexSym(core.phi)}}${name}(\\omega+${w})\\right)`;
  return `${sinBody}\\\\ ${name}(\\omega)=${env}`;
}

function seriesLatexFor(terms: Term[]): string | null {
  if (terms.length === 1 && terms[0].core.kind === "square") {
    const C = latexAtom(terms[0].coeff);
    const phi = (terms[0].core as { phi: Sym }).phi;
    const phi0 = phi.k === "num" && Math.abs(phi.v) < 1e-12;
    if (phi0) {
      return `a_0=0,\\ a_n=0,\\ b_n=\\begin{cases}\\dfrac{4${C}}{n\\pi}& n\\ \\text{奇}\\\\ 0& n\\ \\text{偶}\\end{cases}`;
    }
    return `n\\ \\text{奇时}\\ a_n=\\dfrac{4${C}}{n\\pi}\\sin(n\\varphi),\\ b_n=\\dfrac{4${C}}{n\\pi}\\cos(n\\varphi);\\ n\\ \\text{偶时为}\\ 0`;
  }
  if (terms.length === 1 && terms[0].core.kind === "saw") {
    const C = latexAtom(terms[0].coeff);
    return `a_0=0,\\ a_n=0,\\ b_n=\\dfrac{2${C}(-1)^{n+1}}{n\\pi}`;
  }
  const trig = terms.every((t) => t.core.kind === "cos" || t.core.kind === "sin");
  if (trig && terms.length > 0) {
    return "若\\ \\omega=n\\omega_0,\\ \\cos(\\omega t+\\varphi)\\ \\text{给出}\\ a_n=A\\cos\\varphi,\\ b_n=-A\\sin\\varphi;\\ \\sin\\ \\text{给出}\\ a_n=A\\sin\\varphi,\\ b_n=A\\cos\\varphi";
  }
  const ordinary = terms.every((t) => !isDistributional(t.core) && t.core.kind !== "modcos" && t.core.kind !== "modsin");
  if (ordinary) {
    return "c_n=\\dfrac{1}{T}F(n\\omega_0),\\quad a_0=c_0,\\ a_n=2\\operatorname{Re}c_n,\\ b_n=-2\\operatorname{Im}c_n";
  }
  if (terms.some((t) => t.core.kind === "modcos" || t.core.kind === "modsin")) {
    return "c_n=\\dfrac{1}{T}F(n\\omega_0)\\ \\text{（信号需几乎落在一个周期内）}";
  }
  return null;
}

function buildFLatex(terms: Term[]): string {
  const chunks: string[] = [];
  const extras: string[] = [];
  terms.forEach((term, i) => {
    const peeled = peel(term.coeff);
    let piece = termLatex({ coeff: peeled.rest, core: term.core });
    const extraIdx = piece.indexOf("\\\\");
    if (extraIdx >= 0) {
      extras.push(piece.slice(extraIdx + 2).trim());
      piece = piece.slice(0, extraIdx).trim();
    }
    const formulaNeg = piece.startsWith("-");
    const body = formulaNeg ? piece.slice(1) : piece;
    const neg = peeled.neg !== formulaNeg;
    if (i === 0) chunks.push(neg ? `-${body}` : body);
    else chunks.push(neg ? `-${body}` : `+${body}`);
  });
  let s = chunks.join("");
  if (extras.length) s += ",\\quad " + extras.join(",\\ ");
  return s;
}

function notesFor(terms: Term[]): string[] {
  const notes: string[] = [];
  if (terms.some((t) => t.core.kind === "cos" || t.core.kind === "sin" || t.core.kind === "dc" || t.core.kind === "square" || t.core.kind === "saw")) {
    notes.push("冲激只在分布意义下成立。数值频谱看到的是观察窗的窄峰，不是无限高的 δ。");
  }
  if (terms.some((t) => t.core.kind === "rect" || t.core.kind === "tri" || t.core.kind === "sinc")) {
    notes.push("\\operatorname{sinc}x=\\sin(\\pi x)/(\\pi x)，\\operatorname{rect} 在 |x|<1/2 为 1。");
  }
  if (terms.some((t) => t.core.kind === "sinc")) {
    notes.push("sinc 拖尾很长，观察窗要开大，数值谱才接近矩形。");
  }
  if (terms.some((t) => t.core.kind === "square")) {
    notes.push("方波级数默认分析周期等于信号周期。只保留奇次正弦项。");
  }
  if (terms.some((t) => t.core.kind === "saw")) {
    notes.push("锯齿波级数默认分析周期等于参量里的周期。");
  }
  return notes;
}

export function recognize(ast: Ast): ClosedForm | null {
  const parts = splitAdd(fromAst(ast));
  const terms: Term[] = [];
  for (const p of parts) {
    if (p.k === "num" && p.v === 0) continue;
    const m = matchProduct(p);
    if (!m) return null;
    terms.push(...m);
  }
  if (terms.length === 0) return null;
  const distributional = terms.some((t) => isDistributional(t.core));
  const ordinaryOnly = terms.every((t) => !isDistributional(t.core));
  return {
    terms,
    fLatex: astToLatex(ast),
    FLatex: buildFLatex(terms),
    seriesLatex: seriesLatexFor(terms),
    distributional,
    notes: notesFor(terms),
    evalAt: (omega, params) => {
      if (!ordinaryOnly) return null;
      let acc: Complex = { re: 0, im: 0 };
      for (const term of terms) {
        const c = evalSym(term.coeff, params);
        const v = evalCore(term.core, omega, params);
        if (!v || !Number.isFinite(c) || !Number.isFinite(v.re) || !Number.isFinite(v.im)) return null;
        acc = cAdd(acc, cScale(v, c));
      }
      return acc;
    },
  };
}

export function liveNote(form: ClosedForm, params: Record<string, number>): string {
  if (form.terms.length !== 1) {
    return "这是几项之和。变换按项相加，拖动每一项自己的参量，看它只改自己那一支频谱。";
  }
  const term = form.terms[0];
  const C = evalSym(term.coeff, params);
  const core = term.core;
  if (core.kind === "expabs") {
    const a = evalSym(core.a, params);
    return `双边指数。频谱是洛伦兹函数，降到峰值一半时 |ω| = a = ${fmt(a)}。a 越大，时域越瘦、频谱越宽。`;
  }
  if (core.kind === "gauss") {
    const a = evalSym(core.a, params);
    return `高斯的变换仍是高斯。a = ${fmt(a)} 时频域指数是 ω²/(4a)。a 越大，脉冲越窄，频谱越铺开。`;
  }
  if (core.kind === "rect") {
    const tau = evalSym(core.tau, params);
    return `矩形宽 τ = ${fmt(tau)}。sinc 的主瓣零点在 ω = ±2π/τ = ±${fmt((2 * Math.PI) / tau)}。τ 加大，主瓣变窄。`;
  }
  if (core.kind === "tri") {
    const tau = evalSym(core.tau, params);
    return `三角脉冲的频谱是 sinc²，旁瓣比矩形低。零点仍在 2π/τ = ${fmt((2 * Math.PI) / tau)} 的整数倍。`;
  }
  if (core.kind === "cexp") {
    const a = evalSym(core.a, params);
    return `单边指数。F(ω) = 1/(a+jω)，幅度 1/√(a²+ω²)。a = ${fmt(a)}，3 dB 点大约在 |ω| = a。`;
  }
  if (core.kind === "sinc") {
    const tau = evalSym(core.tau, params);
    return `sinc 的变换是矩形，截止在 |ω| = π/|τ| = ${fmt(Math.PI / Math.abs(tau || 1))}。时域越宽，频域矩形越窄。`;
  }
  if (core.kind === "cos" || core.kind === "sin") {
    const w = evalSym(core.w, params);
    return `永恒${core.kind === "cos" ? "余弦" : "正弦"}在 ±ω = ±${fmt(w)} 各有一根冲激。窗内数值谱是两根窄峰，相位由 φ 决定。`;
  }
  if (core.kind === "square") {
    return `方波只含奇次正弦。第一项 b₁ = 4A/π = ${fmt((4 * C) / Math.PI)}。谐波次数加大，平顶更平，但间断点的过冲不消失。`;
  }
  if (core.kind === "saw") {
    return `锯齿波只有正弦项，bₙ = 2A(−1)^{n+1}/(nπ)。第一项 |b₁| = 2A/π = ${fmt((2 * Math.abs(C)) / Math.PI)}。`;
  }
  if (core.kind === "modcos" || core.kind === "modsin") {
    const w = evalSym(core.w, params);
    return `调制把包络的频谱对半拆开，搬到 ±ωc = ±${fmt(w)}。包络越窄，每一团频谱越宽。`;
  }
  return "拖动参量，对照封闭形式和数值曲线。";
}

function fmt(n: number): string {
  if (!Number.isFinite(n)) return "—";
  const a = Math.abs(n);
  if (a >= 100) return n.toFixed(1);
  if (a >= 10) return n.toFixed(2);
  return n.toFixed(3);
}

export function theoryError(
  form: ClosedForm,
  w: number[],
  re: number[],
  im: number[],
  params: Record<string, number>,
  wMax: number,
): number | null {
  let num = 0;
  let den = 0;
  let hit = 0;
  for (let i = 0; i < w.length; i++) {
    if (Math.abs(w[i]) > wMax) continue;
    const th = form.evalAt(w[i], params);
    if (!th) return null;
    const dr = re[i] - th.re;
    const di = im[i] - th.im;
    num += dr * dr + di * di;
    den += th.re * th.re + th.im * th.im + re[i] * re[i] + im[i] * im[i];
    hit++;
  }
  if (!hit) return null;
  return Math.sqrt(num / Math.max(den, 1e-18));
}

