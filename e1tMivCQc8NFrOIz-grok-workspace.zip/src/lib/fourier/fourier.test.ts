import assert from "node:assert/strict";
import test from "node:test";
import { evaluate, parse } from "./expr.ts";
import { fourierSeries, interp, parseval, transform } from "./num.ts";
import { runExperiment } from "./properties.ts";
import { recognize, theoryError } from "./symbolic.ts";

const params = (p: Record<string, number>) => p;

function fnOf(expr: string, p: Record<string, number>) {
  const ast = parse(expr);
  return (t: number) => evaluate(ast, t, p);
}

test("parser evaluates classic values", () => {
  assert.ok(Math.abs(evaluate(parse("sin(pi/2)"), 0, {}) - 1) < 1e-12);
  assert.ok(Math.abs(evaluate(parse("2t"), 3, {}) - 6) < 1e-12);
  assert.ok(Math.abs(evaluate(parse("A exp(-a abs(t))"), 0, { A: 2, a: 1 }) - 2) < 1e-12);
  assert.equal(evaluate(parse("rect(0)"), 0, {}), 1);
  assert.equal(evaluate(parse("sinc(0)"), 0, {}), 1);
  assert.ok(Math.abs(evaluate(parse("2^3^2"), 0, {}) - 512) < 1e-9);
});

test("FT of two-sided exponential", () => {
  const f = (t: number) => Math.exp(-Math.abs(t));
  const spec = transform(f, 12, 4096);
  const z = interp(spec, 0);
  const at1 = interp(spec, 1);
  assert.ok(Math.abs(z.re - 2) < 0.02, `F(0)=${z.re}`);
  assert.ok(Math.abs(at1.re - 1) < 0.03, `F(1)=${at1.re}`);
  assert.ok(Math.abs(at1.im) < 0.03, `F(1) im ${at1.im}`);
  const p = parseval(f, spec);
  assert.ok(Math.abs(p.time - p.freq) / p.time < 0.02, JSON.stringify(p));
});

test("FT of gaussian, rect, causal, tri", () => {
  const g = transform((t) => Math.exp(-t * t), 8, 4096);
  const g0 = g.re[g.w.findIndex((w) => Math.abs(w) < 1e-6)];
  assert.ok(Math.abs(g0 - Math.sqrt(Math.PI)) < 0.01, `gauss ${g0}`);

  const r = transform((t) => (Math.abs(t) < 0.5 ? 1 : 0), 8, 4096);
  const r0 = r.re[r.w.findIndex((w) => Math.abs(w) < 1e-6)];
  assert.ok(Math.abs(r0 - 1) < 0.02, `rect ${r0}`);

  const c = transform((t) => (t >= 0 ? Math.exp(-t) : 0), 12, 4096);
  const i1 = c.w.reduce((b, w, i) => (Math.abs(w - 1) < Math.abs(c.w[b] - 1) ? i : b), 0);
  assert.ok(Math.abs(c.re[i1] - 0.5) < 0.03, `cexp re ${c.re[i1]}`);
  assert.ok(Math.abs(c.im[i1] + 0.5) < 0.03, `cexp im ${c.im[i1]}`);

  const tri = transform((t) => Math.max(0, 1 - Math.abs(t)), 8, 4096);
  const t0 = tri.re[tri.w.findIndex((w) => Math.abs(w) < 1e-6)];
  assert.ok(Math.abs(t0 - 1) < 0.03, `tri ${t0}`);
});

test("square and saw series", () => {
  const sq = fourierSeries((t) => Math.sign(Math.sin(Math.PI * t)), 2, 6, 8192);
  assert.ok(Math.abs(sq.bn[1] - 4 / Math.PI) < 0.02, `b1 ${sq.bn[1]}`);
  assert.ok(Math.abs(sq.bn[2]) < 0.02);
  assert.ok(Math.abs(sq.an[1]) < 0.02);
  const saw = fourierSeries((t) => {
    const x = t / 2;
    return 2 * (x - Math.round(x));
  }, 2, 4, 8192);
  assert.ok(Math.abs(saw.bn[1] - 2 / Math.PI) < 0.03, `saw b1 ${saw.bn[1]}`);
  assert.ok(Math.abs(saw.an[1]) < 0.03);
});

test("closed forms match numerical spectra", () => {
  const cases: { expr: string; p: Record<string, number>; L: number; tol: number }[] = [
    { expr: "A*exp(-a*abs(t))", p: { A: 1.4, a: 1.2 }, L: 10, tol: 0.03 },
    { expr: "A*exp(-a*t^2)", p: { A: 0.8, a: 0.7 }, L: 8, tol: 0.03 },
    { expr: "A*rect(t/tau)", p: { A: 1.2, tau: 1.5 }, L: 8, tol: 0.05 },
    { expr: "A*tri(t/tau)", p: { A: 1, tau: 1.5 }, L: 8, tol: 0.05 },
    { expr: "A*exp(-a*t)*u(t)", p: { A: 1.1, a: 0.9 }, L: 12, tol: 0.04 },
    { expr: "A*sinc(t/tau)", p: { A: 1, tau: 1.2 }, L: 18, tol: 0.12 },
    { expr: "A*exp(-a*abs(t))*cos(w*t)", p: { A: 1, a: 1, w: 5 }, L: 10, tol: 0.06 },
    { expr: "A*cos(2*pi*t/T)+B*sin(4*pi*t/T)", p: { A: 1, B: 0.5, T: 2 }, L: 8, tol: 0.2 },
  ];
  for (const c of cases) {
    const ast = parse(c.expr);
    const form = recognize(ast);
    assert.ok(form, `unrecognized ${c.expr}`);
    const spec = transform(fnOf(c.expr, c.p), c.L, 4096);
    const err = theoryError(form, spec.w, spec.re, spec.im, params(c.p), 12);
    if (form.distributional) {
      assert.equal(err, null, c.expr);
    } else {
      assert.ok(err !== null && err < c.tol, `${c.expr} err ${err}`);
    }
  }
});

test("square closed form exists and cosine is distributional", () => {
  const sq = recognize(parse("A*sign(sin(2*pi*t/T))"));
  assert.ok(sq);
  assert.match(sq.seriesLatex ?? "", /b_n/);
  const tone = recognize(parse("A*cos(2*pi*t/T+phi)"));
  assert.ok(tone?.distributional);
});

test("linearity, scale and shift stay small on a gaussian", () => {
  const fn = (t: number) => Math.exp(-0.8 * t * t);
  const base = { fn, L: 8, wMax: 12, alpha: 1.2, beta: -0.4, gKind: "rect" as const, t0: 0.4, scaleA: 1.5, wc: 4, kernel: 1, gibbsN: 25 };
  const lin = runExperiment({ ...base, id: "linear" });
  const scale = runExperiment({ ...base, id: "scale" });
  const sh = runExperiment({ ...base, id: "shift" });
  const mod = runExperiment({ ...base, id: "mod" });
  const d = runExperiment({ ...base, id: "diff" });
  for (const [name, view] of [
    ["linear", lin],
    ["scale", scale],
    ["shift", sh],
    ["mod", mod],
    ["diff", d],
  ] as const) {
    const err = Number(view.metrics[0].value.replace("%", ""));
    assert.ok(err < 8, `${name} ${view.metrics[0].value}`);
  }
});

test("gibbs overshoot settles near 9 percent", () => {
  const view = runExperiment({
    id: "gibbs",
    fn: (t) => t,
    L: 4,
    wMax: 10,
    alpha: 1,
    beta: 1,
    gKind: "gauss",
    t0: 0,
    scaleA: 1,
    wc: 1,
    kernel: 1,
    gibbsN: 31,
  });
  const peak = Number(view.metrics[0].value);
  assert.ok(peak > 1.05 && peak < 1.2, `peak ${peak}`);
});
