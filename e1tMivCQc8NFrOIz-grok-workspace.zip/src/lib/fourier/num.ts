export type Spectrum = {
  w: number[];
  re: number[];
  im: number[];
  /** Sample spacing of the time window used to build this spectrum. */
  dt: number;
  L: number;
};

export type Series = {
  T: number;
  w0: number;
  a0: number;
  an: number[];
  bn: number[];
};

function fft(re: Float64Array, im: Float64Array, inverse = false): void {
  const n = re.length;
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      const tr = re[i];
      re[i] = re[j];
      re[j] = tr;
      const ti = im[i];
      im[i] = im[j];
      im[j] = ti;
    }
  }
  const sign = inverse ? 1 : -1;
  for (let len = 2; len <= n; len <<= 1) {
    const ang = (sign * 2 * Math.PI) / len;
    const wlenRe = Math.cos(ang);
    const wlenIm = Math.sin(ang);
    for (let i = 0; i < n; i += len) {
      let wr = 1;
      let wi = 0;
      const half = len >> 1;
      for (let k = 0; k < half; k++) {
        const j = i + k + half;
        const uRe = re[i + k];
        const uIm = im[i + k];
        const vRe = re[j] * wr - im[j] * wi;
        const vIm = re[j] * wi + im[j] * wr;
        re[i + k] = uRe + vRe;
        im[i + k] = uIm + vIm;
        re[j] = uRe - vRe;
        im[j] = uIm - vIm;
        const nwr = wr * wlenRe - wi * wlenIm;
        wi = wr * wlenIm + wi * wlenRe;
        wr = nwr;
      }
    }
  }
  if (inverse) {
    for (let i = 0; i < n; i++) {
      re[i] /= n;
      im[i] /= n;
    }
  }
}

export function transform(fn: (t: number) => number, L: number, n = 4096): Spectrum {
  const N = n < 16 ? 16 : n;
  const dt = (2 * L) / N;
  const re = new Float64Array(N);
  const im = new Float64Array(N);
  const t0 = -L;
  for (let i = 0; i < N; i++) {
    const y = fn(t0 + i * dt);
    re[i] = Number.isFinite(y) ? y : 0;
  }
  fft(re, im, false);
  const wRaw = new Float64Array(N);
  const Fr = new Float64Array(N);
  const Fi = new Float64Array(N);
  for (let k = 0; k < N; k++) {
    const kk = k <= N / 2 ? k : k - N;
    const omega = (2 * Math.PI * kk) / (N * dt);
    const phase = -omega * t0;
    const cr = Math.cos(phase);
    const ci = Math.sin(phase);
    const xr = re[k] * dt;
    const xi = im[k] * dt;
    Fr[k] = xr * cr - xi * ci;
    Fi[k] = xr * ci + xi * cr;
    wRaw[k] = omega;
  }
  const order = Array.from({ length: N }, (_, i) => i).sort((a, b) => wRaw[a] - wRaw[b]);
  return {
    w: order.map((i) => wRaw[i]),
    re: order.map((i) => Fr[i]),
    im: order.map((i) => Fi[i]),
    dt,
    L,
  };
}

export function interp(spec: Spectrum, omega: number): { re: number; im: number } {
  const w = spec.w;
  const n = w.length;
  if (n === 0) return { re: 0, im: 0 };
  if (omega <= w[0]) return { re: spec.re[0], im: spec.im[0] };
  if (omega >= w[n - 1]) return { re: spec.re[n - 1], im: spec.im[n - 1] };
  let lo = 0;
  let hi = n - 1;
  while (hi - lo > 1) {
    const mid = (lo + hi) >> 1;
    if (w[mid] <= omega) lo = mid;
    else hi = mid;
  }
  const span = w[hi] - w[lo] || 1;
  const u = (omega - w[lo]) / span;
  return {
    re: spec.re[lo] * (1 - u) + spec.re[hi] * u,
    im: spec.im[lo] * (1 - u) + spec.im[hi] * u,
  };
}

export function fourierSeries(fn: (t: number) => number, T: number, harmonics: number, samples = 4096): Series {
  const H = Math.max(1, Math.min(64, harmonics));
  const dt = T / samples;
  const w0 = (2 * Math.PI) / T;
  const a = new Float64Array(H + 1);
  const b = new Float64Array(H + 1);
  for (let i = 0; i < samples; i++) {
    const t = -T / 2 + (i + 0.5) * dt;
    const y0 = fn(t);
    const y = Number.isFinite(y0) ? y0 : 0;
    a[0] += y;
    for (let n = 1; n <= H; n++) {
      const th = n * w0 * t;
      a[n] += y * Math.cos(th);
      b[n] += y * Math.sin(th);
    }
  }
  a[0] = (a[0] * dt) / T;
  const an = [0];
  const bn = [0];
  for (let n = 1; n <= H; n++) {
    an.push((2 * a[n] * dt) / T);
    bn.push((2 * b[n] * dt) / T);
  }
  return { T, w0, a0: a[0], an, bn };
}

export function reconstruct(t: number, series: Series, harmonics?: number): number {
  const H = Math.min(series.an.length - 1, harmonics ?? series.an.length - 1);
  let s = series.a0;
  for (let n = 1; n <= H; n++) {
    const th = n * series.w0 * t;
    s += series.an[n] * Math.cos(th) + series.bn[n] * Math.sin(th);
  }
  return s;
}

export function energy(fn: (t: number) => number, t0: number, t1: number, samples = 2000): number {
  if (t1 <= t0) return 0;
  const dt = (t1 - t0) / samples;
  let s = 0;
  for (let i = 0; i < samples; i++) {
    const y = fn(t0 + (i + 0.5) * dt);
    if (Number.isFinite(y)) s += y * y;
  }
  return s * dt;
}

/** Parseval for the same window the spectrum was built on: ∫|f|² = (1/2π)∫|F|². */
export function parseval(fn: (t: number) => number, spec: Spectrum): { time: number; freq: number } {
  const n = spec.w.length;
  const dt = spec.dt;
  let time = 0;
  const t0 = -spec.L;
  for (let i = 0; i < n; i++) {
    const y = fn(t0 + i * dt);
    if (Number.isFinite(y)) time += y * y;
  }
  time *= dt;
  const dW = n > 1 ? spec.w[1] - spec.w[0] : 0;
  let acc = 0;
  for (let i = 0; i < n; i++) acc += spec.re[i] * spec.re[i] + spec.im[i] * spec.im[i];
  const freq = (acc * dW) / (2 * Math.PI);
  return { time, freq };
}

export function relError(a: Spectrum, b: Spectrum, wMax: number): number {
  let num = 0;
  let den = 0;
  const n = Math.min(a.w.length, b.w.length);
  for (let i = 0; i < n; i++) {
    if (Math.abs(a.w[i]) > wMax) continue;
    const dr = a.re[i] - b.re[i];
    const di = a.im[i] - b.im[i];
    num += dr * dr + di * di;
    den += a.re[i] * a.re[i] + a.im[i] * a.im[i] + b.re[i] * b.re[i] + b.im[i] * b.im[i];
  }
  return Math.sqrt(num / Math.max(den, 1e-18));
}

export function sampleSeries(
  fns: Record<string, (x: number) => number>,
  x0: number,
  x1: number,
  count: number,
): Record<string, number | null>[] {
  const keys = Object.keys(fns);
  const rows: Record<string, number | null>[] = [];
  const n = Math.max(2, count);
  for (let i = 0; i < n; i++) {
    const x = x0 + ((x1 - x0) * i) / (n - 1);
    const row: Record<string, number | null> = { x };
    for (const k of keys) {
      const y = fns[k](x);
      row[k] = Number.isFinite(y) ? y : null;
    }
    rows.push(row);
  }
  return rows;
}

export function spectrumRows(
  spec: Spectrum,
  wMax: number,
  keys: { re?: string; im?: string; mag?: string; db?: string; phase?: string },
): Record<string, number | null>[] {
  const rows: Record<string, number | null>[] = [];
  for (let i = 0; i < spec.w.length; i++) {
    const w = spec.w[i];
    if (w < -wMax || w > wMax) continue;
    const re = spec.re[i];
    const im = spec.im[i];
    const mag = Math.hypot(re, im);
    const row: Record<string, number | null> = { x: w };
    if (keys.re) row[keys.re] = re;
    if (keys.im) row[keys.im] = im;
    if (keys.mag) row[keys.mag] = mag;
    if (keys.db) row[keys.db] = 20 * Math.log10(mag + 1e-12);
    if (keys.phase) row[keys.phase] = Math.atan2(im, re);
    rows.push(row);
  }
  return rows;
}

export function tone(err: number): "ok" | "warn" | "bad" {
  if (err < 0.04) return "ok";
  if (err < 0.12) return "warn";
  return "bad";
}

export function toneText(err: number): string {
  if (err < 0.04) return "两边重合，这条性质在当前参量下成立。";
  if (err < 0.12) return "大体一致。剩下的差别主要来自有限观察窗把信号截断了。";
  return "偏差偏大。把观察窗加大，或让信号在窗边先衰减完，再看一次。";
}
