export class ParseError extends Error {
  index: number;
  constructor(message: string, index: number) {
    super(message);
    this.name = "ParseError";
    this.index = index;
  }
}

export type Ast =
  | { t: "n"; v: number }
  | { t: "v"; name: string }
  | { t: "u"; op: "-"; a: Ast }
  | { t: "b"; op: "+" | "-" | "*" | "/" | "^"; a: Ast; b: Ast }
  | { t: "c"; name: string; args: Ast[] };

const FUNCTIONS = new Set([
  "sin",
  "cos",
  "tan",
  "asin",
  "acos",
  "atan",
  "exp",
  "log",
  "ln",
  "abs",
  "sqrt",
  "sign",
  "sgn",
  "rect",
  "tri",
  "sinc",
  "heaviside",
  "u",
  "step",
  "floor",
  "ceil",
  "saw",
  "min",
  "max",
]);

const CONSTANTS = new Set(["pi", "e"]);

type Tok =
  | { k: "num"; v: number; i: number }
  | { k: "id"; name: string; i: number }
  | { k: "op"; op: "+" | "-" | "*" | "/" | "^"; i: number }
  | { k: "lp"; i: number }
  | { k: "rp"; i: number }
  | { k: "comma"; i: number };

const NAME_MAP: Record<string, string> = {
  π: "pi",
  τ: "tau",
  ω: "omega",
  φ: "phi",
  ϕ: "phi",
  α: "alpha",
  β: "beta",
  γ: "gamma",
};

function normalizeName(raw: string): string {
  if (NAME_MAP[raw]) return NAME_MAP[raw];
  return raw;
}

export function tokenize(src: string): Tok[] {
  const s = src;
  const out: Tok[] = [];
  let i = 0;
  while (i < s.length) {
    const c = s[i];
    if (c === " " || c === "\t" || c === "\n" || c === "\r") {
      i++;
      continue;
    }
    if (c === "(" || c === "（") {
      out.push({ k: "lp", i });
      i++;
      continue;
    }
    if (c === ")" || c === "）") {
      out.push({ k: "rp", i });
      i++;
      continue;
    }
    if (c === "," || c === "，") {
      out.push({ k: "comma", i });
      i++;
      continue;
    }
    if (c === "*" && s[i + 1] === "*") {
      out.push({ k: "op", op: "^", i });
      i += 2;
      continue;
    }
    if (c === "+" || c === "-" || c === "−" || c === "*" || c === "×" || c === "·" || c === "/" || c === "÷" || c === "^") {
      const op =
        c === "−"
          ? "-"
          : c === "×" || c === "·"
            ? "*"
            : c === "÷"
              ? "/"
              : (c as "+" | "-" | "*" | "/" | "^");
      out.push({ k: "op", op, i });
      i++;
      continue;
    }
    if ((c >= "0" && c <= "9") || (c === "." && s[i + 1] >= "0" && s[i + 1] <= "9")) {
      const start = i;
      let t = "";
      while (i < s.length && ((s[i] >= "0" && s[i] <= "9") || s[i] === ".")) {
        t += s[i];
        i++;
      }
      if (i < s.length && (s[i] === "e" || s[i] === "E")) {
        const ePos = i;
        let j = i + 1;
        if (s[j] === "+" || s[j] === "-") j++;
        if (s[j] >= "0" && s[j] <= "9") {
          t += s.slice(i, j);
          i = j;
          while (i < s.length && s[i] >= "0" && s[i] <= "9") {
            t += s[i];
            i++;
          }
        } else {
          i = ePos;
        }
      }
      const v = Number(t);
      if (!Number.isFinite(v)) throw new ParseError("数字无效", start);
      out.push({ k: "num", v, i: start });
      continue;
    }
    if (isIdentStart(c)) {
      const start = i;
      let name = "";
      while (i < s.length && isIdentCont(s[i])) {
        name += s[i];
        i++;
      }
      out.push({ k: "id", name: normalizeName(name), i: start });
      continue;
    }
    throw new ParseError(`不能识别「${c}」`, i);
  }
  return out;
}

function isIdentStart(c: string): boolean {
  return /[A-Za-z_\u0391-\u03c9\u03d5]/.test(c);
}
function isIdentCont(c: string): boolean {
  return /[A-Za-z0-9_\u0391-\u03c9\u03d5]/.test(c);
}

class Parser {
  toks: Tok[];
  pos = 0;
  constructor(toks: Tok[]) {
    this.toks = toks;
  }

  peek(): Tok | undefined {
    return this.toks[this.pos];
  }

  parse(): Ast {
    if (this.toks.length === 0) throw new ParseError("请输入 f(t)", 0);
    const e = this.parseAdd();
    if (this.pos < this.toks.length) {
      throw new ParseError("这里后面多出来一段", this.peek()?.i ?? 0);
    }
    return e;
  }

  parseAdd(): Ast {
    let left = this.parseMul();
    while (true) {
      const p = this.peek();
      if (p?.k === "op" && (p.op === "+" || p.op === "-")) {
        this.pos++;
        const right = this.parseMul();
        left = { t: "b", op: p.op, a: left, b: right };
        continue;
      }
      break;
    }
    return left;
  }

  parseMul(): Ast {
    let left = this.parseUnary();
    while (true) {
      const p = this.peek();
      if (p?.k === "op" && (p.op === "*" || p.op === "/")) {
        this.pos++;
        const right = this.parseUnary();
        left = { t: "b", op: p.op, a: left, b: right };
        continue;
      }
      if (p && (p.k === "num" || p.k === "id" || p.k === "lp")) {
        const right = this.parseUnary();
        left = { t: "b", op: "*", a: left, b: right };
        continue;
      }
      break;
    }
    return left;
  }

  parseUnary(): Ast {
    const p = this.peek();
    if (p?.k === "op" && p.op === "+") {
      this.pos++;
      return this.parseUnary();
    }
    if (p?.k === "op" && p.op === "-") {
      this.pos++;
      return { t: "u", op: "-", a: this.parseUnary() };
    }
    return this.parsePow();
  }

  parsePow(): Ast {
    const left = this.parsePrimary();
    const p = this.peek();
    if (p?.k === "op" && p.op === "^") {
      this.pos++;
      const right = this.parseUnary();
      return { t: "b", op: "^", a: left, b: right };
    }
    return left;
  }

  parsePrimary(): Ast {
    const p = this.peek();
    if (!p) throw new ParseError("表达式在这里断了", this.toks.at(-1)?.i ?? 0);
    if (p.k === "lp") {
      this.pos++;
      const e = this.parseAdd();
      const rp = this.peek();
      if (rp?.k !== "rp") throw new ParseError("少了一个右括号", p.i);
      this.pos++;
      return e;
    }
    if (p.k === "num") {
      this.pos++;
      return { t: "n", v: p.v };
    }
    if (p.k === "id") {
      this.pos++;
      const next = this.peek();
      if (next?.k === "lp" && FUNCTIONS.has(p.name)) {
        const args = this.parseArgs();
        return { t: "c", name: p.name, args };
      }
      if (next?.k === "lp") {
        throw new ParseError(`未知函数 ${p.name}`, p.i);
      }
      return { t: "v", name: p.name };
    }
    throw new ParseError("这里期望数字、变量或函数", p.i);
  }

  parseArgs(): Ast[] {
    const lp = this.peek();
    if (lp?.k !== "lp") throw new ParseError("函数后面需要括号", lp?.i ?? 0);
    this.pos++;
    if (this.peek()?.k === "rp") {
      this.pos++;
      return [];
    }
    const args = [this.parseAdd()];
    while (this.peek()?.k === "comma") {
      this.pos++;
      args.push(this.parseAdd());
    }
    if (this.peek()?.k !== "rp") throw new ParseError("函数参数没有写完", lp.i);
    this.pos++;
    return args;
  }
}

export function parse(src: string): Ast {
  if (src.trim().length > 400) throw new ParseError("表达式太长", 0);
  return new Parser(tokenize(src)).parse();
}

export function collectParams(ast: Ast): string[] {
  const found = new Set<string>();
  const walk = (a: Ast) => {
    if (a.t === "v") {
      if (a.name !== "t" && !CONSTANTS.has(a.name)) found.add(a.name);
      return;
    }
    if (a.t === "u") walk(a.a);
    else if (a.t === "b") {
      walk(a.a);
      walk(a.b);
    } else if (a.t === "c") a.args.forEach(walk);
  };
  walk(ast);
  return [...found];
}

function callFn(name: string, args: number[]): number {
  const [x, y] = args;
  switch (name) {
    case "sin":
      return Math.sin(x);
    case "cos":
      return Math.cos(x);
    case "tan":
      return Math.tan(x);
    case "asin":
      return Math.asin(x);
    case "acos":
      return Math.acos(x);
    case "atan":
      return args.length >= 2 ? Math.atan2(x, y) : Math.atan(x);
    case "exp":
      return Math.exp(x);
    case "log":
    case "ln":
      return Math.log(x);
    case "abs":
      return Math.abs(x);
    case "sqrt":
      return Math.sqrt(x);
    case "sign":
    case "sgn":
      return x > 0 ? 1 : x < 0 ? -1 : 0;
    case "rect": {
      const ax = Math.abs(x);
      if (ax < 0.5) return 1;
      if (Math.abs(ax - 0.5) < 1e-12) return 0.5;
      return 0;
    }
    case "tri":
      return Math.max(0, 1 - Math.abs(x));
    case "sinc":
      if (Math.abs(x) < 1e-10) return 1;
      return Math.sin(Math.PI * x) / (Math.PI * x);
    case "heaviside":
    case "u":
    case "step":
      return x >= 0 ? 1 : 0;
    case "floor":
      return Math.floor(x);
    case "ceil":
      return Math.ceil(x);
    case "saw": {
      const f = x - Math.round(x);
      return 2 * f;
    }
    case "min":
      return Math.min(x, y);
    case "max":
      return Math.max(x, y);
    default:
      return NaN;
  }
}

export function evaluate(ast: Ast, t: number, params: Record<string, number>): number {
  switch (ast.t) {
    case "n":
      return ast.v;
    case "v":
      if (ast.name === "t") return t;
      if (ast.name === "pi") return Math.PI;
      if (ast.name === "e") return Math.E;
      return params[ast.name] ?? 0;
    case "u":
      return -evaluate(ast.a, t, params);
    case "b": {
      const a = evaluate(ast.a, t, params);
      const b = evaluate(ast.b, t, params);
      switch (ast.op) {
        case "+":
          return a + b;
        case "-":
          return a - b;
        case "*":
          return a * b;
        case "/":
          return a / b;
        case "^":
          return Math.pow(a, b);
      }
    }
    case "c":
      return callFn(
        ast.name,
        ast.args.map((x) => evaluate(x, t, params)),
      );
  }
}

const GREEK: Record<string, string> = {
  pi: "\\pi",
  phi: "\\varphi",
  tau: "\\tau",
  omega: "\\omega",
  alpha: "\\alpha",
  beta: "\\beta",
  gamma: "\\gamma",
};

function latexName(name: string): string {
  if (name === "t") return "t";
  return GREEK[name] ?? name;
}

function isAtomAst(a: Ast): boolean {
  return a.t === "n" || a.t === "v" || a.t === "c";
}

export function astToLatex(ast: Ast): string {
  const precAdd = 1;
  const precMul = 2;
  const precPow = 3;
  const go = (a: Ast, prec: number): string => {
    if (a.t === "n") {
      const s = Number.isInteger(a.v) ? String(a.v) : String(Number(a.v.toPrecision(6)));
      return a.v < 0 && prec > 0 ? `(${s})` : s;
    }
    if (a.t === "v") return latexName(a.name);
    if (a.t === "u") {
      const inner = go(a.a, precPow);
      const s = `-${inner}`;
      return prec > precMul ? `(${s})` : s;
    }
    if (a.t === "c") {
      if ((a.name === "abs") && a.args.length === 1) return `\\left|${go(a.args[0], 0)}\\right|`;
      if (a.name === "sqrt" && a.args.length === 1) return `\\sqrt{${go(a.args[0], 0)}}`;
      const fn =
        a.name === "ln" || a.name === "log"
          ? "\\ln"
          : a.name === "sign" || a.name === "sgn"
            ? "\\operatorname{sign}"
            : a.name === "rect" || a.name === "tri" || a.name === "sinc" || a.name === "saw"
              ? `\\operatorname{${a.name}}`
              : a.name === "u" || a.name === "step" || a.name === "heaviside"
                ? "u"
                : `\\${["sin", "cos", "tan", "exp"].includes(a.name) ? a.name : `operatorname{${a.name}}`}`;
      return `${fn}\\!\\left(${a.args.map((x) => go(x, 0)).join(", ")}\\right)`;
    }
    const op = a.op;
    if (op === "/") {
      return `\\frac{${go(a.a, 0)}}{${go(a.b, 0)}}`;
    }
    if (op === "^") {
      const base = isAtomAst(a.a) && !(a.a.t === "n" && a.a.v < 0) ? go(a.a, 0) : `(${go(a.a, 0)})`;
      const s = `${base}^{${go(a.b, 0)}}`;
      return prec > precPow ? `(${s})` : s;
    }
    if (op === "*") {
      const left = go(a.a, precMul);
      const right = go(a.b, precMul);
      const sep = /\\[a-zA-Z]+$/.test(left) && /^[A-Za-z\\]/.test(right) ? " " : "";
      const s = `${left}${sep}${right}`;
      return prec > precMul ? `(${s})` : s;
    }
    const left = go(a.a, precAdd);
    const right = go(a.b, op === "-" ? precMul : precAdd);
    const s = op === "+" ? `${left}+${right}` : `${left}-${right}`;
    return prec > precAdd ? `(${s})` : s;
  };
  return go(ast, 0);
}

export function defaultParam(name: string): number {
  const table: Record<string, number> = {
    A: 1,
    B: 0.6,
    C: 0.5,
    a: 1,
    b: 1,
    c: 1,
    w: 4,
    omega: 4,
    wc: 6,
    w0: 4,
    f: 1,
    f0: 1,
    tau: 1.5,
    T: 2,
    phi: 0,
    t0: 0.4,
    sigma: 1,
    alpha: 1,
    beta: 1,
    gamma: 1,
    n: 1,
  };
  if (name in table) return table[name];
  if (/^[A-Z]$/.test(name)) return 1;
  return 1;
}

export function sliderRange(name: string, value: number): { min: number; max: number; step: number } {
  let min = -2;
  let max = 3;
  let step = 0.01;
  if (name === "phi") {
    min = -Math.PI;
    max = Math.PI;
    step = 0.01;
  } else if (name === "a" || name === "b" || name === "c" || name === "sigma" || name === "alpha") {
    min = 0.05;
    max = 5;
    step = 0.01;
  } else if (name === "tau" || name === "t0") {
    min = 0.15;
    max = 8;
    step = 0.01;
  } else if (name === "w" || name === "omega" || name === "wc" || name === "w0" || name === "gamma") {
    min = 0;
    max = 20;
    step = 0.05;
  } else if (name === "T") {
    min = 0.4;
    max = 12;
    step = 0.05;
  } else if (name === "n") {
    min = 1;
    max = 24;
    step = 1;
  } else if (/^[A-Z]$/.test(name)) {
    min = -2;
    max = 3;
    step = 0.01;
  }
  if (value < min) min = Math.floor(value * 10) / 10;
  if (value > max) max = Math.ceil(value * 10) / 10;
  return { min, max, step };
}
