export type Preset = {
  id: string;
  name: string;
  expr: string;
  params: Record<string, number>;
  half: number;
  wMax: number;
  blurb: string;
};

export const PRESETS: Preset[] = [
  {
    id: "exp",
    name: "双边指数",
    expr: "A*exp(-a*abs(t))",
    params: { A: 1, a: 1.2 },
    half: 8,
    wMax: 16,
    blurb: "偶函数，频谱是实的洛伦兹",
  },
  {
    id: "gauss",
    name: "高斯",
    expr: "A*exp(-a*t^2)",
    params: { A: 1, a: 0.8 },
    half: 6,
    wMax: 14,
    blurb: "变换后仍是高斯",
  },
  {
    id: "rect",
    name: "矩形",
    expr: "A*rect(t/tau)",
    params: { A: 1, tau: 1.6 },
    half: 8,
    wMax: 24,
    blurb: "频谱是 sinc",
  },
  {
    id: "tri",
    name: "三角",
    expr: "A*tri(t/tau)",
    params: { A: 1, tau: 1.6 },
    half: 8,
    wMax: 24,
    blurb: "频谱是 sinc 的平方",
  },
  {
    id: "causal",
    name: "单边指数",
    expr: "A*exp(-a*t)*u(t)",
    params: { A: 1, a: 1 },
    half: 8,
    wMax: 16,
    blurb: "有实部也有虚部",
  },
  {
    id: "tone",
    name: "余弦",
    expr: "A*cos(2*pi*t/T+phi)",
    params: { A: 1, T: 2, phi: 0 },
    half: 8,
    wMax: 12,
    blurb: "一根谐波，相位随 φ",
  },
  {
    id: "mod",
    name: "调制",
    expr: "A*exp(-a*abs(t))*cos(w*t)",
    params: { A: 1, a: 0.9, w: 6 },
    half: 8,
    wMax: 18,
    blurb: "包络谱搬到 ±w",
  },
  {
    id: "square",
    name: "方波",
    expr: "A*sign(sin(2*pi*t/T))",
    params: { A: 1, T: 2 },
    half: 6,
    wMax: 30,
    blurb: "只有奇次正弦",
  },
  {
    id: "saw",
    name: "锯齿",
    expr: "A*saw(t/T)",
    params: { A: 1, T: 2 },
    half: 6,
    wMax: 30,
    blurb: "正弦项按 1/n 下降",
  },
  {
    id: "sinc",
    name: "sinc",
    expr: "A*sinc(t/tau)",
    params: { A: 1, tau: 0.8 },
    half: 14,
    wMax: 16,
    blurb: "频谱应是矩形",
  },
  {
    id: "dual",
    name: "双音",
    expr: "A*cos(2*pi*t/T)+B*sin(4*pi*t/T)",
    params: { A: 1, B: 0.55, T: 2 },
    half: 8,
    wMax: 14,
    blurb: "第 1、2 号谐波",
  },
];
